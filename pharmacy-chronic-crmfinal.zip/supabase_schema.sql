-- ============================================================================
-- COMMUNITY PHARMACY CHRONIC PATIENT MEDICATION TRACKER & CRM
-- FULL SUPABASE / POSTGRESQL PRODUCTION DATABASE SCHEMA
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PATIENTS TABLE
CREATE TABLE IF NOT EXISTS patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_number VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(20) CHECK (gender IN ('Male', 'Female', 'Other')),
    phone_number VARCHAR(30) NOT NULL,
    email VARCHAR(150),
    address TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(30),
    primary_physician VARCHAR(100),
    physician_phone VARCHAR(30),
    preferred_channel VARCHAR(20) DEFAULT 'WhatsApp' CHECK (preferred_channel IN ('WhatsApp', 'SMS', 'Phone Call')),
    chronic_conditions TEXT[] DEFAULT '{}',
    allergies TEXT DEFAULT 'None reported',
    adherence_score NUMERIC(5, 2) DEFAULT 92.50, -- PDC Adherence percentage (0-100)
    risk_level VARCHAR(20) DEFAULT 'Low' CHECK (risk_level IN ('Low', 'Moderate', 'High')),
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Transferred')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. MEDICATIONS CATALOG (Standard Chronic Drugs Master List)
CREATE TABLE IF NOT EXISTS medications_catalog (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    generic_name VARCHAR(150) NOT NULL,
    brand_name VARCHAR(150),
    strength VARCHAR(50) NOT NULL,
    dosage_form VARCHAR(50) NOT NULL, -- Tablet, Capsule, Inhaler, Injection
    therapeutic_category VARCHAR(100) NOT NULL, -- Antihypertensive, Antidiabetic, Statin, etc.
    standard_pack_size INT DEFAULT 30,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. CHRONIC PRESCRIPTIONS / REGIMENS
CREATE TABLE IF NOT EXISTS chronic_prescriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    medication_name VARCHAR(200) NOT NULL,
    dosage VARCHAR(100) NOT NULL, -- e.g. "5mg"
    frequency VARCHAR(100) NOT NULL, -- e.g. "Once daily in the morning"
    quantity_per_refill INT NOT NULL DEFAULT 30,
    days_supply INT NOT NULL DEFAULT 30,
    prescribed_date DATE NOT NULL DEFAULT CURRENT_DATE,
    last_dispensed_date DATE NOT NULL DEFAULT CURRENT_DATE,
    next_refill_date DATE NOT NULL,
    refills_authorized INT DEFAULT 6,
    refills_remaining INT DEFAULT 5,
    prescribing_doctor VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Completed', 'Discontinued', 'On Hold')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. DISPENSE & REFILL AUDIT LOGS
CREATE TABLE IF NOT EXISTS refill_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    prescription_id UUID NOT NULL REFERENCES chronic_prescriptions(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    dispense_date DATE NOT NULL DEFAULT CURRENT_DATE,
    quantity_dispensed INT NOT NULL,
    days_supplied INT NOT NULL,
    pharmacist_name VARCHAR(100) NOT NULL,
    refill_compliance VARCHAR(30) DEFAULT 'On Time' CHECK (refill_compliance IN ('Early', 'On Time', 'Delayed 1-3d', 'Delayed >7d')),
    patient_feedback TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. CLINICAL INTERVENTIONS & MTM NOTES (Medication Therapy Management)
CREATE TABLE IF NOT EXISTS clinical_interventions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    pharmacist_name VARCHAR(100) NOT NULL,
    intervention_type VARCHAR(100) NOT NULL, -- Adherence Barrier, Adverse Effect, Drug Interaction, Lab Consultation
    clinical_summary TEXT NOT NULL,
    pharmacist_action TEXT NOT NULL,
    biometrics JSONB DEFAULT '{}'::jsonb, -- e.g. {"blood_pressure": "130/84", "blood_glucose_mg_dl": 126, "hba1c": "7.1%"}
    follow_up_required BOOLEAN DEFAULT FALSE,
    follow_up_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. REMINDER & OUTREACH LOGS
CREATE TABLE IF NOT EXISTS reminder_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    prescription_id UUID REFERENCES chronic_prescriptions(id) ON DELETE SET NULL,
    channel VARCHAR(20) NOT NULL, -- WhatsApp, SMS, Call
    message_content TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Sent', 'Delivered', 'Confirmed', 'Failed')),
    scheduled_for DATE NOT NULL,
    sent_at TIMESTAMPTZ,
    patient_response TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- INDEXES FOR FAST PHARMACY LOOKUPS & WORKFLOWS
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_patients_file_number ON patients(file_number);
CREATE INDEX IF NOT EXISTS idx_patients_phone ON patients(phone_number);
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient ON chronic_prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_next_refill ON chronic_prescriptions(next_refill_date);
CREATE INDEX IF NOT EXISTS idx_prescriptions_status ON chronic_prescriptions(status);
CREATE INDEX IF NOT EXISTS idx_refill_logs_patient ON refill_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_clinical_interventions_patient ON clinical_interventions(patient_id);

-- ============================================================================
-- TRIGGER: AUTO-CALCULATE NEXT REFILL DATE ON PRESCRIPTION INSERT/UPDATE
-- ============================================================================
CREATE OR REPLACE FUNCTION trg_calculate_next_refill()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.last_dispensed_date IS NOT NULL AND NEW.days_supply IS NOT NULL THEN
        NEW.next_refill_date := NEW.last_dispensed_date + (NEW.days_supply || ' days')::INTERVAL;
    END IF;
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_next_refill_date ON chronic_prescriptions;
CREATE TRIGGER set_next_refill_date
    BEFORE INSERT OR UPDATE OF last_dispensed_date, days_supply
    ON chronic_prescriptions
    FOR EACH ROW
    EXECUTE FUNCTION trg_calculate_next_refill();

-- ============================================================================
-- VIEW: PHARMACY WORKBENCH REFILL QUEUE SUMMARY
-- ============================================================================
CREATE OR REPLACE VIEW vw_refill_queue AS
SELECT 
    cp.id AS prescription_id,
    p.id AS patient_id,
    p.file_number,
    p.first_name || ' ' || p.last_name AS patient_name,
    p.phone_number,
    p.preferred_channel,
    p.risk_level,
    cp.medication_name,
    cp.dosage,
    cp.frequency,
    cp.days_supply,
    cp.last_dispensed_date,
    cp.next_refill_date,
    cp.refills_remaining,
    CASE 
        WHEN cp.next_refill_date < CURRENT_DATE THEN 'Overdue'
        WHEN cp.next_refill_date = CURRENT_DATE THEN 'Due Today'
        WHEN cp.next_refill_date <= CURRENT_DATE + INTERVAL '3 days' THEN 'Due Soon (1-3d)'
        WHEN cp.next_refill_date <= CURRENT_DATE + INTERVAL '7 days' THEN 'Upcoming (4-7d)'
        ELSE 'Scheduled'
    END AS urgency_status,
    (CURRENT_DATE - cp.next_refill_date) AS days_overdue_or_remaining
FROM chronic_prescriptions cp
JOIN patients p ON cp.patient_id = p.id
WHERE cp.status = 'Active'
ORDER BY cp.next_refill_date ASC;

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE medications_catalog ENABLE ROW LEVEL SECURITY;
ALTER TABLE chronic_prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE refill_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinical_interventions ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminder_logs ENABLE ROW LEVEL SECURITY;

-- Allow anonymous or authenticated access for client app (with API anon key)
CREATE POLICY "Public Read/Write Access on patients" ON patients FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public Read/Write Access on medications_catalog" ON medications_catalog FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public Read/Write Access on chronic_prescriptions" ON chronic_prescriptions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public Read/Write Access on refill_logs" ON refill_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public Read/Write Access on clinical_interventions" ON clinical_interventions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public Read/Write Access on reminder_logs" ON reminder_logs FOR ALL USING (true) WITH CHECK (true);

-- ============================================================================
-- SEED DATA: COMMUNITY PHARMACY REALISTIC CHRONIC PATIENTS & REGIMENS
-- ============================================================================
INSERT INTO patients (id, file_number, first_name, last_name, date_of_birth, gender, phone_number, email, address, emergency_contact_name, emergency_contact_phone, primary_physician, physician_phone, preferred_channel, chronic_conditions, allergies, adherence_score, risk_level, status, notes)
VALUES 
('a0000000-0000-0000-0000-000000000001', 'RX-1042', 'Eleanor', 'Vance', '1958-04-12', 'Female', '+1-555-019-2831', 'eleanor.vance@example.com', '742 Evergreen Terrace, Springfield', 'Thomas Vance (Son)', '+1-555-019-2839', 'Dr. Sarah Lin (Cardiologist)', '+1-555-900-1122', 'WhatsApp', ARRAY['Hypertension', 'Type 2 Diabetes'], 'Penicillin (Rash)', 96.00, 'Low', 'Active', 'Very cooperative. Usually picks up refills on Monday mornings.'),
('a0000000-0000-0000-0000-000000000002', 'RX-1043', 'Marcus', 'Aurelius', '1964-11-20', 'Male', '+1-555-014-9922', 'm.aurelius@example.com', '12 Roman Way, Apt 4B', 'Faustina Aurelius (Spouse)', '+1-555-014-9925', 'Dr. Robert Chen (Endocrinologist)', '+1-555-900-3344', 'SMS', ARRAY['Type 2 Diabetes', 'Dyslipidemia'], 'Sulfa drugs', 68.50, 'High', 'Active', 'History of missed doses due to busy travel schedule. Needs SMS reminders 3 days ahead.'),
('a0000000-0000-0000-0000-000000000003', 'RX-1044', 'Fatima', 'Al-Zahra', '1972-08-15', 'Female', '+1-555-018-4477', 'fatima.zahra@example.com', '88 Palm Boulevard, Suite 101', 'Ali Zahra (Brother)', '+1-555-018-4470', 'Dr. Emily Watson (Pulmonologist)', '+1-555-900-5566', 'WhatsApp', ARRAY['Asthma', 'Hypertension'], 'None reported', 91.00, 'Low', 'Active', 'Uses inhaler spacer technique. Counselled on peak flow diary.'),
('a0000000-0000-0000-0000-000000000004', 'RX-1045', 'David', 'Kowalski', '1951-02-28', 'Male', '+1-555-017-8811', 'dkowalski51@example.com', '304 Maple Street', 'Anna Kowalski (Daughter)', '+1-555-017-8815', 'Dr. Sarah Lin (Cardiologist)', '+1-555-900-1122', 'Phone Call', ARRAY['Hypertension', 'Heart Failure', 'Dyslipidemia'], 'Aspirin (GI Bleed)', 78.00, 'Moderate', 'Active', 'Prefers daughter to be notified for refills. Monitor edema and blood pressure closely.'),
('a0000000-0000-0000-0000-000000000005', 'RX-1046', 'Amara', 'Okonkwo', '1980-06-03', 'Female', '+1-555-013-6622', 'amara.o@example.com', '512 Unity Crescent', 'Chidi Okonkwo (Husband)', '+1-555-013-6629', 'Dr. Michael Taylor (GP)', '+1-555-900-7788', 'WhatsApp', ARRAY['Hypertension'], 'None reported', 98.00, 'Low', 'Active', 'Excellent adherence. Uses automated weekly pill organizer.'),
('a0000000-0000-0000-0000-000000000006', 'RX-1047', 'James', 'Wilson', '1960-09-17', 'Male', '+1-555-011-3344', 'jwilson@example.com', '19 Pineview Drive', 'Mary Wilson (Wife)', '+1-555-011-3348', 'Dr. Robert Chen (Endocrinologist)', '+1-555-900-3344', 'WhatsApp', ARRAY['Type 2 Diabetes', 'Neuropathy'], 'Codeine', 55.00, 'High', 'Active', 'Frequently forgets evening Metformin dose. Pharmacist recommended blister packaging.');

-- SEED PRESCRIPTIONS
INSERT INTO chronic_prescriptions (id, patient_id, medication_name, dosage, frequency, quantity_per_refill, days_supply, prescribed_date, last_dispensed_date, next_refill_date, refills_authorized, refills_remaining, prescribing_doctor, status, notes)
VALUES
-- Eleanor Vance (Refill Due in 2 days)
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'Amlodipine Besylate', '5mg', '1 tablet once daily in morning', 30, 30, CURRENT_DATE - 58, CURRENT_DATE - 28, CURRENT_DATE + 2, 6, 4, 'Dr. Sarah Lin', 'Active', 'Well tolerated, BP controlled (124/80)'),
('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001', 'Metformin Extended Release (Glucophage XR)', '500mg', '1 tablet twice daily with meals', 60, 30, CURRENT_DATE - 58, CURRENT_DATE - 28, CURRENT_DATE + 2, 6, 4, 'Dr. Sarah Lin', 'Active', 'Take with food to minimize GI upset'),

-- Marcus Aurelius (OVERDUE by 4 days - High Risk!)
('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000002', 'Empagliflozin (Jardiance)', '10mg', '1 tablet once daily in the morning', 30, 30, CURRENT_DATE - 70, CURRENT_DATE - 34, CURRENT_DATE - 4, 6, 3, 'Dr. Robert Chen', 'Active', 'URGENT: Patient is 4 days overdue. Call needed'),
('b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000002', 'Atorvastatin Calcium (Lipitor)', '20mg', '1 tablet at bedtime', 30, 30, CURRENT_DATE - 70, CURRENT_DATE - 34, CURRENT_DATE - 4, 6, 3, 'Dr. Robert Chen', 'Active', 'Monitor lipid panel every 6 months'),

-- Fatima Al-Zahra (Due Today!)
('b0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000003', 'Fluticasone / Salmeterol Inhaler (Advair)', '250/50 mcg', '1 inhalation twice daily', 1, 30, CURRENT_DATE - 60, CURRENT_DATE - 30, CURRENT_DATE, 4, 2, 'Dr. Emily Watson', 'Active', 'Rinse mouth after each inhalation'),
('b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000003', 'Lisinopril', '10mg', '1 tablet once daily in morning', 30, 30, CURRENT_DATE - 60, CURRENT_DATE - 30, CURRENT_DATE, 6, 4, 'Dr. Emily Watson', 'Active', 'No persistent dry cough reported'),

-- David Kowalski (Due in 5 days)
('b0000000-0000-0000-0000-000000000007', 'a0000000-0000-0000-0000-000000000004', 'Carvedilol (Coreg)', '12.5mg', '1 tablet twice daily with food', 60, 30, CURRENT_DATE - 85, CURRENT_DATE - 25, CURRENT_DATE + 5, 5, 2, 'Dr. Sarah Lin', 'Active', 'Daughter picks up. Check pulse rate'),
('b0000000-0000-0000-0000-000000000008', 'a0000000-0000-0000-0000-000000000004', 'Furosemide (Lasix)', '40mg', '1 tablet every morning', 30, 30, CURRENT_DATE - 85, CURRENT_DATE - 25, CURRENT_DATE + 5, 5, 2, 'Dr. Sarah Lin', 'Active', 'Take early in day to avoid nocturnal urination'),

-- Amara Okonkwo (Due in 18 days)
('b0000000-0000-0000-0000-000000000009', 'a0000000-0000-0000-0000-000000000005', 'Telmisartan (Micardis)', '40mg', '1 tablet once daily', 30, 30, CURRENT_DATE - 42, CURRENT_DATE - 12, CURRENT_DATE + 18, 6, 5, 'Dr. Michael Taylor', 'Active', 'BP optimal 118/76'),

-- James Wilson (OVERDUE by 9 days - Severe Adherence Risk)
('b0000000-0000-0000-0000-000000000010', 'a0000000-0000-0000-0000-000000000006', 'Metformin HCl', '850mg', '1 tablet twice daily with meals', 60, 30, CURRENT_DATE - 90, CURRENT_DATE - 39, CURRENT_DATE - 9, 3, 0, 'Dr. Robert Chen', 'Active', 'Out of refills! Needs physician re-authorization & urgent call');

-- SEED CLINICAL INTERVENTIONS
INSERT INTO clinical_interventions (patient_id, pharmacist_name, intervention_type, clinical_summary, pharmacist_action, biometrics, follow_up_required, follow_up_date)
VALUES
('a0000000-0000-0000-0000-000000000002', 'Pharm. Alex Mercer, RPh', 'Adherence Barrier', 'Patient missed 4 consecutive days of Jardiance while on a business trip. Unsure if safe to restart without seeing doctor.', 'Reassured patient to resume regular morning dose immediately. Counseled on using phone alarm. Scheduled SMS refill reminder 3 days before supply ends.', '{"blood_glucose_mg_dl": 182, "blood_pressure": "138/88"}'::jsonb, TRUE, CURRENT_DATE + 3),
('a0000000-0000-0000-0000-000000000004', 'Pharm. Alex Mercer, RPh', 'Lab Consultation', 'Blood pressure measured in pharmacy: 122/78 mmHg. Pulse: 64 bpm. Mild ankle edema assessed.', 'Patient educated on sodium restriction and elevating legs in evening. Advised daughter to monitor morning weight. Next cardiology follow-up in 2 weeks.', '{"blood_pressure": "122/78", "pulse_bpm": 64, "weight_kg": 81.5}'::jsonb, FALSE, NULL);
