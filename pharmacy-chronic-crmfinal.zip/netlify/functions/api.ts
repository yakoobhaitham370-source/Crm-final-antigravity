import { Handler } from '@netlify/functions';
import { handleApiRoute, RequestContext } from '../../src/server/routes';

export const handler: Handler = async (event, context) => {
  // CORS & Security headers
  const defaultHeaders: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: defaultHeaders,
      body: ''
    };
  }

  try {
    let body: any = null;
    if (event.body) {
      try {
        body = JSON.parse(event.body);
      } catch (e) {
        body = event.body;
      }
    }

    const query: Record<string, string> = {};
    if (event.queryStringParameters) {
      for (const [k, v] of Object.entries(event.queryStringParameters)) {
        if (v !== undefined) query[k] = v;
      }
    }

    // Role-based auth verification (mockable or JWT-backed)
    const authHeader = event.headers['authorization'] || event.headers['Authorization'] || '';
    let role: 'admin' | 'pharmacist' | 'staff' = 'pharmacist';
    let userName = 'Staff Pharmacist';

    if (authHeader.includes('admin')) {
      role = 'admin';
      userName = 'Chief Pharmacist (Admin)';
    } else if (authHeader.includes('staff')) {
      role = 'staff';
      userName = 'Pharmacy Technician';
    }

    const reqContext: RequestContext = {
      method: event.httpMethod,
      path: event.path,
      query,
      body,
      headers: event.headers as Record<string, string>,
      user: {
        id: 'usr_default',
        name: userName,
        role
      }
    };

    const result = await handleApiRoute(reqContext);

    let responseBody = '';
    const headers = { ...defaultHeaders, ...(result.headers || {}) };

    if (result.isRaw) {
      if (Buffer.isBuffer(result.body)) {
        return {
          statusCode: result.status,
          headers,
          body: result.body.toString('base64'),
          isBase64Encoded: true
        };
      }
      responseBody = String(result.body);
    } else {
      headers['Content-Type'] = 'application/json';
      responseBody = JSON.stringify(result.body);
    }

    return {
      statusCode: result.status,
      headers,
      body: responseBody
    };
  } catch (err: any) {
    console.error('Netlify function error:', err);
    return {
      statusCode: 500,
      headers: defaultHeaders,
      body: JSON.stringify({ error: err.message || 'Internal Server Error' })
    };
  }
};
