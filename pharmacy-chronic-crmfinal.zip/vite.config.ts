import { defineConfig, Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { handleApiRoute, RequestContext } from './src/server/routes';

// Vite dev server API middleware to execute backend routes locally
function devApiPlugin(): Plugin {
  return {
    name: 'dev-api-middleware',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url || (!req.url.startsWith('/api') && !req.url.startsWith('/.netlify/functions/api'))) {
          return next();
        }

        try {
          const parsedUrl = new URL(req.url, 'http://localhost:5173');
          const query: Record<string, string> = {};
          parsedUrl.searchParams.forEach((val, key) => {
            query[key] = val;
          });

          // Read body if POST / PUT / PATCH
          let body: any = null;
          if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method || '')) {
            const chunks: Buffer[] = [];
            for await (const chunk of req) {
              chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
            }
            const rawBody = Buffer.concat(chunks).toString('utf-8');
            if (rawBody) {
              try {
                body = JSON.parse(rawBody);
              } catch {
                body = rawBody;
              }
            }
          }

          const reqContext: RequestContext = {
            method: req.method || 'GET',
            path: parsedUrl.pathname,
            query,
            body,
            headers: req.headers as Record<string, string>,
            user: {
              id: 'usr_dev',
              name: 'Dr. Ali Al-Rawi (Staff)',
              role: 'pharmacist'
            }
          };

          const routeRes = await handleApiRoute(reqContext);

          res.statusCode = routeRes.status;
          if (routeRes.headers) {
            for (const [k, v] of Object.entries(routeRes.headers)) {
              res.setHeader(k, v);
            }
          }

          if (routeRes.isRaw) {
            res.end(routeRes.body);
          } else {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(routeRes.body));
          }
        } catch (err: any) {
          console.error('Dev API Error:', err);
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: err.message || 'Server error' }));
        }
      });
    }
  };
}

export default defineConfig({
  plugins: [react(), devApiPlugin()],
  server: {
    port: 5173,
    host: true
  }
});
