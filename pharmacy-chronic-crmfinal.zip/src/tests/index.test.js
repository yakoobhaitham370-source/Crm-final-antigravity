import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  calculateNextRefillDate,
  calculateNextReminderDate,
  recalculateMedicationSchedule,
  determineRefillStatus,
  calculateRetentionScore,
  normalizePhoneNumber,
  sanitizeFormulaInjection,
  validateDaysSupply,
  formatTemplateMessage
} from '../lib/calculations.ts';

describe('1. Days Supply Validation', () => {
  test('validates positive integers', () => {
    assert.equal(validateDaysSupply(30).valid, true);
    assert.equal(validateDaysSupply('60').valid, true);
    assert.equal(validateDaysSupply('60').value, 60);
  });

  test('rejects negative numbers, zero, or non-numeric strings', () => {
    assert.equal(validateDaysSupply(0).valid, false);
    assert.equal(validateDaysSupply(-15).valid, false);
    assert.equal(validateDaysSupply('abc').valid, false);
    assert.equal(validateDaysSupply(12.5).valid, false);
  });
});

describe('2. Medication Refill and Reminder Date Calculations', () => {
  test('accurately calculates next refill date as purchase date + days supply', () => {
    // 2026-10-01 + 30 days = 2026-10-31
    const nextRefill = calculateNextRefillDate('2026-10-01', 30);
    assert.equal(nextRefill, '2026-10-31');

    // Month boundary rollover: 2026-02-01 + 28 days = 2026-03-01
    const febRollover = calculateNextRefillDate('2026-02-01', 28);
    assert.equal(febRollover, '2026-03-01');

    // 90 day supply
    const ninetyDays = calculateNextRefillDate('2026-01-01', 90);
    assert.equal(ninetyDays, '2026-04-01');
  });

  test('accurately calculates reminder date as next refill date - reminder interval (default 3 days)', () => {
    const nextRefill = '2026-10-31';
    const reminderDate = calculateNextReminderDate(nextRefill, 3);
    assert.equal(reminderDate, '2026-10-28');

    // Configurable interval: 5 days
    const reminderDate5 = calculateNextReminderDate(nextRefill, 5);
    assert.equal(reminderDate5, '2026-10-26');

    // Configurable interval: 1 day
    const reminderDate1 = calculateNextReminderDate(nextRefill, 1);
    assert.equal(reminderDate1, '2026-10-30');
  });

  test('recalculateMedicationSchedule returns complete schedule and status', () => {
    const schedule = recalculateMedicationSchedule('2026-10-01', 30, 3, '2026-10-28');
    assert.equal(schedule.nextRefillDate, '2026-10-31');
    assert.equal(schedule.nextReminderDate, '2026-10-28');
    assert.equal(schedule.refillStatus, 'due_soon'); // 3 days away
  });
});

describe('3. Refill Status Categorization', () => {
  const today = '2026-10-15';

  test('identifies overdue refills', () => {
    assert.equal(determineRefillStatus('2026-10-10', today, 3), 'overdue');
    assert.equal(determineRefillStatus('2026-10-14', today, 3), 'overdue');
  });

  test('identifies refills due today', () => {
    assert.equal(determineRefillStatus('2026-10-15', today, 3), 'due_today');
  });

  test('identifies refills due soon within configurable reminder interval', () => {
    assert.equal(determineRefillStatus('2026-10-16', today, 3), 'due_soon'); // 1 day away
    assert.equal(determineRefillStatus('2026-10-18', today, 3), 'due_soon'); // 3 days away
  });

  test('identifies active refills beyond reminder window', () => {
    assert.equal(determineRefillStatus('2026-10-25', today, 3), 'active'); // 10 days away
  });
});

describe('4. Iraqi Phone Normalization (+964) & International Numbers', () => {
  test('normalizes 11-digit local Iraqi numbers starting with 07', () => {
    const res = normalizePhoneNumber('07701234567');
    assert.equal(res.valid, true);
    assert.equal(res.normalized, '+9647701234567');
    assert.equal(res.isIraq, true);
  });

  test('normalizes 10-digit Iraqi numbers without leading 0', () => {
    const res = normalizePhoneNumber('7801234567');
    assert.equal(res.valid, true);
    assert.equal(res.normalized, '+9647801234567');
    assert.equal(res.isIraq, true);
  });

  test('normalizes numbers with 00964 prefix', () => {
    const res = normalizePhoneNumber('009647501234567');
    assert.equal(res.valid, true);
    assert.equal(res.normalized, '+9647501234567');
    assert.equal(res.isIraq, true);
  });

  test('preserves already normalized Iraqi numbers with spaces/hyphens', () => {
    const res = normalizePhoneNumber('+964 770-123-4567');
    assert.equal(res.valid, true);
    assert.equal(res.normalized, '+9647701234567');
    assert.equal(res.isIraq, true);
  });

  test('preserves valid international numbers from other countries', () => {
    const res = normalizePhoneNumber('+962 7 9123 4567'); // Jordan
    assert.equal(res.valid, true);
    assert.equal(res.normalized, '+962791234567');
    assert.equal(res.isIraq, false);
  });
});

describe('5. Patient Retention Adherence Proxy (PDC)', () => {
  test('calculates high adherence for continuous refills', () => {
    const purchases = [
      { purchaseDate: '2026-05-01', daysSupply: 30 },
      { purchaseDate: '2026-05-31', daysSupply: 30 },
      { purchaseDate: '2026-06-30', daysSupply: 30 },
      { purchaseDate: '2026-07-30', daysSupply: 30 },
      { purchaseDate: '2026-08-29', daysSupply: 30 },
      { purchaseDate: '2026-09-28', daysSupply: 30 },
    ];
    const result = calculateRetentionScore(purchases, 180, '2026-10-28');
    assert.ok(result.score >= 80);
    assert.equal(result.status, 'retained');
  });

  test('detects at_risk and inactive status when significant gaps exist', () => {
    // Only one 30-day supply in past 180 days
    const purchases = [
      { purchaseDate: '2026-05-01', daysSupply: 30 }
    ];
    const result = calculateRetentionScore(purchases, 180, '2026-10-28');
    assert.ok(result.score < 50);
    assert.equal(result.status, 'inactive');
  });

  test('provides fallback baseline score for newly enrolled patients', () => {
    const result = calculateRetentionScore([], 180);
    assert.equal(result.score, 90.0);
    assert.equal(result.status, 'retained');
  });
});

describe('6. Spreadsheet Formula Injection Defense', () => {
  test('escapes formula trigger characters (=, +, -, @, tab, return)', () => {
    assert.equal(sanitizeFormulaInjection('=SUM(A1:A10)'), "'=SUM(A1:A10)");
    assert.equal(sanitizeFormulaInjection('+cmd|'), "'+cmd|");
    assert.equal(sanitizeFormulaInjection('-12+cmd'), "'-12+cmd");
    assert.equal(sanitizeFormulaInjection('@macro'), "'@macro");
    assert.equal(sanitizeFormulaInjection('Regular Text'), 'Regular Text');
    assert.equal(sanitizeFormulaInjection(123), '123');
    assert.equal(sanitizeFormulaInjection(null), '');
  });
});

describe('7. Message Template Compilation', () => {
  test('replaces placeholders accurately', () => {
    const template = 'Dear {patient_name}, your refill for {medications} is due on {due_date}. - {pharmacy_name} ({pharmacy_phone})';
    const compiled = formatTemplateMessage(template, {
      patient_name: 'Ahmed',
      medications: 'Metformin 500mg',
      due_date: '2026-10-15',
      pharmacy_name: 'Al-Mansour Community Pharmacy',
      pharmacy_phone: '+9647701234567'
    });

    assert.equal(
      compiled,
      'Dear Ahmed, your refill for Metformin 500mg is due on 2026-10-15. - Al-Mansour Community Pharmacy (+9647701234567)'
    );
  });
});
