import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';
import { repository } from '../server/repository.ts';
import { handleApiRoute } from '../server/routes.ts';

describe('Pharmacy Backend Integration & Security Tests', () => {
  before(() => {
    repository.init();
    repository.updateSettings({ reminderIntervalDays: 3 }, 'TestSetup');
  });

  test('1. Database Status Endpoint returns sanitized status without credentials', async () => {
    const res = await handleApiRoute({
      method: 'GET',
      path: '/api/system/db-status',
      query: {},
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(res.status, 200);
    assert.equal(typeof res.body.success, 'boolean');
    assert.equal(typeof res.body.message, 'string');
    // Ensure no passwords or database connection secrets leaked
    assert.equal(JSON.stringify(res.body).includes('password'), false);
    assert.equal(JSON.stringify(res.body).includes('postgres://'), false);
  });

  test('2. Patient Registration with Iraqi phone number normalization (+964)', async () => {
    const res = await handleApiRoute({
      method: 'POST',
      path: '/api/patients',
      query: {},
      body: {
        firstName: 'Karrar',
        lastName: 'Al-Husseini',
        dateOfBirth: '1968-04-12',
        gender: 'Male',
        phoneNumber: '07705556677', // Iraqi local format
        whatsappNumber: '07705556677',
        familyCode: 'FAM-KADHIMIYA-505',
        chronicConditions: ['Hypertension'],
        allergies: 'Ceftriaxone'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(res.status, 201);
    assert.equal(res.body.firstName, 'Karrar');
    assert.equal(res.body.phoneNumber, '+9647705556677');
    assert.equal(res.body.whatsappNumber, '+9647705556677');
    assert.ok(res.body.fileNumber.startsWith('RX-'));
    assert.equal(res.body.allergies, 'Ceftriaxone');
  });

  test('3. Add Medication with automatic refill & reminder date calculations', async () => {
    // Fetch a patient
    const patientsRes = await handleApiRoute({
      method: 'GET',
      path: '/api/patients',
      query: { search: 'Karrar' },
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });
    const patientId = patientsRes.body.data[0].id;

    // Add medication
    const medRes = await handleApiRoute({
      method: 'POST',
      path: `/api/patients/${patientId}/medications`,
      query: {},
      body: {
        drugName: 'Candesartan Cilexetil',
        strength: '16mg',
        dosageInstructions: '1 tablet daily in the morning',
        purchaseDate: '2026-10-01',
        daysSupply: 30
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(medRes.status, 201);
    assert.equal(medRes.body.nextRefillDate, '2026-10-31');
    assert.equal(medRes.body.nextReminderDate, '2026-10-28'); // default 3 days interval
  });

  test('4. Dispensing refill updates schedule and creates immutable audit log', async () => {
    const patientsRes = await handleApiRoute({
      method: 'GET',
      path: '/api/patients',
      query: { search: 'Karrar' },
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });
    const patient = patientsRes.body.data[0];
    const medId = patient.medications[0].id;

    const refillRes = await handleApiRoute({
      method: 'POST',
      path: '/api/refills',
      query: {},
      body: {
        medicationId: medId,
        purchaseDate: '2026-10-31',
        daysSupply: 30,
        quantityDispensed: 30,
        notes: 'Refill picked up on schedule. Blood pressure normal.'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(refillRes.status, 200);
    assert.equal(refillRes.body.medication.purchaseDate, '2026-10-31');
    assert.equal(refillRes.body.medication.nextRefillDate, '2026-11-30');
    assert.equal(refillRes.body.auditLog.action, 'refill_dispensed');
    assert.equal(refillRes.body.auditLog.refillCompliance, 'On Time');
  });

  test('5. Antibiotic follow-up creation and progress documentation', async () => {
    const abRes = await handleApiRoute({
      method: 'POST',
      path: '/api/antibiotics',
      query: {},
      body: {
        patientId: 'p001',
        antibioticName: 'Amoxicillin / Clavulanate (Augmentin)',
        dosageAndDuration: '1g BID for 7 days',
        startDate: '2026-10-01',
        expectedFollowupDate: '2026-10-08',
        pharmacistNotes: 'Dental infection; instructed on taking after meals.'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(abRes.status, 201);
    assert.equal(abRes.body.disclaimerAcknowledged, true);

    // Update progress
    const updateRes = await handleApiRoute({
      method: 'PUT',
      path: `/api/antibiotics/${abRes.body.id}`,
      query: {},
      body: {
        contactAttempts: 1,
        patientReportedProgress: 'improving',
        pharmacistNotes: 'Contacted via WhatsApp; symptoms resolving.'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(updateRes.status, 200);
    assert.equal(updateRes.body.contactAttempts, 1);
    assert.equal(updateRes.body.patientReportedProgress, 'improving');
  });

  test('6. Communication Opt-out blocks messaging', async () => {
    // Create opted-out patient
    const p = repository.createPatient({
      firstName: 'OptedOut',
      lastName: 'Patient',
      phoneNumber: '+9647700000000',
      whatsappNumber: '+9647700000000',
      optedOut: true
    }, 'Pharmacist');

    const msgRes = await handleApiRoute({
      method: 'POST',
      path: '/api/messages/send',
      query: {},
      body: {
        patientId: p.id,
        channel: 'whatsapp'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(msgRes.status, 403);
    assert.ok(msgRes.body.error.includes('opted out'));
  });

  test('7. Thermal Slip expiring token generation and verification', async () => {
    const tokenRes = await handleApiRoute({
      method: 'POST',
      path: '/api/thermal/token',
      query: {},
      body: {
        patientId: 'p001',
        medicationIds: ['m001'],
        instructions: 'Take 1 tablet every morning with water.'
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(tokenRes.status, 200);
    assert.ok(tokenRes.body.token);
    assert.ok(tokenRes.body.url.includes('/verify-refill?token='));
    // Ensure no patient name or sensitive diagnosis in the URL
    assert.equal(tokenRes.body.url.includes('Ahmed'), false);

    // Verify token endpoint
    const verifyRes = await handleApiRoute({
      method: 'GET',
      path: '/api/thermal/verify',
      query: { token: tokenRes.body.token },
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(verifyRes.status, 200);
    assert.equal(verifyRes.body.expired, false);
    assert.ok(verifyRes.body.medications.length > 0);
  });

  test('8. Inventory demand forecasting flags projected stockouts', async () => {
    const forecastRes = await handleApiRoute({
      method: 'GET',
      path: '/api/inventory/forecast',
      query: { days: '14' },
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(forecastRes.status, 200);
    assert.ok(Array.isArray(forecastRes.body));
    const jardiance = forecastRes.body.find(i => i.drugName.includes('Jardiance'));
    assert.ok(jardiance);
    assert.ok(typeof jardiance.forecast14d === 'number');
  });

  test('9. Settings Reminder Interval update recalculates schedules', async () => {
    const updateSettingsRes = await handleApiRoute({
      method: 'PUT',
      path: '/api/settings',
      query: {},
      body: {
        reminderIntervalDays: 5
      },
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(updateSettingsRes.status, 200);
    assert.equal(updateSettingsRes.body.reminderIntervalDays, 5);
  });

  test('10. Soft deletion preserves record with isDeleted flag', async () => {
    const p = repository.createPatient({
      firstName: 'Archived',
      lastName: 'Patient',
      phoneNumber: '+9647709999999'
    }, 'Pharmacist');

    const deleteRes = await handleApiRoute({
      method: 'DELETE',
      path: `/api/patients/${p.id}`,
      query: {},
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(deleteRes.status, 200);
    assert.equal(deleteRes.body.success, true);

    // Verify excluded from default list
    const listRes = await handleApiRoute({
      method: 'GET',
      path: '/api/patients',
      query: { search: 'Archived' },
      body: null,
      headers: {},
      user: { id: 'test', name: 'Pharmacist', role: 'pharmacist' }
    });

    assert.equal(listRes.body.data.length, 0);
  });
});
