import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { repository } from '../server/repository';

describe('Scale Test: 3,000+ Chronic Patient Records Benchmark', () => {
  test('Comfortably populates and queries 3,000+ patient records with sub-50ms response', async () => {
    repository.init();

    console.log('Generating 3,000 patient records for scale testing...');
    const startTime = Date.now();

    const familyCodes = ['FAM-BAGHDAD-1', 'FAM-BAGHDAD-2', 'FAM-BAGHDAD-3', 'FAM-KARRADA-1', 'FAM-MANSOUR-1'];
    const drugs = ['Amlodipine 5mg', 'Metformin XR 500mg', 'Atorvastatin 20mg', 'Jardiance 10mg', 'Losartan 50mg'];

    // Generate 3,000 patients
    const records = [];
    for (let i = 1; i <= 3000; i++) {
      records.push({
        id: `scale_pt_${i}`,
        fileNumber: `RX-SCALE-${String(i).padStart(5, '0')}`,
        firstName: `Patient${i}`,
        lastName: `Al-Iraqi${i % 50}`,
        dateOfBirth: '1970-01-01',
        gender: i % 2 === 0 ? 'Female' : 'Male',
        phoneNumber: `+964770${String(1000000 + i).slice(0, 7)}`,
        whatsappNumber: `+964770${String(1000000 + i).slice(0, 7)}`,
        familyCode: familyCodes[i % familyCodes.length],
        preferredChannel: 'WhatsApp',
        chronicConditions: ['Hypertension', 'Type 2 Diabetes'],
        allergies: i % 10 === 0 ? 'Penicillin' : 'None reported',
        retentionStatus: i % 15 === 0 ? 'at_risk' : i % 30 === 0 ? 'inactive' : 'retained',
        retentionScore: i % 15 === 0 ? 65.0 : 95.0,
        optedOut: i % 50 === 0,
        isDeleted: false,
        createdAt: '2026-01-01T00:00:00.000Z',
        updatedAt: '2026-01-01T00:00:00.000Z'
      });
    }

    // Inject into repository in memory
    (repository as any).data.patients = [...(repository as any).data.patients, ...records];

    const genTime = Date.now() - startTime;
    console.log(`Generated 3,000 records in ${genTime}ms`);

    // 1. Benchmark: Paginated query on 3,000+ records
    const t0 = performance.now();
    const page1 = repository.getPatients({ page: 1, pageSize: 20 });
    const queryTime = performance.now() - t0;

    assert.equal(page1.data.length, 20);
    assert.ok(page1.total >= 3000);
    assert.ok(queryTime < 50, `Pagination took ${queryTime.toFixed(2)}ms (expected < 50ms)`);

    // 2. Benchmark: Global Search by Name across 3,000+ records
    const t1 = performance.now();
    const searchRes = repository.getPatients({ search: 'Patient2500', pageSize: 10 });
    const searchTime = performance.now() - t1;

    assert.equal(searchRes.data.length, 1);
    assert.equal(searchRes.data[0].firstName, 'Patient2500');
    assert.ok(searchTime < 50, `Search took ${searchTime.toFixed(2)}ms (expected < 50ms)`);

    // 3. Benchmark: Filter by Family Code across 3,000+ records
    const t2 = performance.now();
    const famRes = repository.getPatients({ familyCode: 'FAM-BAGHDAD-1', pageSize: 15 });
    const famTime = performance.now() - t2;

    assert.ok(famRes.total >= 600);
    assert.ok(famTime < 50, `Family filter took ${famTime.toFixed(2)}ms (expected < 50ms)`);

    // 4. Benchmark: Dashboard Metrics calculation across 3,000+ records
    const t3 = performance.now();
    const metrics = repository.getDashboardMetrics();
    const metricsTime = performance.now() - t3;

    assert.ok(metrics.totalActivePatients >= 3000);
    assert.ok(metricsTime < 50, `Dashboard metrics took ${metricsTime.toFixed(2)}ms (expected < 50ms)`);

    console.log(`✅ All scale benchmarks passed: Pagination: ${queryTime.toFixed(2)}ms, Search: ${searchTime.toFixed(2)}ms, Family filter: ${famTime.toFixed(2)}ms, Metrics: ${metricsTime.toFixed(2)}ms.`);
  });
});
