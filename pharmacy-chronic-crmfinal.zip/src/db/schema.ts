import { pgTable, uuid, varchar, text, date, timestamp, integer, boolean, numeric, jsonb, index } from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

// 1. PATIENTS
export const patients = pgTable('patients', {
  id: uuid('id').primaryKey().defaultRandom(),
  fileNumber: varchar('file_number', { length: 50 }).notNull().unique(),
  firstName: varchar('first_name', { length: 100 }).notNull(),
  lastName: varchar('last_name', { length: 100 }).notNull(),
  dateOfBirth: date('date_of_birth').notNull(),
  gender: varchar('gender', { length: 20 }).notNull().default('Other'), // 'Male' | 'Female' | 'Other'
  phoneNumber: varchar('phone_number', { length: 30 }).notNull(), // normalized international format (+964...)
  whatsappNumber: varchar('whatsapp_number', { length: 30 }).notNull(),
  address: text('address'),
  familyCode: varchar('family_code', { length: 50 }), // Links family members without merging profiles
  emergencyContactName: varchar('emergency_contact_name', { length: 100 }),
  emergencyContactPhone: varchar('emergency_contact_phone', { length: 30 }),
  primaryPhysician: varchar('primary_physician', { length: 100 }),
  physicianPhone: varchar('physician_phone', { length: 30 }),
  preferredChannel: varchar('preferred_channel', { length: 20 }).notNull().default('WhatsApp'),
  chronicConditions: jsonb('chronic_conditions').$type<string[]>().default(sql`'[]'::jsonb`),
  allergies: text('allergies').default('None reported'),
  retentionStatus: varchar('retention_status', { length: 30 }).notNull().default('retained'), // 'retained' | 'at_risk' | 'inactive'
  retentionScore: numeric('retention_score', { precision: 5, scale: 2 }).default('95.00'), // Adherence proxy percentage
  retentionReason: text('retention_reason'),
  retentionUpdatedAt: timestamp('retention_updated_at', { withTimezone: true }).defaultNow(),
  photoUrl: text('photo_url'), // Storage object key, never public URL
  optedOut: boolean('opted_out').notNull().default(false), // Communication consent
  isDeleted: boolean('is_deleted').notNull().default(false), // Soft deletion
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
  notes: text('notes'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    fileNumberIdx: index('idx_patients_file_number').on(table.fileNumber),
    phoneNumberIdx: index('idx_patients_phone').on(table.phoneNumber),
    familyCodeIdx: index('idx_patients_family_code').on(table.familyCode),
    nameIdx: index('idx_patients_names').on(table.lastName, table.firstName),
    isDeletedIdx: index('idx_patients_deleted').on(table.isDeleted),
  };
});

// 2. MEDICATIONS (Multiple per patient)
export const medications = pgTable('medications', {
  id: uuid('id').primaryKey().defaultRandom(),
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  drugName: varchar('drug_name', { length: 200 }).notNull(),
  strength: varchar('strength', { length: 100 }).notNull(),
  dosageInstructions: text('dosage_instructions').notNull(),
  purchaseDate: date('purchase_date').notNull(), // Editable via date picker
  daysSupply: integer('days_supply').notNull(), // Positive integer
  nextRefillDate: date('next_refill_date').notNull(), // purchaseDate + daysSupply
  nextReminderDate: date('next_reminder_date').notNull(), // nextRefillDate - reminderInterval
  refillStatus: varchar('refill_status', { length: 30 }).notNull().default('active'), // 'active' | 'due_soon' | 'due_today' | 'overdue' | 'completed' | 'discontinued'
  refillsAuthorized: integer('refills_authorized').default(6),
  refillsRemaining: integer('refills_remaining').default(5),
  quantityPerRefill: integer('quantity_per_refill').default(30),
  prescribingDoctor: varchar('prescribing_doctor', { length: 100 }),
  notes: text('notes'),
  isDeleted: boolean('is_deleted').notNull().default(false),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    patientIdIdx: index('idx_medications_patient').on(table.patientId),
    drugNameIdx: index('idx_medications_drug_name').on(table.drugName),
    nextRefillIdx: index('idx_medications_next_refill').on(table.nextRefillDate),
    nextReminderIdx: index('idx_medications_next_reminder').on(table.nextReminderDate),
    statusIdx: index('idx_medications_status').on(table.refillStatus),
    deletedIdx: index('idx_medications_deleted').on(table.isDeleted),
  };
});

// 3. REFILL AUDIT LOGS (Immutable dispense history)
export const refillAuditLogs = pgTable('refill_audit_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  medicationId: uuid('medication_id').notNull().references(() => medications.id, { onDelete: 'cascade' }),
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  action: varchar('action', { length: 50 }).notNull(), // 'dispense' | 'update_supply' | 'discontinue'
  previousPurchaseDate: date('previous_purchase_date'),
  newPurchaseDate: date('new_purchase_date').notNull(),
  previousDaysSupply: integer('previous_days_supply'),
  newDaysSupply: integer('new_days_supply').notNull(),
  quantityDispensed: integer('quantity_dispensed').notNull(),
  performedBy: varchar('performed_by', { length: 100 }).notNull(),
  refillCompliance: varchar('refill_compliance', { length: 30 }).default('On Time'), // 'Early' | 'On Time' | 'Late'
  notes: text('notes'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    patientIdIdx: index('idx_refill_audit_patient').on(table.patientId),
    medicationIdIdx: index('idx_refill_audit_med').on(table.medicationId),
    createdAtIdx: index('idx_refill_audit_created').on(table.createdAt),
  };
});

// 4. ANTIBIOTIC FOLLOW-UP
export const antibioticFollowups = pgTable('antibiotic_followups', {
  id: uuid('id').primaryKey().defaultRandom(),
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  antibioticName: varchar('antibiotic_name', { length: 200 }).notNull(),
  dosageAndDuration: varchar('dosage_and_duration', { length: 200 }).notNull(), // e.g. "Amoxicillin 500mg TID for 7 days"
  startDate: date('start_date').notNull(),
  expectedFollowupDate: date('expected_followup_date').notNull(),
  contactAttempts: integer('contact_attempts').notNull().default(0),
  lastContactDate: date('last_contact_date'),
  patientReportedProgress: varchar('patient_reported_progress', { length: 50 }).default('pending'), // 'improving' | 'no_change' | 'worsened' | 'adverse_reaction' | 'completed_course'
  status: varchar('status', { length: 30 }).notNull().default('pending'), // 'pending' | 'due_today' | 'overdue' | 'completed' | 'lost_to_followup'
  pharmacistNotes: text('pharmacist_notes'),
  disclaimerAcknowledged: boolean('disclaimer_acknowledged').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    patientIdx: index('idx_antibiotic_patient').on(table.patientId),
    followupDateIdx: index('idx_antibiotic_date').on(table.expectedFollowupDate),
    statusIdx: index('idx_antibiotic_status').on(table.status),
  };
});

// 5. PATIENT DOCUMENTS (Private storage metadata)
export const patientDocuments = pgTable('patient_documents', {
  id: uuid('id').primaryKey().defaultRandom(),
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  documentType: varchar('document_type', { length: 50 }).notNull(), // 'prescription' | 'lab_result' | 'discharge_summary' | 'other'
  fileName: varchar('file_name', { length: 255 }).notNull(),
  fileSize: integer('file_size').notNull(), // In bytes
  mimeType: varchar('mime_type', { length: 100 }).notNull(),
  storagePath: text('storage_path').notNull(), // Internal private object key
  notes: text('notes'),
  uploadedBy: varchar('uploaded_by', { length: 100 }).notNull(),
  isDeleted: boolean('is_deleted').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    patientIdx: index('idx_documents_patient').on(table.patientId),
    docTypeIdx: index('idx_documents_type').on(table.documentType),
  };
});

// 6. INVENTORY ITEMS & FORECASTING PARAMETERS
export const inventoryItems = pgTable('inventory_items', {
  id: uuid('id').primaryKey().defaultRandom(),
  drugName: varchar('drug_name', { length: 200 }).notNull().unique(),
  strength: varchar('strength', { length: 100 }).notNull(),
  category: varchar('category', { length: 100 }).notNull().default('General Chronic'),
  currentStock: integer('current_stock').notNull().default(0),
  minimumStockThreshold: integer('minimum_stock_threshold').notNull().default(20),
  supplierLeadTimeDays: integer('supplier_lead_time_days').notNull().default(7),
  unit: varchar('unit', { length: 50 }).notNull().default('packs'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    drugNameIdx: index('idx_inventory_drug_name').on(table.drugName),
  };
});

// 7. MESSAGE LOGS (WhatsApp / SMS audits)
export const messageLogs = pgTable('message_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  medicationId: uuid('medication_id'),
  channel: varchar('channel', { length: 20 }).notNull(), // 'whatsapp' | 'sms'
  recipientPhone: varchar('recipient_phone', { length: 30 }).notNull(),
  messageContent: text('message_content').notNull(),
  deliveryMode: varchar('delivery_mode', { length: 40 }).notNull(), // 'click_to_chat_handoff' | 'sms_handoff' | 'provider_direct'
  status: varchar('status', { length: 30 }).notNull().default('prepared'), // 'prepared' | 'handed_off' | 'sent' | 'failed'
  errorMessage: text('error_message'),
  sentBy: varchar('sent_by', { length: 100 }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    patientIdx: index('idx_messages_patient').on(table.patientId),
    createdAtIdx: index('idx_messages_created').on(table.createdAt),
  };
});

// 8. THERMAL RECEIPT TOKENS (Secure non-guessable expiring tokens for QR verification)
export const thermalReceiptTokens = pgTable('thermal_receipt_tokens', {
  id: uuid('id').primaryKey().defaultRandom(),
  token: varchar('token', { length: 64 }).notNull().unique(), // Cryptographically random
  patientId: uuid('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  medicationIds: jsonb('medication_ids').$type<string[]>().notNull(),
  instructions: text('instructions'),
  pharmacyName: varchar('pharmacy_name', { length: 150 }).notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  accessCount: integer('access_count').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    tokenIdx: index('idx_thermal_token').on(table.token),
    expiresIdx: index('idx_thermal_expires').on(table.expiresAt),
  };
});

// 9. SYSTEM SETTINGS
export const systemSettings = pgTable('system_settings', {
  key: varchar('key', { length: 100 }).primaryKey(),
  value: jsonb('value').notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
  updatedBy: varchar('updated_by', { length: 100 }).default('System'),
});

// 10. AUDIT TRAIL LOGS
export const auditTrailLogs = pgTable('audit_trail_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  entityType: varchar('entity_type', { length: 50 }).notNull(), // 'patient' | 'medication' | 'settings' | 'import' | 'export'
  entityId: varchar('entity_id', { length: 100 }).notNull(),
  action: varchar('action', { length: 50 }).notNull(), // 'create' | 'update' | 'soft_delete' | 'export' | 'import'
  performedBy: varchar('performed_by', { length: 100 }).notNull(),
  details: jsonb('details'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => {
  return {
    entityIdx: index('idx_audit_entity').on(table.entityType, table.entityId),
    createdAtIdx: index('idx_audit_created').on(table.createdAt),
  };
});
