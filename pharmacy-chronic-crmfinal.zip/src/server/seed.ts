import postgres from 'postgres';
import { INITIAL_PATIENTS, INITIAL_MEDICATIONS, INITIAL_ANTIBIOTIC_FOLLOWUPS, INITIAL_INVENTORY_ITEMS } from './seedData';

async function seedDatabase() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.log('ℹ No DATABASE_URL specified. Local store will automatically seed on startup.');
    process.exit(0);
  }

  console.log('🌱 Seeding PostgreSQL database with realistic fictional chronic patient data...');
  const sql = postgres(dbUrl, { max: 1 });

  try {
    for (const p of INITIAL_PATIENTS) {
      await sql`
        INSERT INTO patients (
          id, file_number, first_name, last_name, date_of_birth, gender,
          phone_number, whatsapp_number, address, family_code, emergency_contact_name,
          emergency_contact_phone, primary_physician, physician_phone, preferred_channel,
          chronic_conditions, allergies, retention_status, retention_score, retention_reason,
          opted_out, is_deleted, notes
        ) VALUES (
          gen_random_uuid(), ${p.fileNumber}, ${p.firstName}, ${p.lastName}, ${p.dateOfBirth}::date, ${p.gender},
          ${p.phoneNumber}, ${p.whatsappNumber}, ${p.address || ''}, ${p.familyCode || null}, ${p.emergencyContactName || ''},
          ${p.emergencyContactPhone || ''}, ${p.primaryPhysician || ''}, ${p.physicianPhone || ''}, ${p.preferredChannel},
          ${JSON.stringify(p.chronicConditions)}::jsonb, ${p.allergies}, ${p.retentionStatus}, ${p.retentionScore}, ${p.retentionReason || ''},
          ${p.optedOut}, false, ${p.notes || ''}
        ) ON CONFLICT (file_number) DO NOTHING;
      `;
    }
    console.log('✅ Seeding complete!');
  } catch (err) {
    console.error('❌ Seeding failed:', err);
    process.exit(1);
  } finally {
    await sql.end();
  }
}

seedDatabase();
