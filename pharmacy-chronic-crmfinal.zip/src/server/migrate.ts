import fs from 'fs';
import path from 'path';
import postgres from 'postgres';

async function runMigration() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.log('ℹ No DATABASE_URL specified. Migration step skipped (using local demo repository).');
    process.exit(0);
  }

  console.log('🚀 Running PostgreSQL database migration on hosted instance...');
  const sql = postgres(dbUrl, { max: 1 });

  try {
    const migrationFile = path.resolve(process.cwd(), 'drizzle/0000_initial_schema.sql');
    if (!fs.existsSync(migrationFile)) {
      throw new Error(`Migration file not found at ${migrationFile}`);
    }

    const migrationSql = fs.readFileSync(migrationFile, 'utf-8');
    await sql.unsafe(migrationSql);
    console.log('✅ PostgreSQL schema and indexes successfully migrated!');
  } catch (err) {
    console.error('❌ Migration failed:', err);
    process.exit(1);
  } finally {
    await sql.end();
  }
}

runMigration();
