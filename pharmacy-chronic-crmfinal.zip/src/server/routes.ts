import { repository } from './repository';
import { savePrivateFile, generateExpiringDownloadUrl, getFileByToken, deletePrivateFile } from './storage';
import { formatTemplateMessage, normalizePhoneNumber } from '../lib/calculations';
import * as XLSX from 'xlsx';

export interface RequestContext {
  method: string;
  path: string;
  query: Record<string, string>;
  body: any;
  headers: Record<string, string>;
  user: { id: string; name: string; role: 'admin' | 'pharmacist' | 'staff' };
}

export interface RouteResponse {
  status: number;
  body: any;
  headers?: Record<string, string>;
  isRaw?: boolean;
}

export async function handleApiRoute(req: RequestContext): Promise<RouteResponse> {
  const { method, path: rawPath, query, body, user } = req;
  const path = rawPath.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');

  try {
    // 1. SYSTEM DATABASE STATUS TEST (Server-side check without credential exposure or SSRF)
    if (method === 'GET' && path === '/system/db-status') {
      const status = await repository.testDatabaseConnection();
      return { status: 200, body: status };
    }

    // 2. DASHBOARD METRICS
    if (method === 'GET' && path === '/dashboard/metrics') {
      const metrics = repository.getDashboardMetrics();
      return { status: 200, body: metrics };
    }

    // 3. PATIENTS LIST & PAGINATION
    if (method === 'GET' && path === '/patients') {
      const result = repository.getPatients({
        page: query.page ? Number(query.page) : 1,
        pageSize: query.pageSize ? Number(query.pageSize) : 15,
        search: query.search,
        status: query.status,
        familyCode: query.familyCode,
        drugName: query.drugName,
        sortField: query.sortField as any,
        sortOrder: query.sortOrder as any
      });
      return { status: 200, body: result };
    }

    // 4. SINGLE PATIENT DOSSIER
    if (method === 'GET' && path.match(/^\/patients\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const patient = repository.getPatientById(id);
      if (!patient) return { status: 404, body: { error: 'Patient not found' } };
      return { status: 200, body: patient };
    }

    // 5. CREATE PATIENT
    if (method === 'POST' && path === '/patients') {
      if (!body.firstName || !body.lastName || !body.phoneNumber) {
        return { status: 400, body: { error: 'First name, last name, and phone number are required.' } };
      }
      const newPatient = repository.createPatient(body, user.name);
      return { status: 201, body: newPatient };
    }

    // 6. UPDATE PATIENT
    if (method === 'PUT' && path.match(/^\/patients\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const updated = repository.updatePatient(id, body, user.name);
      return { status: 200, body: updated };
    }

    // 7. SOFT DELETE PATIENT
    if (method === 'DELETE' && path.match(/^\/patients\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const ok = repository.softDeletePatient(id, user.name);
      if (!ok) return { status: 404, body: { error: 'Patient not found' } };
      return { status: 200, body: { success: true, message: 'Patient archived safely.' } };
    }

    // 8. ADD MEDICATION TO PATIENT
    if (method === 'POST' && path.match(/^\/patients\/[a-zA-Z0-9_\-]+\/medications$/)) {
      const patientId = path.split('/')[2];
      if (!body.drugName || !body.daysSupply) {
        return { status: 400, body: { error: 'Drug name and days supply are required.' } };
      }
      const med = repository.addMedication(patientId, body, user.name);
      return { status: 201, body: med };
    }

    // 9. UPDATE MEDICATION
    if (method === 'PUT' && path.match(/^\/medications\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const updated = repository.updateMedication(id, body, user.name);
      return { status: 200, body: updated };
    }

    // 10. RECORD REFILL (Dispense)
    if (method === 'POST' && path === '/refills') {
      if (!body.medicationId || !body.daysSupply) {
        return { status: 400, body: { error: 'Medication ID and days supply are required.' } };
      }
      const result = repository.recordRefill({
        medicationId: body.medicationId,
        purchaseDate: body.purchaseDate,
        daysSupply: Number(body.daysSupply),
        quantityDispensed: Number(body.quantityDispensed) || 30,
        performedBy: user.name,
        notes: body.notes
      });
      return { status: 200, body: result };
    }

    // 11. GET REFILLS DUE ON SELECTED DATE (Bulk Refill Workbench)
    if (method === 'GET' && path === '/refills/by-date') {
      const dateStr = query.date || new Date().toISOString().split('T')[0];
      const items = repository.getMedicationsByDate(dateStr);
      return { status: 200, body: items };
    }

    // 12. ANTIBIOTIC FOLLOW-UPS
    if (method === 'GET' && path === '/antibiotics') {
      const result = repository.getAntibioticFollowups({
        status: query.status,
        search: query.search,
        page: query.page ? Number(query.page) : 1,
        pageSize: query.pageSize ? Number(query.pageSize) : 10
      });
      return { status: 200, body: result };
    }

    if (method === 'POST' && path === '/antibiotics') {
      if (!body.antibioticName || !body.startDate || !body.expectedFollowupDate) {
        return { status: 400, body: { error: 'Antibiotic name, start date, and follow-up date are required.' } };
      }
      const created = repository.createAntibioticFollowup(body, user.name);
      return { status: 201, body: created };
    }

    if (method === 'PUT' && path.match(/^\/antibiotics\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const updated = repository.updateAntibioticFollowup(id, body, user.name);
      return { status: 200, body: updated };
    }

    // 13. INVENTORY FORECAST & DEMAND
    if (method === 'GET' && path === '/inventory/forecast') {
      const planningDays = query.days ? Number(query.days) : 30;
      const forecast = repository.getInventoryForecast(planningDays);
      return { status: 200, body: forecast };
    }

    if (method === 'PUT' && path.match(/^\/inventory\/[a-zA-Z0-9_\-]+$/)) {
      const id = path.split('/')[2];
      const updated = repository.updateInventoryStock(id, body, user.name);
      return { status: 200, body: updated };
    }

    // 14. SETTINGS
    if (method === 'GET' && path === '/settings') {
      const settings = repository.getSettings();
      return { status: 200, body: settings };
    }

    if (method === 'PUT' && path === '/settings') {
      const updated = repository.updateSettings(body, user.name);
      return { status: 200, body: updated };
    }

    // 15. THERMAL RECEIPT EXPIRING TOKEN
    if (method === 'POST' && path === '/thermal/token') {
      if (!body.patientId || !body.medicationIds || body.medicationIds.length === 0) {
        return { status: 400, body: { error: 'Patient ID and medication IDs are required.' } };
      }
      const tokenData = repository.createThermalSlipToken({
        patientId: body.patientId,
        medicationIds: body.medicationIds,
        instructions: body.instructions
      });
      return { status: 200, body: tokenData };
    }

    if (method === 'GET' && path === '/thermal/verify') {
      const token = query.token;
      if (!token) return { status: 400, body: { error: 'Token required' } };
      const receipt = repository.getThermalSlipByToken(token);
      if (!receipt) return { status: 404, body: { error: 'Invalid prescription verification token' } };
      return { status: 200, body: receipt };
    }

    // 16. MESSAGES (WhatsApp / SMS workflow)
    if (method === 'POST' && path === '/messages/send') {
      const { patientId, medicationId, channel, customMessage } = body;
      const patient = repository.getPatientById(patientId);
      if (!patient) return { status: 404, body: { error: 'Patient not found' } };

      if (patient.optedOut) {
        return { status: 403, body: { error: 'Patient has opted out of notifications. Action blocked.' } };
      }

      const settings = repository.getSettings();
      const phoneNorm = normalizePhoneNumber(channel === 'whatsapp' ? patient.whatsappNumber : patient.phoneNumber);
      const phone = phoneNorm.normalized;

      const template = channel === 'whatsapp' ? settings.whatsappTemplate : settings.smsTemplate;
      const med = patient.medications.find(m => m.id === medicationId) || patient.medications[0];

      const finalMessage = customMessage || formatTemplateMessage(template, {
        patient_name: `${patient.firstName} ${patient.lastName}`,
        medications: med ? med.drugName : 'prescriptions',
        due_date: med ? med.nextRefillDate : '',
        pharmacy_name: settings.pharmacyName,
        pharmacy_phone: settings.contactPhone
      });

      // Safe Click-to-chat Handoff URL (strip the + for wa.me)
      const waNumber = phone.replace(/^\+/, '');
      const waLink = `https://wa.me/${waNumber}?text=${encodeURIComponent(finalMessage)}`;
      const smsLink = `sms:${phone}?body=${encodeURIComponent(finalMessage)}`;

      // Log communication record
      const log = repository.logMessage({
        patientId,
        medicationId: med?.id,
        channel,
        recipientPhone: phone,
        messageContent: finalMessage,
        deliveryMode: channel === 'whatsapp' ? 'click_to_chat_handoff' : 'sms_handoff',
        status: 'handed_off',
        sentBy: user.name
      });

      return {
        status: 200,
        body: {
          success: true,
          message: finalMessage,
          link: channel === 'whatsapp' ? waLink : smsLink,
          channel,
          phone,
          logId: log.id
        }
      };
    }

    // 17. REPORTS EXPORT (CSV / XLSX with Formula Injection Sanitization)
    if (method === 'GET' && path === '/export') {
      const type = (query.type || 'patients') as 'patients' | 'refills' | 'inventory';
      const format = query.format || 'xlsx';
      const data = repository.getExportData(type);

      const worksheet = XLSX.utils.json_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, type.toUpperCase());

      if (format === 'csv') {
        const csv = XLSX.utils.sheet_to_csv(worksheet);
        return {
          status: 200,
          body: csv,
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="pharmacy_${type}_${Date.now()}.csv"`
          },
          isRaw: true
        };
      }

      const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
      return {
        status: 200,
        body: buffer,
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="pharmacy_${type}_${Date.now()}.xlsx"`
        },
        isRaw: true
      };
    }

    // 18. PATIENT IMPORT
    if (method === 'POST' && path === '/import/patients') {
      const rows = body.rows;
      if (!Array.isArray(rows) || rows.length === 0) {
        return { status: 400, body: { error: 'No data rows provided for import.' } };
      }
      const result = repository.importPatients(rows, user.name);
      return { status: result.success ? 200 : 422, body: result };
    }

    // 19. SECURE PHOTO UPLOAD
    if (method === 'POST' && path.match(/^\/patients\/[a-zA-Z0-9_\-]+\/photo$/)) {
      const patientId = path.split('/')[2];
      const { base64Data, originalName, mimeType } = body;

      if (!base64Data || !mimeType) {
        return { status: 400, body: { error: 'Invalid photo payload.' } };
      }

      const buffer = Buffer.from(base64Data, 'base64');
      const saved = await savePrivateFile(buffer, originalName || 'patient_photo.jpg', mimeType, true);

      // Update patient profile with private storage path
      repository.updatePatient(patientId, { photoUrl: saved.storagePath }, user.name);

      // Return expiring access token
      const downloadUrl = generateExpiringDownloadUrl(saved.storagePath, saved.mimeType);

      return { status: 200, body: { success: true, photoUrl: downloadUrl } };
    }

    // 20. STREAM PRIVATE DOCUMENT / PHOTO BY EXPIRING TOKEN
    if (method === 'GET' && path === '/documents/stream') {
      const token = query.token;
      if (!token) return { status: 400, body: { error: 'Missing access token' } };

      const fileInfo = getFileByToken(token);
      if (!fileInfo) {
        return { status: 403, body: { error: 'Access token expired or file unavailable.' } };
      }

      const fs = await import('fs');
      const buffer = await fs.promises.readFile(fileInfo.filePath);

      return {
        status: 200,
        body: buffer,
        headers: {
          'Content-Type': fileInfo.mimeType,
          'Cache-Control': 'private, no-cache, no-store'
        },
        isRaw: true
      };
    }

    return { status: 404, body: { error: `Endpoint not found: ${method} ${path}` } };
  } catch (err: any) {
    console.error('API Error:', err);
    return {
      status: 500,
      body: { error: err.message || 'Internal Server Error' }
    };
  }
}
