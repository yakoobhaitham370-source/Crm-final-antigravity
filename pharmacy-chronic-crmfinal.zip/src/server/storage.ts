import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const UPLOAD_DIR = path.resolve(process.cwd(), 'data/uploads');

// Ensure directory exists with restricted permissions
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

export const ALLOWED_PHOTO_MIMES = ['image/jpeg', 'image/png', 'image/webp'];
export const ALLOWED_DOC_MIMES = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];

export const MAX_PHOTO_SIZE_BYTES = 3 * 1024 * 1024; // 3 MB
export const MAX_DOC_SIZE_BYTES = 8 * 1024 * 1024; // 8 MB

export interface StoredFile {
  storagePath: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
}

/**
 * Validates and saves an uploaded file securely to private object storage.
 * Enforces file type and size restrictions. Never exposes file publicly.
 */
export async function savePrivateFile(
  buffer: Buffer,
  originalName: string,
  mimeType: string,
  isPhoto = false
): Promise<StoredFile> {
  const allowed = isPhoto ? ALLOWED_PHOTO_MIMES : ALLOWED_DOC_MIMES;
  const maxSize = isPhoto ? MAX_PHOTO_SIZE_BYTES : MAX_DOC_SIZE_BYTES;

  if (!allowed.includes(mimeType)) {
    throw new Error(`Invalid file type (${mimeType}). Allowed: ${allowed.join(', ')}`);
  }

  if (buffer.length > maxSize) {
    throw new Error(`File exceeds maximum allowed size of ${maxSize / (1024 * 1024)}MB.`);
  }

  // Generate non-guessable private key
  const ext = path.extname(originalName) || (mimeType === 'application/pdf' ? '.pdf' : '.jpg');
  const safeHash = crypto.randomBytes(16).toString('hex');
  const storagePath = `${Date.now()}_${safeHash}${ext}`;
  const fullPath = path.join(UPLOAD_DIR, storagePath);

  // If Supabase Storage or S3 credentials exist in environment, this can upload via S3/Supabase client
  // For local and self-contained execution, store in private protected uploads directory
  await fs.promises.writeFile(fullPath, buffer);

  return {
    storagePath,
    fileName: path.basename(originalName).replace(/[^a-zA-Z0-9_\-\.]/g, '_'),
    mimeType,
    fileSize: buffer.length
  };
}

/**
 * Generates an expiring access token for private document or photo downloads.
 */
const activeDownloadTokens = new Map<string, { storagePath: string; mimeType: string; expiresAt: number }>();

export function generateExpiringDownloadUrl(storagePath: string, mimeType: string, ttlSeconds = 3600): string {
  const token = crypto.randomBytes(32).toString('hex');
  activeDownloadTokens.set(token, {
    storagePath,
    mimeType,
    expiresAt: Date.now() + ttlSeconds * 1000
  });

  return `/api/documents/stream?token=${token}`;
}

export function getFileByToken(token: string): { filePath: string; mimeType: string } | null {
  const entry = activeDownloadTokens.get(token);
  if (!entry) return null;

  if (Date.now() > entry.expiresAt) {
    activeDownloadTokens.delete(token);
    return null;
  }

  const fullPath = path.join(UPLOAD_DIR, entry.storagePath);
  if (!fs.existsSync(fullPath)) return null;

  return { filePath: fullPath, mimeType: entry.mimeType };
}

/**
 * Deletes a private file when replaced or removed.
 */
export async function deletePrivateFile(storagePath: string): Promise<boolean> {
  try {
    const fullPath = path.join(UPLOAD_DIR, storagePath);
    if (fs.existsSync(fullPath)) {
      await fs.promises.unlink(fullPath);
      return true;
    }
  } catch (err) {
    console.error('Failed to delete private file:', err);
  }
  return false;
}
