import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { 
  Patient, 
  Medication, 
  RefillAuditLog, 
  AntibioticFollowup, 
  InventoryItem, 
  MessageLog, 
  ThermalReceiptToken, 
  PharmacySettings, 
  DashboardMetrics 
} from './types';
import { 
  INITIAL_PATIENTS, 
  INITIAL_MEDICATIONS, 
  INITIAL_ANTIBIOTIC_FOLLOWUPS, 
  INITIAL_INVENTORY_ITEMS, 
  DEFAULT_SETTINGS 
} from './seedData';
import { 
  calculateNextRefillDate, 
  calculateNextReminderDate, 
  determineRefillStatus, 
  calculateRetentionScore, 
  normalizePhoneNumber, 
  validateDaysSupply,
  sanitizeFormulaInjection 
} from '../lib/calculations';

const DATA_FILE = path.resolve(process.cwd(), 'data/pharmacy_store.json');

interface StoreData {
  patients: Patient[];
  medications: Medication[];
  refillLogs: RefillAuditLog[];
  antibioticFollowups: AntibioticFollowup[];
  inventory: InventoryItem[];
  messageLogs: MessageLog[];
  thermalTokens: ThermalReceiptToken[];
  settings: PharmacySettings;
  auditTrail: Array<{ id: string; entity: string; entityId: string; action: string; performedBy: string; timestamp: string; details?: any }>;
}

class PharmacyRepository {
  private data: StoreData;
  private initialized = false;

  constructor() {
    this.data = {
      patients: [],
      medications: [],
      refillLogs: [],
      antibioticFollowups: [],
      inventory: [],
      messageLogs: [],
      thermalTokens: [],
      settings: DEFAULT_SETTINGS,
      auditTrail: []
    };
  }

  public init() {
    if (this.initialized) return;

    try {
      const dataDir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        // Seed initial data
        this.data = {
          patients: [...INITIAL_PATIENTS],
          medications: [...INITIAL_MEDICATIONS],
          refillLogs: [],
          antibioticFollowups: [...INITIAL_ANTIBIOTIC_FOLLOWUPS],
          inventory: [...INITIAL_INVENTORY_ITEMS],
          messageLogs: [],
          thermalTokens: [],
          settings: { ...DEFAULT_SETTINGS },
          auditTrail: [{
            id: crypto.randomUUID(),
            entity: 'system',
            entityId: 'init',
            action: 'initial_seed',
            performedBy: 'System',
            timestamp: new Date().toISOString()
          }]
        };
        this.save();
      }
    } catch (e) {
      console.warn('Repository init warning:', e);
    }
    this.initialized = true;
  }

  private save() {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to persist pharmacy store:', e);
    }
  }

  private audit(entity: string, entityId: string, action: string, performedBy: string, details?: any) {
    this.data.auditTrail.unshift({
      id: crypto.randomUUID(),
      entity,
      entityId,
      action,
      performedBy,
      timestamp: new Date().toISOString(),
      details
    });
    // Keep last 1,000 audit records
    if (this.data.auditTrail.length > 1000) {
      this.data.auditTrail.pop();
    }
  }

  // =========================================================================
  // SYSTEM & DATABASE STATUS
  // =========================================================================
  public async testDatabaseConnection(): Promise<{ success: boolean; message: string; dialect: string }> {
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) {
      return {
        success: true,
        message: 'Running in Local Protected Database mode. To connect to hosted PostgreSQL (Neon/Supabase), set the DATABASE_URL environment variable in Netlify.',
        dialect: 'local_persistence'
      };
    }

    try {
      // If DATABASE_URL is set, test connection with postgres client
      const postgres = (await import('postgres')).default;
      const sql = postgres(dbUrl, { max: 1, timeout: 5 });
      await sql`SELECT 1 as connected;`;
      await sql.end();
      return {
        success: true,
        message: 'PostgreSQL connection verified successfully via server-side check.',
        dialect: 'postgresql'
      };
    } catch (err: any) {
      // Return sanitized message - never disclose connection string or credentials
      return {
        success: false,
        message: 'Could not connect to external PostgreSQL server. Please verify your DATABASE_URL in Netlify Settings.',
        dialect: 'postgresql'
      };
    }
  }

  // =========================================================================
  // PATIENTS
  // =========================================================================
  public getPatients(params: {
    page?: number;
    pageSize?: number;
    search?: string;
    status?: string;
    familyCode?: string;
    drugName?: string;
    sortField?: 'lastName' | 'fileNumber' | 'retentionScore' | 'createdAt';
    sortOrder?: 'asc' | 'desc';
  }) {
    this.init();
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = Math.min(100, Math.max(5, Number(params.pageSize) || 15));

    let list = this.data.patients.filter(p => !p.isDeleted);

    // Filter by family code
    if (params.familyCode) {
      list = list.filter(p => p.familyCode?.toLowerCase() === params.familyCode?.toLowerCase());
    }

    // Filter by status (retained / at_risk / inactive)
    if (params.status && params.status !== 'all') {
      list = list.filter(p => p.retentionStatus === params.status);
    }

    // Filter by medication name
    if (params.drugName) {
      const q = params.drugName.toLowerCase();
      const patientIdsWithDrug = new Set(
        this.data.medications
          .filter(m => !m.isDeleted && m.drugName.toLowerCase().includes(q))
          .map(m => m.patientId)
      );
      list = list.filter(p => patientIdsWithDrug.has(p.id));
    }

    // Search by name, phone, fileNumber, familyCode, or conditions
    if (params.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(p => 
        p.firstName.toLowerCase().includes(q) ||
        p.lastName.toLowerCase().includes(q) ||
        p.fileNumber.toLowerCase().includes(q) ||
        p.phoneNumber.includes(q) ||
        p.whatsappNumber.includes(q) ||
        (p.familyCode && p.familyCode.toLowerCase().includes(q)) ||
        (p.allergies && p.allergies.toLowerCase().includes(q)) ||
        p.chronicConditions.some(c => c.toLowerCase().includes(q))
      );
    }

    // Sorting
    const sortField = params.sortField || 'lastName';
    const sortOrder = params.sortOrder || 'asc';
    list.sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();
      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    const total = list.length;
    const paginated = list.slice((page - 1) * pageSize, page * pageSize);

    // Attach medications to patients in page
    const populated = paginated.map(p => {
      const meds = this.data.medications.filter(m => m.patientId === p.id && !m.isDeleted);
      return { ...p, medications: meds };
    });

    return {
      data: populated,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    };
  }

  public getPatientById(id: string): (Patient & { medications: Medication[]; refillLogs: RefillAuditLog[]; familyMembers?: Patient[] }) | null {
    this.init();
    const patient = this.data.patients.find(p => p.id === id && !p.isDeleted);
    if (!patient) return null;

    const medications = this.data.medications.filter(m => m.patientId === id && !m.isDeleted);
    const refillLogs = this.data.refillLogs.filter(l => l.patientId === id);

    let familyMembers: Patient[] = [];
    if (patient.familyCode) {
      familyMembers = this.data.patients.filter(p => 
        p.familyCode === patient.familyCode && p.id !== patient.id && !p.isDeleted
      );
    }

    return {
      ...patient,
      medications,
      refillLogs,
      familyMembers
    };
  }

  public createPatient(patientData: Partial<Patient>, performedBy: string): Patient {
    this.init();
    const normalizedPhone = normalizePhoneNumber(patientData.phoneNumber || '');
    const normalizedWhatsApp = normalizePhoneNumber(patientData.whatsappNumber || patientData.phoneNumber || '');

    const fileNumber = patientData.fileNumber || `RX-${Math.floor(1000 + Math.random() * 9000)}`;

    const newPatient: Patient = {
      id: crypto.randomUUID(),
      fileNumber,
      firstName: patientData.firstName?.trim() || '',
      lastName: patientData.lastName?.trim() || '',
      dateOfBirth: patientData.dateOfBirth || '1970-01-01',
      gender: patientData.gender || 'Other',
      phoneNumber: normalizedPhone.normalized || patientData.phoneNumber || '',
      whatsappNumber: normalizedWhatsApp.normalized || patientData.whatsappNumber || '',
      address: patientData.address || '',
      familyCode: patientData.familyCode?.trim() || undefined,
      emergencyContactName: patientData.emergencyContactName || '',
      emergencyContactPhone: patientData.emergencyContactPhone || '',
      primaryPhysician: patientData.primaryPhysician || '',
      physicianPhone: patientData.physicianPhone || '',
      preferredChannel: patientData.preferredChannel || 'WhatsApp',
      chronicConditions: patientData.chronicConditions || [],
      allergies: patientData.allergies?.trim() || 'None reported',
      retentionStatus: patientData.retentionStatus || 'retained',
      retentionScore: patientData.retentionScore || 95.0,
      retentionReason: patientData.retentionReason || 'New patient registration',
      retentionUpdatedAt: new Date().toISOString(),
      photoUrl: patientData.photoUrl || undefined,
      optedOut: Boolean(patientData.optedOut),
      isDeleted: false,
      notes: patientData.notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.patients.unshift(newPatient);
    this.audit('patient', newPatient.id, 'create', performedBy, { name: `${newPatient.firstName} ${newPatient.lastName}` });
    this.save();
    return newPatient;
  }

  public updatePatient(id: string, updates: Partial<Patient>, performedBy: string): Patient {
    this.init();
    const idx = this.data.patients.findIndex(p => p.id === id && !p.isDeleted);
    if (idx === -1) throw new Error('Patient not found');

    const current = this.data.patients[idx];

    let phone = current.phoneNumber;
    if (updates.phoneNumber) {
      phone = normalizePhoneNumber(updates.phoneNumber).normalized;
    }

    let wa = current.whatsappNumber;
    if (updates.whatsappNumber) {
      wa = normalizePhoneNumber(updates.whatsappNumber).normalized;
    }

    const updated: Patient = {
      ...current,
      ...updates,
      phoneNumber: phone,
      whatsappNumber: wa,
      updatedAt: new Date().toISOString()
    };

    this.data.patients[idx] = updated;
    this.audit('patient', id, 'update', performedBy, updates);
    this.save();
    return updated;
  }

  public softDeletePatient(id: string, performedBy: string): boolean {
    this.init();
    const idx = this.data.patients.findIndex(p => p.id === id && !p.isDeleted);
    if (idx === -1) return false;

    this.data.patients[idx].isDeleted = true;
    this.data.patients[idx].deletedAt = new Date().toISOString();

    // Soft delete associated medications
    this.data.medications.forEach(m => {
      if (m.patientId === id) {
        m.isDeleted = true;
        m.deletedAt = new Date().toISOString();
      }
    });

    this.audit('patient', id, 'soft_delete', performedBy);
    this.save();
    return true;
  }

  // =========================================================================
  // MEDICATIONS & REFILL WORKFLOW
  // =========================================================================
  public addMedication(patientId: string, medData: Partial<Medication>, performedBy: string): Medication {
    this.init();
    const patient = this.data.patients.find(p => p.id === patientId && !p.isDeleted);
    if (!patient) throw new Error('Patient not found');

    const daysSupplyValidation = validateDaysSupply(medData.daysSupply || 30);
    const daysSupply = daysSupplyValidation.value;
    const purchaseDate = medData.purchaseDate || new Date().toISOString().split('T')[0];
    const reminderInterval = this.data.settings.reminderIntervalDays || 3;

    const nextRefillDate = calculateNextRefillDate(purchaseDate, daysSupply);
    const nextReminderDate = calculateNextReminderDate(nextRefillDate, reminderInterval);
    const refillStatus = determineRefillStatus(nextRefillDate, undefined, reminderInterval);

    const newMed: Medication = {
      id: crypto.randomUUID(),
      patientId,
      drugName: medData.drugName?.trim() || 'Medication',
      strength: medData.strength?.trim() || '',
      dosageInstructions: medData.dosageInstructions?.trim() || 'As directed',
      purchaseDate,
      daysSupply,
      nextRefillDate,
      nextReminderDate,
      refillStatus,
      refillsAuthorized: Number(medData.refillsAuthorized) || 6,
      refillsRemaining: Number(medData.refillsRemaining) || 5,
      quantityPerRefill: Number(medData.quantityPerRefill) || 30,
      prescribingDoctor: medData.prescribingDoctor || '',
      notes: medData.notes || '',
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.medications.unshift(newMed);

    // Initial audit log
    const auditLog: RefillAuditLog = {
      id: crypto.randomUUID(),
      medicationId: newMed.id,
      patientId,
      action: 'medication_created',
      newPurchaseDate: purchaseDate,
      newDaysSupply: daysSupply,
      quantityDispensed: newMed.quantityPerRefill,
      performedBy,
      refillCompliance: 'Initial Dispense',
      notes: 'Initial chronic prescription registered',
      createdAt: new Date().toISOString()
    };
    this.data.refillLogs.unshift(auditLog);

    this.audit('medication', newMed.id, 'create', performedBy, { drug: newMed.drugName });
    this.save();
    return newMed;
  }

  public updateMedication(id: string, updates: Partial<Medication>, performedBy: string): Medication {
    this.init();
    const idx = this.data.medications.findIndex(m => m.id === id && !m.isDeleted);
    if (idx === -1) throw new Error('Medication not found');

    const current = this.data.medications[idx];
    const purchaseDate = updates.purchaseDate || current.purchaseDate;
    const daysSupply = updates.daysSupply ? validateDaysSupply(updates.daysSupply).value : current.daysSupply;
    const reminderInterval = this.data.settings.reminderIntervalDays || 3;

    const nextRefillDate = calculateNextRefillDate(purchaseDate, daysSupply);
    const nextReminderDate = calculateNextReminderDate(nextRefillDate, reminderInterval);
    const refillStatus = determineRefillStatus(nextRefillDate, undefined, reminderInterval);

    const updated: Medication = {
      ...current,
      ...updates,
      purchaseDate,
      daysSupply,
      nextRefillDate,
      nextReminderDate,
      refillStatus,
      updatedAt: new Date().toISOString()
    };

    this.data.medications[idx] = updated;
    this.audit('medication', id, 'update', performedBy, updates);
    this.save();
    return updated;
  }

  public recordRefill(params: {
    medicationId: string;
    purchaseDate: string;
    daysSupply: number;
    quantityDispensed: number;
    performedBy: string;
    notes?: string;
  }): { medication: Medication; auditLog: RefillAuditLog } {
    this.init();
    const med = this.data.medications.find(m => m.id === params.medicationId && !m.isDeleted);
    if (!med) throw new Error('Medication record not found');

    const { value: daysSupply } = validateDaysSupply(params.daysSupply);
    const purchaseDate = params.purchaseDate || new Date().toISOString().split('T')[0];
    const reminderInterval = this.data.settings.reminderIntervalDays || 3;

    const nextRefillDate = calculateNextRefillDate(purchaseDate, daysSupply);
    const nextReminderDate = calculateNextReminderDate(nextRefillDate, reminderInterval);
    const refillStatus = determineRefillStatus(nextRefillDate, undefined, reminderInterval);

    const previousPurchaseDate = med.purchaseDate;
    const previousDaysSupply = med.daysSupply;

    med.purchaseDate = purchaseDate;
    med.daysSupply = daysSupply;
    med.nextRefillDate = nextRefillDate;
    med.nextReminderDate = nextReminderDate;
    med.refillStatus = refillStatus;
    med.refillsRemaining = Math.max(0, (med.refillsRemaining || 1) - 1);
    med.updatedAt = new Date().toISOString();

    // Determine compliance
    let compliance = 'On Time';
    if (previousPurchaseDate) {
      const prevExpected = calculateNextRefillDate(previousPurchaseDate, previousDaysSupply);
      if (purchaseDate > prevExpected) compliance = 'Delayed';
      else if (purchaseDate < prevExpected) compliance = 'Early';
    }

    const auditLog: RefillAuditLog = {
      id: crypto.randomUUID(),
      medicationId: med.id,
      patientId: med.patientId,
      action: 'refill_dispensed',
      previousPurchaseDate,
      newPurchaseDate: purchaseDate,
      previousDaysSupply,
      newDaysSupply: daysSupply,
      quantityDispensed: Number(params.quantityDispensed) || med.quantityPerRefill,
      performedBy: params.performedBy,
      refillCompliance: compliance,
      notes: params.notes || '',
      createdAt: new Date().toISOString()
    };

    this.data.refillLogs.unshift(auditLog);

    // Re-evaluate patient retention adherence proxy score
    this.recalculatePatientRetention(med.patientId);

    this.audit('refill', med.id, 'dispense', params.performedBy, {
      medication: med.drugName,
      nextRefillDate
    });

    this.save();
    return { medication: med, auditLog };
  }

  private recalculatePatientRetention(patientId: string) {
    const patient = this.data.patients.find(p => p.id === patientId);
    if (!patient) return;

    const logs = this.data.refillLogs.filter(l => l.patientId === patientId);
    const purchases = logs.map(l => ({
      purchaseDate: l.newPurchaseDate,
      daysSupply: l.newDaysSupply
    }));

    const result = calculateRetentionScore(purchases);
    patient.retentionScore = result.score;
    patient.retentionStatus = result.status;
    patient.retentionReason = result.explanation;
    patient.retentionUpdatedAt = new Date().toISOString();
  }

  // =========================================================================
  // DASHBOARD METRICS & REFILL WORKBENCH
  // =========================================================================
  public getDashboardMetrics(): DashboardMetrics {
    this.init();
    const today = new Date().toISOString().split('T')[0];
    const reminderInterval = this.data.settings.reminderIntervalDays || 3;

    const activeMeds = this.data.medications.filter(m => !m.isDeleted && m.refillStatus !== 'discontinued');

    let dueSoonCount = 0;
    let dueTodayCount = 0;
    let overdueCount = 0;

    activeMeds.forEach(m => {
      const status = determineRefillStatus(m.nextRefillDate, today, reminderInterval);
      if (status === 'overdue') overdueCount++;
      else if (status === 'due_today') dueTodayCount++;
      else if (status === 'due_soon') dueSoonCount++;
    });

    // Completed recently (past 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const sevenDaysAgoStr = sevenDaysAgo.toISOString();
    const completedRecentlyCount = this.data.refillLogs.filter(l => l.createdAt >= sevenDaysAgoStr).length;

    // Total active patients
    const activePatients = this.data.patients.filter(p => !p.isDeleted);
    const avgAdherence = activePatients.length > 0
      ? Math.round(activePatients.reduce((acc, p) => acc + (Number(p.retentionScore) || 90), 0) / activePatients.length)
      : 90;

    // Antibiotic followups
    const pendingAntibiotics = this.data.antibioticFollowups.filter(a => a.status === 'pending' || a.status === 'due_today').length;
    const overdueAntibiotics = this.data.antibioticFollowups.filter(a => a.status === 'overdue').length;

    // Projected stock-outs
    const forecast = this.getInventoryForecast(14);
    const stockouts = forecast.filter(i => i.isStockoutProjected).length;

    return {
      totalActivePatients: activePatients.length,
      dueSoonCount,
      dueTodayCount,
      overdueCount,
      completedRecentlyCount,
      averageAdherenceRate: avgAdherence,
      pendingAntibioticFollowups: pendingAntibiotics,
      overdueAntibioticFollowups: overdueAntibiotics,
      projectedStockoutsCount: stockouts
    };
  }

  public getMedicationsByDate(dateStr: string) {
    this.init();
    const meds = this.data.medications.filter(m => !m.isDeleted && m.nextRefillDate === dateStr);
    return meds.map(m => {
      const patient = this.data.patients.find(p => p.id === m.patientId);
      return {
        ...m,
        patient
      };
    });
  }

  // =========================================================================
  // ANTIBIOTIC FOLLOW-UP WORKFLOW
  // =========================================================================
  public getAntibioticFollowups(params: { status?: string; search?: string; page?: number; pageSize?: number }) {
    this.init();
    const today = new Date().toISOString().split('T')[0];

    // Auto-update statuses based on expected followup date
    this.data.antibioticFollowups.forEach(a => {
      if (a.status !== 'completed' && a.status !== 'lost_to_followup') {
        if (a.expectedFollowupDate < today) a.status = 'overdue';
        else if (a.expectedFollowupDate === today) a.status = 'due_today';
        else a.status = 'pending';
      }
    });

    let list = [...this.data.antibioticFollowups];

    if (params.status && params.status !== 'all') {
      list = list.filter(a => a.status === params.status);
    }

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(a => 
        a.antibioticName.toLowerCase().includes(q) ||
        (a.patientName && a.patientName.toLowerCase().includes(q)) ||
        (a.patientPhone && a.patientPhone.includes(q))
      );
    }

    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = Math.min(50, Math.max(5, Number(params.pageSize) || 10));
    const total = list.length;
    const paginated = list.slice((page - 1) * pageSize, page * pageSize);

    return {
      data: paginated,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    };
  }

  public createAntibioticFollowup(data: Partial<AntibioticFollowup>, performedBy: string): AntibioticFollowup {
    this.init();
    const patient = this.data.patients.find(p => p.id === data.patientId);
    const newFollowup: AntibioticFollowup = {
      id: crypto.randomUUID(),
      patientId: data.patientId || '',
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : data.patientName,
      patientPhone: patient ? patient.phoneNumber : data.patientPhone,
      antibioticName: data.antibioticName?.trim() || 'Antibiotic',
      dosageAndDuration: data.dosageAndDuration?.trim() || 'As directed',
      startDate: data.startDate || new Date().toISOString().split('T')[0],
      expectedFollowupDate: data.expectedFollowupDate || new Date().toISOString().split('T')[0],
      contactAttempts: 0,
      patientReportedProgress: 'pending',
      status: 'pending',
      pharmacistNotes: data.pharmacistNotes || '',
      disclaimerAcknowledged: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.antibioticFollowups.unshift(newFollowup);
    this.audit('antibiotic_followup', newFollowup.id, 'create', performedBy);
    this.save();
    return newFollowup;
  }

  public updateAntibioticFollowup(id: string, updates: Partial<AntibioticFollowup>, performedBy: string): AntibioticFollowup {
    this.init();
    const idx = this.data.antibioticFollowups.findIndex(a => a.id === id);
    if (idx === -1) throw new Error('Antibiotic follow-up record not found');

    const updated = {
      ...this.data.antibioticFollowups[idx],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.data.antibioticFollowups[idx] = updated;
    this.audit('antibiotic_followup', id, 'update', performedBy, updates);
    this.save();
    return updated;
  }

  // =========================================================================
  // INVENTORY DEMAND FORECASTING ENGINE
  // =========================================================================
  public getInventoryForecast(planningDays = 30) {
    this.init();
    const today = new Date().toISOString().split('T')[0];
    const todayDate = new Date();

    const endDate = new Date();
    endDate.setDate(todayDate.getDate() + planningDays);
    const endDateStr = endDate.toISOString().split('T')[0];

    // Group projected demand by drug name
    const demand7d: Record<string, number> = {};
    const demand14d: Record<string, number> = {};
    const demand30d: Record<string, number> = {};

    const activeMeds = this.data.medications.filter(m => !m.isDeleted && m.refillStatus !== 'discontinued');

    activeMeds.forEach(m => {
      // Exclude inconsistent medication data with explanation
      if (!m.daysSupply || m.daysSupply <= 0 || !m.nextRefillDate) {
        return;
      }

      const refillDate = m.nextRefillDate;
      const drug = m.drugName.trim();
      const qty = m.quantityPerRefill || 30;

      // Project next refill within horizon
      if (refillDate >= today && refillDate <= endDateStr) {
        const diffDays = Math.round((new Date(refillDate).getTime() - todayDate.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays <= 7) {
          demand7d[drug] = (demand7d[drug] || 0) + qty;
        }
        if (diffDays <= 14) {
          demand14d[drug] = (demand14d[drug] || 0) + qty;
        }
        if (diffDays <= 30) {
          demand30d[drug] = (demand30d[drug] || 0) + qty;
        }
      }
    });

    // Merge with inventory items
    return this.data.inventory.map(item => {
      const drug = item.drugName.trim();
      const d7 = demand7d[drug] || 0;
      const d14 = demand14d[drug] || 0;
      const d30 = demand30d[drug] || 0;

      const isStockout = item.currentStock < d14 || item.currentStock <= item.minimumStockThreshold;

      return {
        ...item,
        forecast7d: d7,
        forecast14d: d14,
        forecast30d: d30,
        isStockoutProjected: isStockout,
        projectedStockoutDate: isStockout ? 'Within 7-14 days' : 'Adequate'
      };
    });
  }

  public updateInventoryStock(id: string, updates: Partial<InventoryItem>, performedBy: string): InventoryItem {
    this.init();
    const idx = this.data.inventory.findIndex(i => i.id === id);
    if (idx === -1) throw new Error('Inventory item not found');

    const updated = {
      ...this.data.inventory[idx],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    this.data.inventory[idx] = updated;
    this.audit('inventory', id, 'update', performedBy, updates);
    this.save();
    return updated;
  }

  // =========================================================================
  // SETTINGS & CONFIGURATION
  // =========================================================================
  public getSettings(): PharmacySettings {
    this.init();
    return {
      ...this.data.settings,
      databaseConfigured: Boolean(process.env.DATABASE_URL),
      hasMessagingCredentials: Boolean(process.env.WHATSAPP_API_TOKEN || process.env.TWILIO_ACCOUNT_SID),
      storageConfigured: Boolean(process.env.STORAGE_BUCKET_NAME || process.env.SUPABASE_URL)
    };
  }

  public updateSettings(updates: Partial<PharmacySettings>, performedBy: string): PharmacySettings {
    this.init();
    const previousInterval = this.data.settings.reminderIntervalDays;
    const newInterval = updates.reminderIntervalDays ? Math.max(1, Number(updates.reminderIntervalDays)) : previousInterval;

    this.data.settings = {
      ...this.data.settings,
      ...updates,
      reminderIntervalDays: newInterval
    };

    // If reminder interval changed, recalculate all active medications
    if (newInterval !== previousInterval) {
      const today = new Date().toISOString().split('T')[0];
      this.data.medications.forEach(m => {
        if (!m.isDeleted) {
          m.nextReminderDate = calculateNextReminderDate(m.nextRefillDate, newInterval);
          m.refillStatus = determineRefillStatus(m.nextRefillDate, today, newInterval);
        }
      });
    }

    this.audit('settings', 'global', 'update', performedBy, updates);
    this.save();
    return this.getSettings();
  }

  // =========================================================================
  // SECURE EXPIRING THERMAL RECEIPT TOKENS
  // =========================================================================
  public createThermalSlipToken(params: {
    patientId: string;
    medicationIds: string[];
    instructions?: string;
  }): { token: string; url: string; expiresAt: string } {
    this.init();
    const token = crypto.randomBytes(24).toString('hex');
    const expires = new Date();
    expires.setDate(expires.getDate() + 7); // 7-day expiration

    const receipt: ThermalReceiptToken = {
      id: crypto.randomUUID(),
      token,
      patientId: params.patientId,
      medicationIds: params.medicationIds,
      instructions: params.instructions || '',
      pharmacyName: this.data.settings.pharmacyName,
      expiresAt: expires.toISOString(),
      accessCount: 0,
      createdAt: new Date().toISOString()
    };

    this.data.thermalTokens.push(receipt);
    this.save();

    return {
      token,
      url: `/verify-refill?token=${token}`,
      expiresAt: receipt.expiresAt
    };
  }

  public getThermalSlipByToken(token: string) {
    this.init();
    const receipt = this.data.thermalTokens.find(t => t.token === token);
    if (!receipt) return null;

    if (new Date().toISOString() > receipt.expiresAt) {
      return { expired: true, message: 'This prescription verification link has expired.' };
    }

    receipt.accessCount++;
    this.save();

    const patient = this.data.patients.find(p => p.id === receipt.patientId);
    const medications = this.data.medications.filter(m => receipt.medicationIds.includes(m.id));

    // Return minimum necessary info - NO full medical history or sensitive data
    return {
      expired: false,
      pharmacyName: receipt.pharmacyName,
      verificationId: receipt.token.slice(0, 10).toUpperCase(),
      patientName: patient ? `${patient.firstName} ${patient.lastName.slice(0, 1)}.` : 'Patient', // Privacy masking
      refillDate: new Date().toISOString().split('T')[0],
      medications: medications.map(m => ({
        drugName: m.drugName,
        strength: m.strength,
        dosageInstructions: m.dosageInstructions,
        nextRefillDate: m.nextRefillDate
      })),
      instructions: receipt.instructions,
      expiresAt: receipt.expiresAt
    };
  }

  // =========================================================================
  // MESSAGE LOGGING & OPT-OUT ENFORCEMENT
  // =========================================================================
  public logMessage(params: {
    patientId: string;
    medicationId?: string;
    channel: 'whatsapp' | 'sms';
    recipientPhone: string;
    messageContent: string;
    deliveryMode: 'click_to_chat_handoff' | 'sms_handoff' | 'provider_direct';
    status: 'prepared' | 'handed_off' | 'sent' | 'failed';
    errorMessage?: string;
    sentBy: string;
  }): MessageLog {
    this.init();
    const patient = this.data.patients.find(p => p.id === params.patientId);
    if (patient?.optedOut) {
      throw new Error('Patient has opted out of notifications. Automated or manual messaging is blocked.');
    }

    const log: MessageLog = {
      id: crypto.randomUUID(),
      ...params,
      createdAt: new Date().toISOString()
    };

    this.data.messageLogs.unshift(log);
    this.audit('communication', log.id, 'send', params.sentBy, { channel: params.channel, recipient: params.recipientPhone });
    this.save();
    return log;
  }

  // =========================================================================
  // EXPORT REPORTS WITH FORMULA INJECTION DEFENSE
  // =========================================================================
  public getExportData(type: 'patients' | 'refills' | 'inventory') {
    this.init();
    if (type === 'patients') {
      return this.data.patients.filter(p => !p.isDeleted).map(p => ({
        FileNumber: sanitizeFormulaInjection(p.fileNumber),
        FirstName: sanitizeFormulaInjection(p.firstName),
        LastName: sanitizeFormulaInjection(p.lastName),
        Phone: sanitizeFormulaInjection(p.phoneNumber),
        FamilyCode: sanitizeFormulaInjection(p.familyCode || ''),
        Conditions: sanitizeFormulaInjection(p.chronicConditions.join(', ')),
        Allergies: sanitizeFormulaInjection(p.allergies),
        RetentionStatus: sanitizeFormulaInjection(p.retentionStatus),
        AdherenceScore: p.retentionScore,
        RegisteredDate: p.createdAt.split('T')[0]
      }));
    }

    if (type === 'refills') {
      return this.data.medications.filter(m => !m.isDeleted).map(m => {
        const patient = this.data.patients.find(p => p.id === m.patientId);
        return {
          PatientName: sanitizeFormulaInjection(patient ? `${patient.firstName} ${patient.lastName}` : ''),
          FileNumber: sanitizeFormulaInjection(patient?.fileNumber || ''),
          DrugName: sanitizeFormulaInjection(m.drugName),
          Strength: sanitizeFormulaInjection(m.strength),
          Dosage: sanitizeFormulaInjection(m.dosageInstructions),
          PurchaseDate: m.purchaseDate,
          DaysSupply: m.daysSupply,
          NextRefillDate: m.nextRefillDate,
          NextReminderDate: m.nextReminderDate,
          RefillStatus: sanitizeFormulaInjection(m.refillStatus),
          RefillsRemaining: m.refillsRemaining
        };
      });
    }

    return this.data.inventory.map(i => ({
      DrugName: sanitizeFormulaInjection(i.drugName),
      Strength: sanitizeFormulaInjection(i.strength),
      Category: sanitizeFormulaInjection(i.category),
      CurrentStock: i.currentStock,
      MinimumStockThreshold: i.minimumStockThreshold,
      SupplierLeadTimeDays: i.supplierLeadTimeDays,
      Unit: sanitizeFormulaInjection(i.unit)
    }));
  }

  // =========================================================================
  // IMPORT WITH VALIDATION & DUPLICATE CHECKS
  // =========================================================================
  public importPatients(rows: any[], performedBy: string) {
    this.init();
    const errors: Array<{ row: number; error: string }> = [];
    const validRecords: Patient[] = [];

    const existingPhones = new Set(this.data.patients.filter(p => !p.isDeleted).map(p => p.phoneNumber));
    const existingFiles = new Set(this.data.patients.filter(p => !p.isDeleted).map(p => p.fileNumber));

    rows.forEach((row, idx) => {
      const rowNum = idx + 2; // Header is row 1
      const firstName = row.FirstName || row.first_name || row['الاسم الأول'];
      const lastName = row.LastName || row.last_name || row['اسم العائلة'];
      const rawPhone = row.Phone || row.phone || row['الهاتف'];

      if (!firstName || !lastName) {
        errors.push({ row: rowNum, error: 'First name and last name are required.' });
        return;
      }

      if (!rawPhone) {
        errors.push({ row: rowNum, error: 'Phone number is required.' });
        return;
      }

      const normalized = normalizePhoneNumber(String(rawPhone));
      if (!normalized.valid) {
        errors.push({ row: rowNum, error: `Invalid phone number format: "${rawPhone}".` });
        return;
      }

      if (existingPhones.has(normalized.normalized)) {
        errors.push({ row: rowNum, error: `Duplicate phone number: "${normalized.normalized}" already exists.` });
        return;
      }

      const fileNumber = row.FileNumber || row.file_number || `RX-${Math.floor(1000 + Math.random() * 9000)}`;
      if (existingFiles.has(fileNumber)) {
        errors.push({ row: rowNum, error: `Duplicate file number: "${fileNumber}".` });
        return;
      }

      existingPhones.add(normalized.normalized);
      existingFiles.add(fileNumber);

      const conditionsRaw = row.Conditions || row.chronic_conditions || '';
      const conditions = typeof conditionsRaw === 'string'
        ? conditionsRaw.split(',').map((s: string) => s.trim()).filter(Boolean)
        : [];

      validRecords.push({
        id: crypto.randomUUID(),
        fileNumber,
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        dateOfBirth: row.DateOfBirth || row.dob || '1975-01-01',
        gender: row.Gender === 'Female' ? 'Female' : 'Male',
        phoneNumber: normalized.normalized,
        whatsappNumber: normalized.normalized,
        address: row.Address || '',
        familyCode: row.FamilyCode || undefined,
        preferredChannel: 'WhatsApp',
        chronicConditions: conditions,
        allergies: row.Allergies || 'None reported',
        retentionStatus: 'retained',
        retentionScore: 95.0,
        retentionReason: 'Batch imported patient',
        retentionUpdatedAt: new Date().toISOString(),
        optedOut: false,
        isDeleted: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    });

    if (errors.length === 0 && validRecords.length > 0) {
      this.data.patients.unshift(...validRecords);
      this.audit('import', 'batch', 'import_patients', performedBy, { count: validRecords.length });
      this.save();
    }

    return {
      success: errors.length === 0,
      importedCount: errors.length === 0 ? validRecords.length : 0,
      errors
    };
  }
}

export const repository = new PharmacyRepository();
