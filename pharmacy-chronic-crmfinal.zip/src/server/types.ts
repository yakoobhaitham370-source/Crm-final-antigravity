export type UserRole = 'admin' | 'pharmacist' | 'staff';

export interface AuthUser {
  id: string;
  name: string;
  role: UserRole;
  licenseNumber?: string;
}

export interface Patient {
  id: string;
  fileNumber: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female' | 'Other';
  phoneNumber: string; // Iraq normalized e.g. +9647701234567
  whatsappNumber: string;
  address?: string;
  familyCode?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  primaryPhysician?: string;
  physicianPhone?: string;
  preferredChannel: 'WhatsApp' | 'SMS' | 'Phone Call';
  chronicConditions: string[];
  allergies: string;
  retentionStatus: 'retained' | 'at_risk' | 'inactive';
  retentionScore: number;
  retentionReason?: string;
  retentionUpdatedAt: string;
  photoUrl?: string; // Private storage key
  optedOut: boolean;
  isDeleted: boolean;
  deletedAt?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  medications?: Medication[];
}

export interface Medication {
  id: string;
  patientId: string;
  drugName: string;
  strength: string;
  dosageInstructions: string;
  purchaseDate: string; // YYYY-MM-DD
  daysSupply: number;
  nextRefillDate: string; // YYYY-MM-DD
  nextReminderDate: string; // YYYY-MM-DD
  refillStatus: 'active' | 'due_soon' | 'due_today' | 'overdue' | 'completed' | 'discontinued';
  refillsAuthorized: number;
  refillsRemaining: number;
  quantityPerRefill: number;
  prescribingDoctor?: string;
  notes?: string;
  isDeleted: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RefillAuditLog {
  id: string;
  medicationId: string;
  patientId: string;
  action: string;
  previousPurchaseDate?: string;
  newPurchaseDate: string;
  previousDaysSupply?: number;
  newDaysSupply: number;
  quantityDispensed: number;
  performedBy: string;
  refillCompliance: string;
  notes?: string;
  createdAt: string;
}

export interface AntibioticFollowup {
  id: string;
  patientId: string;
  patientName?: string;
  patientPhone?: string;
  antibioticName: string;
  dosageAndDuration: string;
  startDate: string;
  expectedFollowupDate: string;
  contactAttempts: number;
  lastContactDate?: string;
  patientReportedProgress: 'improving' | 'no_change' | 'worsened' | 'adverse_reaction' | 'completed_course' | 'pending';
  status: 'pending' | 'due_today' | 'overdue' | 'completed' | 'lost_to_followup';
  pharmacistNotes?: string;
  disclaimerAcknowledged: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PatientDocument {
  id: string;
  patientId: string;
  documentType: 'prescription' | 'lab_result' | 'discharge_summary' | 'other';
  fileName: string;
  fileSize: number;
  mimeType: string;
  storagePath: string;
  notes?: string;
  uploadedBy: string;
  isDeleted: boolean;
  createdAt: string;
}

export interface InventoryItem {
  id: string;
  drugName: string;
  strength: string;
  category: string;
  currentStock: number;
  minimumStockThreshold: number;
  supplierLeadTimeDays: number;
  unit: string;
  updatedAt: string;
  // Computed forecast fields
  forecast7d?: number;
  forecast14d?: number;
  forecast30d?: number;
  isStockoutProjected?: boolean;
  projectedStockoutDate?: string;
}

export interface MessageLog {
  id: string;
  patientId: string;
  medicationId?: string;
  channel: 'whatsapp' | 'sms';
  recipientPhone: string;
  messageContent: string;
  deliveryMode: 'click_to_chat_handoff' | 'sms_handoff' | 'provider_direct';
  status: 'prepared' | 'handed_off' | 'sent' | 'failed';
  errorMessage?: string;
  sentBy: string;
  createdAt: string;
}

export interface ThermalReceiptToken {
  id: string;
  token: string;
  patientId: string;
  medicationIds: string[];
  instructions?: string;
  pharmacyName: string;
  expiresAt: string;
  accessCount: number;
  createdAt: string;
}

export interface PharmacySettings {
  pharmacyName: string;
  pharmacistInCharge: string;
  contactPhone: string;
  address: string;
  defaultTimezone: string; // e.g. "Asia/Baghdad"
  interfaceLanguage: 'en' | 'ar';
  reminderIntervalDays: number; // default 3 days
  whatsappTemplate: string;
  smsTemplate: string;
  enableExternalMessaging: boolean;
  hasMessagingCredentials: boolean;
  databaseConfigured: boolean;
  storageConfigured: boolean;
}

export interface DashboardMetrics {
  totalActivePatients: number;
  dueSoonCount: number;
  dueTodayCount: number;
  overdueCount: number;
  completedRecentlyCount: number;
  averageAdherenceRate: number;
  pendingAntibioticFollowups: number;
  overdueAntibioticFollowups: number;
  projectedStockoutsCount: number;
}
