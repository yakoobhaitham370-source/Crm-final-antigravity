/**
 * Core pharmacy domain calculation utilities:
 * - Refill schedule math
 * - Configurable reminder intervals
 * - Adherence/retention proxy scoring (PDC)
 * - Iraqi phone normalization & international support
 * - Spreadsheet formula injection sanitization
 * - Message template compilation
 */

/**
 * Validates days supply as a positive integer (> 0).
 */
export function validateDaysSupply(daysSupply: number | string): { valid: boolean; value: number; error?: string } {
  const parsed = Number(daysSupply);
  if (isNaN(parsed) || !Number.isInteger(parsed) || parsed <= 0) {
    return { valid: false, value: 30, error: 'Days supply must be a positive whole number greater than zero.' };
  }
  return { valid: true, value: parsed };
}

/**
 * Formats a Date object or string as YYYY-MM-DD.
 */
export function formatDateISO(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) {
    throw new Error('Invalid date provided');
  }
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Calculates next refill date: purchaseDate + daysSupply
 */
export function calculateNextRefillDate(purchaseDate: string, daysSupply: number): string {
  const { valid, value } = validateDaysSupply(daysSupply);
  if (!valid) throw new Error('Invalid days supply');
  
  // Parse date components to avoid timezone offset shifts
  const [year, month, day] = purchaseDate.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() + value);
  return formatDateISO(d);
}

/**
 * Calculates next reminder date: nextRefillDate - reminderIntervalDays
 */
export function calculateNextReminderDate(nextRefillDate: string, reminderIntervalDays = 3): string {
  const interval = Math.max(1, Math.round(Number(reminderIntervalDays) || 3));
  const [year, month, day] = nextRefillDate.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() - interval);
  return formatDateISO(d);
}

/**
 * Calculates full medication refill dates and urgency status.
 */
export function recalculateMedicationSchedule(
  purchaseDate: string,
  daysSupply: number,
  reminderIntervalDays = 3,
  referenceDateStr?: string
) {
  const nextRefillDate = calculateNextRefillDate(purchaseDate, daysSupply);
  const nextReminderDate = calculateNextReminderDate(nextRefillDate, reminderIntervalDays);
  const refillStatus = determineRefillStatus(nextRefillDate, referenceDateStr, reminderIntervalDays);

  return {
    nextRefillDate,
    nextReminderDate,
    refillStatus
  };
}

/**
 * Evaluates refill status based on next refill date compared to reference date (default today).
 */
export function determineRefillStatus(
  nextRefillDate: string,
  referenceDateStr?: string,
  reminderIntervalDays = 3
): 'overdue' | 'due_today' | 'due_soon' | 'active' {
  const today = referenceDateStr || formatDateISO(new Date());

  if (nextRefillDate < today) {
    return 'overdue';
  }
  if (nextRefillDate === today) {
    return 'due_today';
  }

  // Calculate days difference
  const [ty, tm, td] = today.split('-').map(Number);
  const [ny, nm, nd] = nextRefillDate.split('-').map(Number);
  const todayDate = new Date(ty, tm - 1, td);
  const refillDate = new Date(ny, nm - 1, nd);
  const diffDays = Math.round((refillDate.getTime() - todayDate.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays <= reminderIntervalDays) {
    return 'due_soon';
  }
  return 'active';
}

/**
 * Calculates patient retention adherence proxy score using Proportion of Days Covered (PDC).
 * 
 * DISCLAIMER: This is an administrative operational proxy for pharmacy inventory & follow-up planning,
 * not a clinical assessment or diagnostic measure.
 */
export function calculateRetentionScore(
  purchases: Array<{ purchaseDate: string; daysSupply: number }>,
  windowDays = 180,
  referenceDateStr?: string
): { score: number; coveredDays: number; totalDays: number; status: 'retained' | 'at_risk' | 'inactive'; explanation: string } {
  if (!purchases || purchases.length === 0) {
    return {
      score: 90.0,
      coveredDays: 0,
      totalDays: windowDays,
      status: 'retained',
      explanation: 'New patient enrollment: benchmark score applied until multi-refill history is established.'
    };
  }

  const todayStr = referenceDateStr || formatDateISO(new Date());
  const [ty, tm, td] = todayStr.split('-').map(Number);
  const windowEnd = new Date(ty, tm - 1, td);
  const windowStart = new Date(ty, tm - 1, td);
  windowStart.setDate(windowStart.getDate() - windowDays);

  const coveredSet = new Set<string>();

  for (const p of purchases) {
    const [py, pm, pd] = p.purchaseDate.split('-').map(Number);
    const pDate = new Date(py, pm - 1, pd);
    const days = Math.max(1, Number(p.daysSupply) || 30);

    for (let i = 0; i < days; i++) {
      const cur = new Date(pDate);
      cur.setDate(cur.getDate() + i);
      if (cur >= windowStart && cur <= windowEnd) {
        coveredSet.add(formatDateISO(cur));
      }
    }
  }

  const coveredDays = coveredSet.size;
  const rawScore = (coveredDays / windowDays) * 100;
  const score = Math.min(100, Math.max(0, Math.round(rawScore * 10) / 10));

  let status: 'retained' | 'at_risk' | 'inactive' = 'retained';
  let explanation = '';

  if (score >= 80) {
    status = 'retained';
    explanation = `High adherence proxy (${score}%): patient covered for ${coveredDays} of past ${windowDays} days.`;
  } else if (score >= 50) {
    status = 'at_risk';
    explanation = `Moderate adherence risk (${score}%): patient had gaps totaling ${windowDays - coveredDays} days without recorded supply.`;
  } else {
    status = 'inactive';
    explanation = `Severe adherence drop (${score}%): over half of observation window lacked documented medication supply. Outreach suggested.`;
  }

  return { score, coveredDays, totalDays: windowDays, status, explanation };
}

/**
 * Normalizes Iraqi phone numbers with +964 default prefix while preserving valid international numbers.
 */
export function normalizePhoneNumber(rawPhone: string): { valid: boolean; normalized: string; isIraq: boolean } {
  if (!rawPhone) return { valid: false, normalized: '', isIraq: false };

  // Remove spaces, hyphens, brackets, dots
  let cleaned = rawPhone.replace(/[\s\-\(\)\.]/g, '').trim();

  // If already starts with +
  if (cleaned.startsWith('+')) {
    const isIraq = cleaned.startsWith('+964');
    // Minimum digits validation
    const digitsOnly = cleaned.replace(/\D/g, '');
    const valid = digitsOnly.length >= 8 && digitsOnly.length <= 15;
    return { valid, normalized: cleaned, isIraq };
  }

  // If starts with 00 (e.g. 00964)
  if (cleaned.startsWith('00')) {
    cleaned = '+' + cleaned.slice(2);
    const isIraq = cleaned.startsWith('+964');
    const digitsOnly = cleaned.replace(/\D/g, '');
    return { valid: digitsOnly.length >= 8, normalized: cleaned, isIraq };
  }

  // Iraqi local formats: starts with 07... (e.g. 07701234567, 07801234567, 0750...)
  if (cleaned.startsWith('07') && cleaned.length === 11) {
    const normalized = '+964' + cleaned.slice(1);
    return { valid: true, normalized, isIraq: true };
  }

  // Iraqi format without leading zero: 7701234567, 7801234567, 750... (10 digits)
  if (cleaned.startsWith('7') && cleaned.length === 10) {
    const normalized = '+964' + cleaned;
    return { valid: true, normalized, isIraq: true };
  }

  // Default assumption for 10-11 digit numbers without country code: apply +964
  if (/^\d{9,11}$/.test(cleaned)) {
    const trimmed = cleaned.startsWith('0') ? cleaned.slice(1) : cleaned;
    const normalized = '+964' + trimmed;
    return { valid: true, normalized, isIraq: true };
  }

  return { valid: false, normalized: cleaned, isIraq: false };
}

/**
 * Protects against CSV and Spreadsheet formula injection.
 * Any string beginning with '=', '+', '-', '@', '\t', or '\r' is escaped with a leading single quote.
 */
export function sanitizeFormulaInjection(value: unknown): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (/^[=\+\-@\t\r]/.test(str)) {
    return `'${str}`;
  }
  return str;
}

/**
 * Compiles a message template with patient and pharmacy parameters.
 */
export function formatTemplateMessage(
  template: string,
  variables: {
    patient_name?: string;
    medications?: string;
    due_date?: string;
    pharmacy_name?: string;
    pharmacy_phone?: string;
    custom_note?: string;
  }
): string {
  let message = template;
  message = message.replace(/{patient_name}/g, variables.patient_name || 'Patient');
  message = message.replace(/{medications}/g, variables.medications || 'medications');
  message = message.replace(/{due_date}/g, variables.due_date || '');
  message = message.replace(/{pharmacy_name}/g, variables.pharmacy_name || 'Community Pharmacy');
  message = message.replace(/{pharmacy_phone}/g, variables.pharmacy_phone || '');
  message = message.replace(/{custom_note}/g, variables.custom_note || '');
  return message.trim();
}
