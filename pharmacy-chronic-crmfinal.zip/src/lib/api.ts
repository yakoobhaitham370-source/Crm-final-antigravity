import { Patient, Medication, AntibioticFollowup, InventoryItem, PharmacySettings, DashboardMetrics } from '../server/types';

const BASE_URL = '/api';

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(options.headers || {})
  };

  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers
  });

  if (!res.ok) {
    let errorMsg = `Server error ${res.status}`;
    try {
      const errJson = await res.json();
      errorMsg = errJson.error || errorMsg;
    } catch {}
    throw new Error(errorMsg);
  }

  return res.json();
}

export const api = {
  // Database status test
  getDbStatus: () => request<{ success: boolean; message: string; dialect: string }>('/system/db-status'),

  // Dashboard
  getDashboardMetrics: () => request<DashboardMetrics>('/dashboard/metrics'),

  // Patients
  getPatients: (params: {
    page?: number;
    pageSize?: number;
    search?: string;
    status?: string;
    familyCode?: string;
    drugName?: string;
    sortField?: string;
    sortOrder?: string;
  }) => {
    const query = new URLSearchParams();
    if (params.page) query.set('page', String(params.page));
    if (params.pageSize) query.set('pageSize', String(params.pageSize));
    if (params.search) query.set('search', params.search);
    if (params.status) query.set('status', params.status);
    if (params.familyCode) query.set('familyCode', params.familyCode);
    if (params.drugName) query.set('drugName', params.drugName);
    if (params.sortField) query.set('sortField', params.sortField);
    if (params.sortOrder) query.set('sortOrder', params.sortOrder);
    return request<{ data: Patient[]; total: number; page: number; pageSize: number; totalPages: number }>(`/patients?${query.toString()}`);
  },

  getPatientById: (id: string) => request<Patient & { medications: Medication[]; refillLogs: any[]; familyMembers?: Patient[] }>(`/patients/${id}`),

  createPatient: (data: Partial<Patient>) => request<Patient>('/patients', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  updatePatient: (id: string, data: Partial<Patient>) => request<Patient>(`/patients/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  deletePatient: (id: string) => request<{ success: boolean }>(`/patients/${id}`, {
    method: 'DELETE'
  }),

  // Medications
  addMedication: (patientId: string, data: Partial<Medication>) => request<Medication>(`/patients/${patientId}/medications`, {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  updateMedication: (id: string, data: Partial<Medication>) => request<Medication>(`/medications/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  recordRefill: (data: {
    medicationId: string;
    purchaseDate: string;
    daysSupply: number;
    quantityDispensed: number;
    notes?: string;
  }) => request<{ medication: Medication; auditLog: any }>('/refills', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  getRefillsByDate: (date: string) => request<Array<Medication & { patient?: Patient }>>(`/refills/by-date?date=${date}`),

  // Antibiotics
  getAntibiotics: (params: { status?: string; search?: string; page?: number; pageSize?: number }) => {
    const q = new URLSearchParams();
    if (params.status) q.set('status', params.status);
    if (params.search) q.set('search', params.search);
    if (params.page) q.set('page', String(params.page));
    if (params.pageSize) q.set('pageSize', String(params.pageSize));
    return request<{ data: AntibioticFollowup[]; total: number; page: number; pageSize: number; totalPages: number }>(`/antibiotics?${q.toString()}`);
  },

  createAntibiotic: (data: Partial<AntibioticFollowup>) => request<AntibioticFollowup>('/antibiotics', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  updateAntibiotic: (id: string, data: Partial<AntibioticFollowup>) => request<AntibioticFollowup>(`/antibiotics/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  // Inventory
  getInventoryForecast: (days = 30) => request<InventoryItem[]>(`/inventory/forecast?days=${days}`),

  updateInventoryItem: (id: string, data: Partial<InventoryItem>) => request<InventoryItem>(`/inventory/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  // Settings
  getSettings: () => request<PharmacySettings>('/settings'),

  updateSettings: (data: Partial<PharmacySettings>) => request<PharmacySettings>('/settings', {
    method: 'PUT',
    body: JSON.stringify(data)
  }),

  // Thermal QR
  createThermalToken: (data: { patientId: string; medicationIds: string[]; instructions?: string }) => request<{ token: string; url: string; expiresAt: string }>('/thermal/token', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  verifyThermalToken: (token: string) => request<any>(`/thermal/verify?token=${token}`),

  // Messaging
  sendMessage: (data: { patientId: string; medicationId?: string; channel: 'whatsapp' | 'sms'; customMessage?: string }) => request<{
    success: boolean;
    message: string;
    link: string;
    channel: string;
    phone: string;
  }>('/messages/send', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  // Import
  importPatients: (rows: any[]) => request<{ success: boolean; importedCount: number; errors: Array<{ row: number; error: string }> }>('/import/patients', {
    method: 'POST',
    body: JSON.stringify({ rows })
  }),

  // Upload Photo
  uploadPhoto: async (patientId: string, file: File) => {
    return new Promise<{ success: boolean; photoUrl: string }>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          const res = await request<{ success: boolean; photoUrl: string }>(`/patients/${patientId}/photo`, {
            method: 'POST',
            body: JSON.stringify({
              base64Data: base64,
              originalName: file.name,
              mimeType: file.type
            })
          });
          resolve(res);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  }
};
