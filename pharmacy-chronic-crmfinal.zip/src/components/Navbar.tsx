import React from 'react';
import { 
  Pill, 
  Users, 
  CalendarClock, 
  Activity, 
  Boxes, 
  FileSpreadsheet, 
  Settings as SettingsIcon, 
  Globe, 
  Database, 
  AlertTriangle,
  UserPlus
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { PharmacySettings } from '../server/types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
  settings: PharmacySettings | null;
  onOpenAddPatient: () => void;
  onOpenSettings: () => void;
  urgentCount: number;
  dueTodayCount: number;
  stockoutCount: number;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  settings,
  onOpenAddPatient,
  onOpenSettings,
  urgentCount,
  dueTodayCount,
  stockoutCount
}: NavbarProps) {
  const t = TRANSLATIONS[lang];

  return (
    <header className="sticky top-0 z-40 bg-[#0f172a]/95 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header Row */}
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Brand & Pharmacy Name */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-950 flex-shrink-0">
              <Pill className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight truncate">
                  {settings?.pharmacyName || t.appTitle}
                </h1>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                  v2.0 Dark
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate hidden sm:block">
                {t.appSubtitle} &bull; <span className="font-mono text-emerald-400">{settings?.defaultTimezone || 'Asia/Baghdad'}</span>
              </p>
            </div>
          </div>

          {/* Quick Actions & Indicators */}
          <div className="flex items-center space-x-2 sm:space-x-3 rtl:space-x-reverse flex-shrink-0">
            
            {/* Database Status Indicator */}
            <div 
              className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border ${
                settings?.databaseConfigured 
                  ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/50' 
                  : 'bg-amber-950/40 text-amber-300 border-amber-800/50'
              }`}
              title={settings?.databaseConfigured ? 'Connected to hosted PostgreSQL' : 'Operating in protected local persistence mode'}
            >
              <Database className="w-3.5 h-3.5" />
              <span>{settings?.databaseConfigured ? 'PostgreSQL' : 'Local DB'}</span>
            </div>

            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
              className="flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Toggle English / Arabic (RTL)"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>{lang === 'en' ? 'العربية' : 'English'}</span>
            </button>

            {/* New Patient Button */}
            <button
              onClick={onOpenAddPatient}
              className="flex items-center space-x-1.5 rtl:space-x-reverse px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950 transition active:scale-95"
            >
              <UserPlus className="w-4 h-4" />
              <span className="hidden sm:inline">{t.addPatient}</span>
            </button>

            {/* Settings Button */}
            <button
              onClick={onOpenSettings}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 border border-transparent hover:border-slate-700 transition"
              title={t.settings}
            >
              <SettingsIcon className="w-5 h-5" />
            </button>

          </div>
        </div>

        {/* Tab Navigation Navigation Bar */}
        <nav className="flex space-x-1 rtl:space-x-reverse overflow-x-auto py-2 scrollbar-none border-t border-slate-800/60 text-xs font-medium">
          
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'dashboard'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{t.dashboard}</span>
            {(urgentCount > 0 || dueTodayCount > 0) && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {urgentCount + dueTodayCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('patients')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'patients'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{t.patients}</span>
          </button>

          <button
            onClick={() => setActiveTab('refills')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'refills'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <CalendarClock className="w-4 h-4" />
            <span>{t.refillsQueue}</span>
            {urgentCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {urgentCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('antibiotics')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'antibiotics'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Pill className="w-4 h-4 text-cyan-400" />
            <span>{t.antibioticFollowups}</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'inventory'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Boxes className="w-4 h-4" />
            <span>{t.inventoryForecast}</span>
            {stockoutCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {stockoutCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg whitespace-nowrap transition ${
              activeTab === 'reports'
                ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{t.reportsAndImport}</span>
          </button>

        </nav>

      </div>
    </header>
  );
}
