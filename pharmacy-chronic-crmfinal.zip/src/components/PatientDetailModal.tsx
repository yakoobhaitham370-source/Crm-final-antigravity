import React, { useState } from 'react';
import { 
  X, 
  Phone, 
  MessageSquare, 
  AlertTriangle, 
  Calendar, 
  FileText, 
  Plus, 
  Pill, 
  History, 
  Upload, 
  CheckCircle2, 
  ShieldAlert, 
  Link2, 
  Camera, 
  Trash2, 
  Edit3, 
  ExternalLink,
  HelpCircle
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { Patient, Medication } from '../server/types';
import { api } from '../lib/api';

interface PatientDetailModalProps {
  patient: Patient & { medications?: Medication[]; refillLogs?: any[]; familyMembers?: Patient[] };
  lang: Language;
  onClose: () => void;
  onRefresh: () => void;
  onOpenRecordRefill: (medication: Medication, patient?: Patient) => void;
  onOpenThermalSlip: (patientId: string, medicationIds: string[]) => void;
  onSendMessage: (patientId: string, medicationId?: string, channel?: 'whatsapp' | 'sms') => void;
  onFilterFamily: (familyCode: string) => void;
}

export default function PatientDetailModal({
  patient,
  lang,
  onClose,
  onRefresh,
  onOpenRecordRefill,
  onOpenThermalSlip,
  onSendMessage,
  onFilterFamily
}: PatientDetailModalProps) {
  const t = TRANSLATIONS[lang];

  const [activeTab, setActiveTab] = useState<'meds' | 'retention' | 'documents' | 'history'>('meds');

  // Allergy Edit State
  const [isEditingAllergies, setIsEditingAllergies] = useState(false);
  const [allergiesText, setAllergiesText] = useState(patient.allergies || '');

  // Retention Override State
  const [retentionStatus, setRetentionStatus] = useState(patient.retentionStatus);
  const [retentionReason, setRetentionReason] = useState(patient.retentionReason || '');
  const [savingRetention, setSavingRetention] = useState(false);

  // New Medication Form State
  const [isAddingMed, setIsAddingMed] = useState(false);
  const [newMedData, setNewMedData] = useState({
    drugName: '',
    strength: '',
    dosageInstructions: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    daysSupply: 30,
    quantityPerRefill: 30,
    refillsAuthorized: 6,
    prescribingDoctor: patient.primaryPhysician || '',
    notes: ''
  });
  const [medError, setMedError] = useState('');

  // Photo Upload State
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // Save Allergies
  const handleSaveAllergies = async () => {
    try {
      await api.updatePatient(patient.id, { allergies: allergiesText });
      setIsEditingAllergies(false);
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to update allergies');
    }
  };

  // Save Retention Override
  const handleSaveRetention = async () => {
    try {
      setSavingRetention(true);
      await api.updatePatient(patient.id, {
        retentionStatus,
        retentionReason,
        retentionUpdatedAt: new Date().toISOString()
      });
      alert('Retention status updated successfully.');
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to update retention status');
    } finally {
      setSavingRetention(false);
    }
  };

  // Add Medication
  const handleAddMedication = async (e: React.FormEvent) => {
    e.preventDefault();
    setMedError('');

    if (!newMedData.drugName.trim()) {
      setMedError('Medication name is required.');
      return;
    }

    if (Number(newMedData.daysSupply) <= 0) {
      setMedError('Days supply must be a positive number greater than 0.');
      return;
    }

    try {
      await api.addMedication(patient.id, newMedData);
      setIsAddingMed(false);
      setNewMedData({
        drugName: '',
        strength: '',
        dosageInstructions: '',
        purchaseDate: new Date().toISOString().split('T')[0],
        daysSupply: 30,
        quantityPerRefill: 30,
        refillsAuthorized: 6,
        prescribingDoctor: patient.primaryPhysician || '',
        notes: ''
      });
      onRefresh();
    } catch (err: any) {
      setMedError(err.message || 'Failed to add medication');
    }
  };

  // Photo Upload Handler
  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      alert('Please upload a valid JPG, PNG, or WebP image.');
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      alert('Photo size exceeds 3MB limit.');
      return;
    }

    try {
      setUploadingPhoto(true);
      await api.uploadPhoto(patient.id, file);
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to upload photo');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const hasAllergies = patient.allergies && patient.allergies.toLowerCase() !== 'none reported' && patient.allergies.trim() !== '';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0">
            
            {/* Photo Avatar with Upload Trigger */}
            <div className="relative group w-12 h-12 rounded-full overflow-hidden bg-slate-800 border-2 border-emerald-500/40 flex-shrink-0 flex items-center justify-center text-emerald-400 font-bold text-base">
              {patient.photoUrl ? (
                <img src={patient.photoUrl} alt="Patient" className="w-full h-full object-cover" />
              ) : (
                <span>{patient.firstName[0]}{patient.lastName[0]}</span>
              )}
              <label 
                className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition"
                title={t.uploadPhoto}
              >
                <Camera className="w-4 h-4 text-white" />
                <input 
                  type="file" 
                  accept="image/jpeg,image/png,image/webp" 
                  onChange={handlePhotoSelect} 
                  className="hidden" 
                  disabled={uploadingPhoto}
                />
              </label>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white truncate">
                  {patient.firstName} {patient.lastName}
                </h2>
                <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {patient.fileNumber}
                </span>
                {patient.familyCode && (
                  <button
                    onClick={() => {
                      onFilterFamily(patient.familyCode || '');
                      onClose();
                    }}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-800 hover:bg-cyan-900 transition"
                    title={t.viewFamily}
                  >
                    <Link2 className="w-3 h-3" />
                    <span>{patient.familyCode}</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5" dir="ltr">
                <span className="font-mono text-emerald-400">{patient.phoneNumber}</span>
                <span>&bull;</span>
                <span>{patient.gender}</span>
                <span>&bull;</span>
                <span>DOB: {patient.dateOfBirth}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* PROMINENT ALLERGY SAFETY ALERT BANNER */}
        <div className={`px-6 py-3 border-b flex items-center justify-between gap-3 ${
          hasAllergies 
            ? 'bg-rose-950/60 border-rose-900/80 text-rose-200' 
            : 'bg-slate-900/40 border-slate-800 text-slate-400'
        }`}>
          <div className="flex items-center space-x-2 rtl:space-x-reverse min-w-0">
            <AlertTriangle className={`w-4 h-4 flex-shrink-0 ${hasAllergies ? 'text-rose-400' : 'text-slate-500'}`} />
            <div className="text-xs min-w-0">
              <span className="font-bold uppercase tracking-wider mr-2 rtl:mr-0 rtl:ml-2">
                {t.allergies}:
              </span>
              <span className={`font-semibold ${hasAllergies ? 'text-rose-200' : 'text-slate-300'}`}>
                {patient.allergies || t.noAllergies}
              </span>
            </div>
          </div>

          <button
            onClick={() => setIsEditingAllergies(!isEditingAllergies)}
            className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 flex-shrink-0 flex items-center gap-1 transition"
          >
            <Edit3 className="w-3 h-3" />
            <span>{isEditingAllergies ? t.cancel : t.editAllergies}</span>
          </button>
        </div>

        {/* Allergy Edit Panel */}
        {isEditingAllergies && (
          <div className="px-6 py-3 bg-slate-900 border-b border-slate-800 flex items-center gap-3">
            <input
              type="text"
              value={allergiesText}
              onChange={(e) => setAllergiesText(e.target.value)}
              placeholder="e.g. Penicillin (Anaphylaxis), Aspirin (Bronchospasm)..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
            <button
              onClick={handleSaveAllergies}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold shadow transition"
            >
              {t.saveAllergies}
            </button>
          </div>
        )}

        {/* Tab Navigation inside Modal */}
        <div className="flex border-b border-slate-800 px-6 bg-slate-900/40 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('meds')}
            className={`py-3 px-4 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'meds'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Pill className="w-4 h-4" />
            <span>{t.chronicMeds} ({(patient.medications || []).length})</span>
          </button>

          <button
            onClick={() => setActiveTab('retention')}
            className={`py-3 px-4 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'retention'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{t.retentionIndicator} ({patient.retentionScore}%)</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`py-3 px-4 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'history'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>{t.dispenseHistory}</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: MEDICATIONS */}
          {activeTab === 'meds' && (
            <div className="space-y-4">
              
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {t.chronicMeds}
                </h3>
                <button
                  onClick={() => setIsAddingMed(!isAddingMed)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAddingMed ? t.cancel : t.addMedication}</span>
                </button>
              </div>

              {/* Add Medication Form */}
              {isAddingMed && (
                <form onSubmit={handleAddMedication} className="bg-slate-900 border border-slate-700 rounded-xl p-4 space-y-3">
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-emerald-400" />
                    <span>{t.addMedication}</span>
                  </h4>

                  {medError && (
                    <div className="text-xs font-semibold text-rose-400 bg-rose-950/60 p-2 rounded-lg border border-rose-800">
                      {medError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Medication Name *</label>
                      <input
                        type="text"
                        required
                        value={newMedData.drugName}
                        onChange={(e) => setNewMedData({ ...newMedData, drugName: e.target.value })}
                        placeholder="e.g. Amlodipine Besylate"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Strength / Dose *</label>
                      <input
                        type="text"
                        required
                        value={newMedData.strength}
                        onChange={(e) => setNewMedData({ ...newMedData, strength: e.target.value })}
                        placeholder="e.g. 5mg, 500mg XR"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-slate-400 mb-1">{t.dosageInstructions} *</label>
                      <input
                        type="text"
                        required
                        value={newMedData.dosageInstructions}
                        onChange={(e) => setNewMedData({ ...newMedData, dosageInstructions: e.target.value })}
                        placeholder="e.g. 1 tablet once daily in the morning with water"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">{t.purchaseDate} *</label>
                      <input
                        type="date"
                        required
                        value={newMedData.purchaseDate}
                        onChange={(e) => setNewMedData({ ...newMedData, purchaseDate: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">{t.daysSupply} (Positive number) *</label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={newMedData.daysSupply}
                        onChange={(e) => setNewMedData({ ...newMedData, daysSupply: Number(e.target.value) })}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingMed(false)}
                      className="px-3 py-1.5 rounded-lg text-xs bg-slate-800 text-slate-300"
                    >
                      {t.cancel}
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white"
                    >
                      Save Medication
                    </button>
                  </div>
                </form>
              )}

              {/* Medications List Cards */}
              <div className="space-y-3">
                {(patient.medications || []).map(m => (
                  <div key={m.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{m.drugName}</span>
                        <span className="text-xs font-semibold text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
                          {m.strength}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          m.refillStatus === 'overdue' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          m.refillStatus === 'due_today' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                          m.refillStatus === 'due_soon' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' :
                          'bg-slate-800 text-slate-300'
                        }`}>
                          {m.refillStatus}
                        </span>
                      </div>

                      <p className="text-xs text-slate-300 mt-1">{m.dosageInstructions}</p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 mt-2 font-mono">
                        <span>Purchased: {m.purchaseDate}</span>
                        <span>&bull;</span>
                        <span>Supply: {m.daysSupply} days</span>
                        <span>&bull;</span>
                        <span className="text-emerald-400 font-bold">Next Refill: {m.nextRefillDate}</span>
                        <span>&bull;</span>
                        <span className="text-cyan-400">Reminder: {m.nextReminderDate}</span>
                        <span>&bull;</span>
                        <span>Refills left: {m.refillsRemaining}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      
                      {/* Dispense Refill */}
                      <button
                        onClick={() => onOpenRecordRefill(m, patient)}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow transition"
                      >
                        {t.refillDispense}
                      </button>

                      {/* Pocket Thermal Slip */}
                      <button
                        onClick={() => onOpenThermalSlip(patient.id, [m.id])}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                        title={t.thermalSlip}
                      >
                        <FileText className="w-4 h-4" />
                      </button>

                      {/* WhatsApp Refill Message */}
                      {!patient.optedOut && (
                        <button
                          onClick={() => onSendMessage(patient.id, m.id, 'whatsapp')}
                          className="p-1.5 rounded-lg bg-teal-950 hover:bg-teal-900 text-teal-400 border border-teal-800 transition"
                          title={t.sendWhatsApp}
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                      )}

                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 2: RETENTION & ADHERENCE CALCULATOR */}
          {activeTab === 'retention' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
              
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-emerald-400" />
                    <span>{t.retentionIndicator}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-xl">
                    {t.retentionDisclaimer}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold font-mono text-emerald-400">{patient.retentionScore}%</div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Proportion of Days Covered</span>
                </div>
              </div>

              {/* Calculator Inputs & Status Display */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                <div>
                  <span className="text-slate-500 block">Current Status:</span>
                  <span className="font-bold text-white capitalize">{patient.retentionStatus.replace('_', ' ')}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Observation Window:</span>
                  <span className="font-bold text-white">Past 180 Days</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Last Re-evaluated:</span>
                  <span className="font-mono text-white">{patient.retentionUpdatedAt?.split('T')[0] || 'N/A'}</span>
                </div>
              </div>

              {/* Reason / Explanation */}
              <div className="text-xs text-slate-300 bg-slate-800/40 p-3 rounded-lg border border-slate-700/60">
                <span className="text-slate-400 font-semibold mr-1">Calculation Rationale:</span>
                {patient.retentionReason || 'Adherence score based on regular recorded dispensing cycles.'}
              </div>

              {/* Override Controls */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300">{t.changeStatus}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Status Override:</label>
                    <select
                      value={retentionStatus}
                      onChange={(e) => setRetentionStatus(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                    >
                      <option value="retained">{t.retained}</option>
                      <option value="at_risk">{t.atRisk}</option>
                      <option value="inactive">{t.inactive}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">{t.reason}:</label>
                    <input
                      type="text"
                      value={retentionReason}
                      onChange={(e) => setRetentionReason(e.target.value)}
                      placeholder="e.g. Travel overseas, physician adjusted therapy, financial gap"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                </div>

                <button
                  disabled={savingRetention}
                  onClick={handleSaveRetention}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow transition"
                >
                  {savingRetention ? 'Saving...' : t.saveChanges}
                </button>
              </div>

            </div>
          )}

          {/* TAB 3: DISPENSE AUDIT HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t.dispenseHistory}
              </h3>

              {(!patient.refillLogs || patient.refillLogs.length === 0) ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No previous refill audit records logged for this patient yet.
                </div>
              ) : (
                <div className="overflow-x-auto bg-slate-900 rounded-xl border border-slate-800">
                  <table className="w-full text-xs text-left rtl:text-right text-slate-300">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Action</th>
                        <th className="py-2.5 px-3">Days Supply</th>
                        <th className="py-2.5 px-3">Quantity</th>
                        <th className="py-2.5 px-3">Compliance</th>
                        <th className="py-2.5 px-3">Pharmacist</th>
                        <th className="py-2.5 px-3">Notes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                      {patient.refillLogs.map((log: any) => (
                        <tr key={log.id} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-3 text-white">{log.newPurchaseDate || log.createdAt?.split('T')[0]}</td>
                          <td className="py-2.5 px-3 uppercase text-emerald-400 font-bold">{log.action?.replace('_', ' ')}</td>
                          <td className="py-2.5 px-3">{log.newDaysSupply}d</td>
                          <td className="py-2.5 px-3">{log.quantityDispensed}</td>
                          <td className="py-2.5 px-3 font-sans">
                            <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                              {log.refillCompliance}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 font-sans text-slate-300">{log.performedBy}</td>
                          <td className="py-2.5 px-3 font-sans text-slate-400 max-w-xs truncate">{log.notes || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs text-slate-400">
          <span>Patient ID: <span className="font-mono text-slate-300">{patient.id}</span></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition font-medium"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
}
