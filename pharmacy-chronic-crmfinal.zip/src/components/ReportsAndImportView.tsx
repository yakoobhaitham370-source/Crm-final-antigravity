import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  FileText,
  Users,
  CalendarClock,
  Boxes
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { api } from '../lib/api';
import * as XLSX from 'xlsx';

interface ReportsAndImportViewProps {
  lang: Language;
  onRefreshPatients: () => void;
}

export default function ReportsAndImportView({ lang, onRefreshPatients }: ReportsAndImportViewProps) {
  const t = TRANSLATIONS[lang];

  const [importRows, setImportRows] = useState<any[]>([]);
  const [importErrors, setImportErrors] = useState<Array<{ row: number; error: string }>>([]);
  const [importedCount, setImportedCount] = useState<number | null>(null);
  const [loadingImport, setLoadingImport] = useState(false);

  // Export Trigger
  const handleExport = (type: 'patients' | 'refills' | 'inventory', format: 'xlsx' | 'csv') => {
    window.open(`/api/export?type=${type}&format=${format}`, '_blank');
  };

  // Sample Template Generator
  const handleDownloadSample = () => {
    const sampleData = [
      {
        FirstName: 'Zaid',
        LastName: 'Al-Rawi',
        Phone: '07701234567',
        DateOfBirth: '1965-06-15',
        Gender: 'Male',
        FamilyCode: 'FAM-MANSOUR-101',
        Conditions: 'Hypertension, Type 2 Diabetes',
        Allergies: 'None reported'
      },
      {
        FirstName: 'Maryam',
        LastName: 'Al-Rawi',
        Phone: '07701234568',
        DateOfBirth: '1970-09-22',
        Gender: 'Female',
        FamilyCode: 'FAM-MANSOUR-101',
        Conditions: 'Dyslipidemia',
        Allergies: 'Penicillin'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sample_Patients');
    XLSX.writeFile(wb, 'PharmaTrack_Patient_Import_Template.xlsx');
  };

  // File Upload & Parse
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportErrors([]);
    setImportedCount(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        setImportRows(data);
      } catch (err: any) {
        alert('Failed to parse file: ' + err.message);
      }
    };
    reader.readAsBinaryString(file);
  };

  // Confirm Import
  const handleConfirmImport = async () => {
    if (importRows.length === 0) return;
    try {
      setLoadingImport(true);
      const res = await api.importPatients(importRows);
      if (res.success) {
        setImportedCount(res.importedCount);
        setImportRows([]);
        setImportErrors([]);
        onRefreshPatients();
      } else {
        setImportErrors(res.errors);
      }
    } catch (err: any) {
      alert(err.message || 'Import failed');
    } finally {
      setLoadingImport(false);
    }
  };

  return (
    <div className="space-y-6">

      {/* Security Formula Injection Notice */}
      <div className="p-4 bg-emerald-950/40 border border-emerald-800/80 rounded-2xl flex items-center space-x-3 rtl:space-x-reverse text-emerald-200 text-xs">
        <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
        <div>
          <span className="font-bold uppercase tracking-wider block text-emerald-300">
            {t.formulaInjectionProtection}
          </span>
          <p className="mt-0.5 text-emerald-200/90">
            Exported Excel and CSV spreadsheets sanitize leading formula injection triggers (=, +, -, @) to prevent remote formula execution attacks when opened in Microsoft Excel or Google Sheets.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* 1. EXPORT REPORTS SECTION */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
              <span>{t.exportReports}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Download complete, sanitized clinical and operational registries for administrative auditing and reporting.
            </p>
          </div>

          <div className="space-y-3">
            
            {/* Export Patient Registry */}
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
                  <Users className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{t.exportPatients}</h4>
                  <p className="text-[11px] text-slate-400">Dossiers, adherence proxy scores, and conditions</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleExport('patients', 'xlsx')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow transition"
                >
                  .XLSX
                </button>
                <button
                  onClick={() => handleExport('patients', 'csv')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                >
                  .CSV
                </button>
              </div>
            </div>

            {/* Export Refill Workbench */}
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
                  <CalendarClock className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{t.exportRefills}</h4>
                  <p className="text-[11px] text-slate-400">Scheduled dispense cycles, days supply, and next dates</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleExport('refills', 'xlsx')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow transition"
                >
                  .XLSX
                </button>
                <button
                  onClick={() => handleExport('refills', 'csv')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                >
                  .CSV
                </button>
              </div>
            </div>

            {/* Export Inventory Forecast */}
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
                  <Boxes className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{t.exportInventory}</h4>
                  <p className="text-[11px] text-slate-400">Current stock, projected 7/14/30d demand, and lead times</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleExport('inventory', 'xlsx')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow transition"
                >
                  .XLSX
                </button>
                <button
                  onClick={() => handleExport('inventory', 'csv')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                >
                  .CSV
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* 2. IMPORT PATIENTS SECTION */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Upload className="w-5 h-5 text-cyan-400" />
              <span>{t.importPatients}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Bulk register patient rosters from existing pharmacy software or spreadsheets.
            </p>
          </div>

          <div className="space-y-4 text-xs">
            
            {/* Step 1: Download Template */}
            <div className="flex items-center justify-between p-3.5 bg-slate-900 border border-slate-800 rounded-xl">
              <div>
                <span className="font-semibold text-white block">Step 1: Download Example Format</span>
                <span className="text-[11px] text-slate-400">Pre-formatted columns: FirstName, LastName, Phone (+964), FamilyCode, etc.</span>
              </div>
              <button
                onClick={handleDownloadSample}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.downloadTemplate}</span>
              </button>
            </div>

            {/* Step 2: Upload File */}
            <div className="p-4 bg-slate-900 border border-dashed border-slate-700 rounded-xl text-center space-y-2">
              <Upload className="w-6 h-6 text-slate-400 mx-auto" />
              <div className="text-slate-300 font-semibold">{t.uploadImportFile}</div>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileChange}
                className="text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-white hover:file:bg-slate-700 cursor-pointer"
              />
            </div>

            {/* Success Message */}
            {importedCount !== null && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-200 rounded-xl flex items-center gap-2 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Successfully imported {importedCount} patient records!</span>
              </div>
            )}

            {/* Validation Errors */}
            {importErrors.length > 0 && (
              <div className="p-3.5 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-xl space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>Validation Issues Detected ({importErrors.length}):</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-rose-300 max-h-32 overflow-y-auto">
                  {importErrors.map((err, idx) => (
                    <li key={idx}>Row {err.row}: {err.error}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Preview & Confirmation */}
            {importRows.length > 0 && (
              <div className="space-y-3 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">Parsed {importRows.length} Rows</span>
                  <button
                    disabled={loadingImport}
                    onClick={handleConfirmImport}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl shadow transition"
                  >
                    {loadingImport ? 'Importing...' : t.confirmImport}
                  </button>
                </div>

                <div className="max-h-40 overflow-y-auto bg-slate-950 rounded-lg p-2 font-mono text-[10px] text-slate-400 border border-slate-800">
                  <pre>{JSON.stringify(importRows.slice(0, 3), null, 2)}</pre>
                  {importRows.length > 3 && <div className="text-center italic mt-1">...and {importRows.length - 3} more rows</div>}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
