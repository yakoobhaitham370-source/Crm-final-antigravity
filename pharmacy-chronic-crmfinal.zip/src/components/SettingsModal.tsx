import React, { useState, useEffect } from 'react';
import { 
  X, 
  Settings as SettingsIcon, 
  Database, 
  CheckCircle2, 
  AlertTriangle, 
  Globe, 
  ShieldCheck, 
  Save, 
  RefreshCw,
  Info
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { PharmacySettings } from '../server/types';
import { api } from '../lib/api';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  setLang: (lang: Language) => void;
  settings: PharmacySettings | null;
  onSettingsUpdated: () => void;
}

export default function SettingsModal({
  isOpen,
  onClose,
  lang,
  setLang,
  settings,
  onSettingsUpdated
}: SettingsModalProps) {
  const t = TRANSLATIONS[lang];

  const [formData, setFormData] = useState<PharmacySettings>({
    pharmacyName: '',
    pharmacistInCharge: '',
    contactPhone: '',
    address: '',
    defaultTimezone: 'Asia/Baghdad',
    interfaceLanguage: 'ar',
    reminderIntervalDays: 3,
    whatsappTemplate: '',
    smsTemplate: '',
    enableExternalMessaging: false,
    hasMessagingCredentials: false,
    databaseConfigured: false,
    storageConfigured: false
  });

  const [dbTestResult, setDbTestResult] = useState<{ success: boolean; message: string; dialect: string } | null>(null);
  const [testingDb, setTestingDb] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setFormData(settings);
    }
  }, [settings]);

  if (!isOpen) return null;

  const handleTestDatabase = async () => {
    try {
      setTestingDb(true);
      const res = await api.getDbStatus();
      setDbTestResult(res);
    } catch (err: any) {
      setDbTestResult({
        success: false,
        message: err.message || 'Connection test failed',
        dialect: 'error'
      });
    } finally {
      setTestingDb(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await api.updateSettings(formData);
      onSettingsUpdated();
      alert('Pharmacy settings successfully updated and schedules recalculated.');
      onClose();
    } catch (err: any) {
      alert(err.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-slate-800 text-emerald-400 border border-slate-700 flex items-center justify-center">
              <SettingsIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{t.pharmacySettings}</h2>
              <p className="text-xs text-slate-400">Configure pharmacy identity, intervals, templates, and secure database</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <form onSubmit={handleSave} className="p-6 overflow-y-auto flex-1 space-y-5 text-xs">
          
          {/* Section 1: Pharmacy Identity */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider text-emerald-400">
              Pharmacy Identity
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-slate-300 font-semibold mb-1">{t.pharmacyName} *</label>
                <input
                  type="text"
                  required
                  value={formData.pharmacyName}
                  onChange={(e) => setFormData({ ...formData, pharmacyName: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.pharmacistInCharge}</label>
                <input
                  type="text"
                  value={formData.pharmacistInCharge}
                  onChange={(e) => setFormData({ ...formData, pharmacistInCharge: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.contactPhone}</label>
                <input
                  type="text"
                  value={formData.contactPhone}
                  onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.defaultTimezone}</label>
                <input
                  type="text"
                  value={formData.defaultTimezone}
                  onChange={(e) => setFormData({ ...formData, defaultTimezone: e.target.value })}
                  placeholder="Asia/Baghdad"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Language</label>
                <select
                  value={lang}
                  onChange={(e) => {
                    const l = e.target.value as Language;
                    setLang(l);
                    setFormData({ ...formData, interfaceLanguage: l });
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
                >
                  <option value="ar">{t.arabic}</option>
                  <option value="en">{t.english}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Refill Reminder Interval & Recalculation */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider text-cyan-400">
              Refill Reminder Engine Configuration
            </h3>

            <div className="flex items-center gap-3">
              <div className="w-36">
                <label className="block text-slate-300 font-semibold mb-1">{t.reminderInterval} *</label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  required
                  value={formData.reminderIntervalDays}
                  onChange={(e) => setFormData({ ...formData, reminderIntervalDays: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono text-center font-bold"
                />
              </div>

              <div className="text-slate-400 text-[11px] leading-relaxed flex-1">
                <span className="font-semibold text-slate-300">Recalculation Behavior:</span> {t.reminderIntervalExplanation}
              </div>
            </div>
          </div>

          {/* Section 3: Message Templates */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider text-emerald-400">
              Outreach Templates
            </h3>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">{t.whatsappTemplate}</label>
              <textarea
                rows={2}
                value={formData.whatsappTemplate}
                onChange={(e) => setFormData({ ...formData, whatsappTemplate: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">{t.smsTemplate}</label>
              <textarea
                rows={2}
                value={formData.smsTemplate}
                onChange={(e) => setFormData({ ...formData, smsTemplate: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Section 4: Secure Database Connection (No Client URL Input / No SSRF) */}
          <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5 text-amber-400">
                <Database className="w-4 h-4" />
                <span>{t.dbConnectionStatus}</span>
              </h3>

              <button
                type="button"
                disabled={testingDb}
                onClick={handleTestDatabase}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testingDb ? 'animate-spin' : ''}`} />
                <span>{testingDb ? 'Checking...' : t.testConnection}</span>
              </button>
            </div>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              {t.dbNote}
            </p>

            {/* Test Result Banner */}
            {dbTestResult && (
              <div className={`p-3 rounded-lg border text-xs flex items-start gap-2 ${
                dbTestResult.success 
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200' 
                  : 'bg-amber-950/60 border-amber-800 text-amber-200'
              }`}>
                {dbTestResult.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                )}
                <div>
                  <strong className="block">Status Check Result:</strong>
                  <span>{dbTestResult.message}</span>
                </div>
              </div>
            )}
          </div>

          {/* Footer Submit */}
          <div className="pt-2 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold shadow transition"
            >
              {saving ? 'Saving...' : t.saveSettings}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
