import React, { useState } from 'react';
import { X, CheckSquare, MessageSquare, AlertTriangle, Send, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { Medication, Patient, PharmacySettings } from '../server/types';
import { formatTemplateMessage } from '../lib/calculations';
import { api } from '../lib/api';

interface BulkRefillModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  date: string;
  medications: Array<Medication & { patient?: Patient }>;
  settings: PharmacySettings | null;
  onSuccess: () => void;
}

export default function BulkRefillModal({
  isOpen,
  onClose,
  lang,
  date,
  medications,
  settings,
  onSuccess
}: BulkRefillModalProps) {
  const t = TRANSLATIONS[lang];

  const [messageTemplate, setMessageTemplate] = useState(
    settings?.whatsappTemplate || 'Dear {patient_name}, your chronic medication refill for {medications} is due on {due_date}. CarePlus Pharmacy has your prescription ready. Reply to confirm pickup or delivery.'
  );

  const [channel, setChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [processing, setProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [results, setResults] = useState<Array<{ name: string; phone: string; link: string; optedOut: boolean }>>([]);

  if (!isOpen) return null;

  // Filter out duplicates and separate opted-out patients
  const eligibleRecipients = medications.filter(m => m.patient && !m.patient.optedOut);
  const optedOutRecipients = medications.filter(m => m.patient && m.patient.optedOut);

  // Live preview for first patient
  const samplePatient = eligibleRecipients[0]?.patient;
  const sampleMed = eligibleRecipients[0];
  const sampleCompiledMessage = samplePatient ? formatTemplateMessage(messageTemplate, {
    patient_name: `${samplePatient.firstName} ${samplePatient.lastName}`,
    medications: sampleMed?.drugName || 'medication',
    due_date: sampleMed?.nextRefillDate || date,
    pharmacy_name: settings?.pharmacyName || 'Pharmacy',
    pharmacy_phone: settings?.contactPhone || '+964 770 123 4567'
  }) : '';

  const handleExecuteBatch = async () => {
    try {
      setProcessing(true);
      const linksList: Array<{ name: string; phone: string; link: string; optedOut: boolean }> = [];

      for (const m of eligibleRecipients) {
        if (!m.patient) continue;

        const res = await api.sendMessage({
          patientId: m.patient.id,
          medicationId: m.id,
          channel,
          customMessage: formatTemplateMessage(messageTemplate, {
            patient_name: `${m.patient.firstName} ${m.patient.lastName}`,
            medications: m.drugName,
            due_date: m.nextRefillDate,
            pharmacy_name: settings?.pharmacyName || 'Pharmacy',
            pharmacy_phone: settings?.contactPhone || '+964 770 123 4567'
          })
        });

        linksList.push({
          name: `${m.patient.firstName} ${m.patient.lastName}`,
          phone: m.patient.phoneNumber,
          link: res.link,
          optedOut: false
        });
      }

      setResults(linksList);
      setCompleted(true);
      onSuccess();
    } catch (err: any) {
      alert(err.message || 'Batch execution failed');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{t.bulkReviewTitle}</h2>
              <p className="text-xs text-slate-400">Refill Date: <strong className="text-emerald-400 font-mono">{date}</strong></p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          
          {/* Review Notice */}
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-300">
            {t.bulkReviewDesc}
          </div>

          {/* Opt-out Warning */}
          {optedOutRecipients.length > 0 && (
            <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-xl flex items-center gap-2 text-rose-300">
              <ShieldAlert className="w-4 h-4 flex-shrink-0" />
              <span>
                <strong>{optedOutRecipients.length} patient(s)</strong> have opted out of communications and are automatically excluded from the messaging batch.
              </span>
            </div>
          )}

          {!completed ? (
            <>
              {/* Recipients Review Table */}
              <div className="space-y-2">
                <span className="font-bold text-white block">
                  Eligible Recipients ({eligibleRecipients.length}):
                </span>
                <div className="max-h-44 overflow-y-auto bg-slate-950 border border-slate-800 rounded-xl">
                  <table className="w-full text-left rtl:text-right text-[11px] text-slate-300">
                    <thead className="bg-slate-900 text-slate-400 border-b border-slate-800 sticky top-0">
                      <tr>
                        <th className="py-2 px-3">Patient</th>
                        <th className="py-2 px-3">Phone (+964)</th>
                        <th className="py-2 px-3">Finishing Medication</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {eligibleRecipients.map(m => (
                        <tr key={m.id}>
                          <td className="py-2 px-3 font-semibold text-white">
                            {m.patient?.firstName} {m.patient?.lastName}
                          </td>
                          <td className="py-2 px-3 font-mono text-emerald-400" dir="ltr">
                            {m.patient?.phoneNumber}
                          </td>
                          <td className="py-2 px-3">
                            {m.drugName} ({m.strength})
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Channel Selector */}
              <div className="flex items-center space-x-4 rtl:space-x-reverse pt-2">
                <span className="text-slate-400 font-semibold">Outreach Channel:</span>
                <label className="flex items-center gap-1.5 cursor-pointer text-white">
                  <input
                    type="radio"
                    name="channel"
                    checked={channel === 'whatsapp'}
                    onChange={() => setChannel('whatsapp')}
                    className="text-emerald-600 focus:ring-0"
                  />
                  <span>WhatsApp Handoff</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer text-white">
                  <input
                    type="radio"
                    name="channel"
                    checked={channel === 'sms'}
                    onChange={() => setChannel('sms')}
                    className="text-emerald-600 focus:ring-0"
                  />
                  <span>SMS Handoff</span>
                </label>
              </div>

              {/* Editable Template Text */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Editable Message Text (Supports variables: {'{patient_name}'}, {'{medications}'}, {'{due_date}'}):
                </label>
                <textarea
                  rows={3}
                  value={messageTemplate}
                  onChange={(e) => setMessageTemplate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Live Preview */}
              {samplePatient && (
                <div className="p-3 bg-slate-900/60 rounded-xl border border-emerald-900/40 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 block tracking-wider">
                    Live Message Preview ({samplePatient.firstName}):
                  </span>
                  <p className="text-slate-200 text-xs italic">
                    "{sampleCompiledMessage}"
                  </p>
                </div>
              )}
            </>
          ) : (
            /* Completed Result Links */
            <div className="space-y-3">
              <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-200 rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span>
                  Successfully compiled and prepared {results.length} outreach messages. Click below to trigger safe handoff!
                </span>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {results.map((r, i) => (
                  <div key={i} className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white">{r.name}</div>
                      <div className="font-mono text-emerald-400 text-[10px]" dir="ltr">{r.phone}</div>
                    </div>
                    <a
                      href={r.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow text-xs"
                    >
                      Open {channel === 'whatsapp' ? 'WhatsApp' : 'SMS'}
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
          >
            {t.close}
          </button>

          {!completed && (
            <button
              disabled={processing || eligibleRecipients.length === 0}
              onClick={handleExecuteBatch}
              className="flex items-center gap-1.5 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-emerald-950 transition"
            >
              <Send className="w-4 h-4" />
              <span>{processing ? 'Processing...' : `Confirm & Review (${eligibleRecipients.length})`}</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
