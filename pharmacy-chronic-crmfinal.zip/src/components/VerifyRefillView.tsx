import React, { useEffect, useState } from 'react';
import { Pill, ShieldCheck, AlertTriangle, CheckCircle2, Clock, Calendar } from 'lucide-react';
import { api } from '../lib/api';

interface VerifyRefillViewProps {
  token: string;
  onBackToApp: () => void;
}

export default function VerifyRefillView({ token, onBackToApp }: VerifyRefillViewProps) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchVerification = async () => {
      try {
        setLoading(true);
        const res = await api.verifyThermalToken(token);
        if (res.expired) {
          setError(res.message || 'This prescription verification token has expired.');
        } else {
          setData(res);
        }
      } catch (err: any) {
        setError(err.message || 'Invalid prescription token');
      } finally {
        setLoading(false);
      }
    };

    fetchVerification();
  }, [token]);

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#111827] border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5">
        
        {/* Verification Header */}
        <div className="flex items-center space-x-3 rtl:space-x-reverse border-b border-slate-800 pb-4">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white">Prescription Refill Verification</h1>
            <p className="text-xs text-slate-400">Digital verification of community pharmacy dispensation</p>
          </div>
        </div>

        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-2">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Verifying security token...</p>
          </div>
        ) : error ? (
          <div className="p-4 bg-rose-950/60 border border-rose-800 rounded-2xl text-rose-200 text-xs space-y-2 text-center">
            <AlertTriangle className="w-6 h-6 text-rose-400 mx-auto" />
            <div className="font-bold text-sm">Verification Link Expired or Invalid</div>
            <p className="text-rose-300">{error}</p>
          </div>
        ) : data ? (
          <div className="space-y-4 text-xs">
            
            {/* Pharmacy & Verification Stamp */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-medium">Issuing Pharmacy:</span>
                <strong className="text-white">{data.pharmacyName}</strong>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-medium">Verification Token:</span>
                <span className="font-mono text-emerald-400 font-bold">{data.verificationId}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-medium">Patient:</span>
                <span className="font-semibold text-slate-200">{data.patientName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-medium">Dispense Date:</span>
                <span className="font-mono text-slate-300">{data.refillDate}</span>
              </div>
            </div>

            {/* Verified Medications */}
            <div className="space-y-2">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px] block">
                Verified Chronic Medications:
              </span>
              <div className="space-y-2">
                {data.medications?.map((m: any, idx: number) => (
                  <div key={idx} className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-sm">{m.drugName}</span>
                      <span className="font-mono text-emerald-400 text-xs font-semibold">{m.strength}</span>
                    </div>
                    <p className="text-slate-300 text-xs">{m.dosageInstructions}</p>
                    <div className="pt-1 flex justify-between text-[11px] font-mono text-slate-400">
                      <span>Scheduled Next Refill:</span>
                      <strong className="text-emerald-400">{m.nextRefillDate}</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pharmacist Instructions */}
            {data.instructions && (
              <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 space-y-1 text-slate-300">
                <span className="text-[10px] uppercase font-bold text-slate-400">Pharmacist Notes:</span>
                <p className="text-xs">{data.instructions}</p>
              </div>
            )}

            {/* Security Guarantee */}
            <div className="p-2.5 bg-emerald-950/40 rounded-xl border border-emerald-900/60 text-emerald-300 text-[11px] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Cryptographically verified authenticity. Token expires on {data.expiresAt?.split('T')[0]}.</span>
            </div>

          </div>
        ) : null}

        {/* Back Action */}
        <div className="pt-2 border-t border-slate-800">
          <button
            onClick={onBackToApp}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition"
          >
            ← Back to Pharmacy CRM
          </button>
        </div>

      </div>
    </div>
  );
}
