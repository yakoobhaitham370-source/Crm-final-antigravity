import React, { useState, useEffect } from 'react';
import { 
  Pill, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  Plus, 
  Phone, 
  MessageSquare, 
  FileText, 
  Info,
  ChevronRight,
  X
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { AntibioticFollowup, Patient } from '../server/types';
import { api } from '../lib/api';

interface AntibioticFollowupViewProps {
  lang: Language;
  onSendMessage: (patientId: string, medicationId?: string, channel?: 'whatsapp' | 'sms') => void;
}

export default function AntibioticFollowupView({
  lang,
  onSendMessage
}: AntibioticFollowupViewProps) {
  const t = TRANSLATIONS[lang];

  const [followups, setFollowups] = useState<AntibioticFollowup[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');

  // Contact Log Modal
  const [selectedItem, setSelectedItem] = useState<AntibioticFollowup | null>(null);
  const [contactProgress, setContactProgress] = useState<any>('improving');
  const [pharmacistNotes, setPharmacistNotes] = useState('');
  const [savingContact, setSavingContact] = useState(false);

  // New Course Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newAntibiotic, setNewAntibiotic] = useState({
    patientName: '',
    patientPhone: '+964',
    antibioticName: '',
    dosageAndDuration: '',
    startDate: new Date().toISOString().split('T')[0],
    expectedFollowupDate: new Date().toISOString().split('T')[0],
    pharmacistNotes: ''
  });

  const loadList = async () => {
    try {
      setLoading(true);
      const res = await api.getAntibiotics({
        status: statusFilter,
        search
      });
      setFollowups(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadList();
  }, [statusFilter, search]);

  const handleSaveContact = async () => {
    if (!selectedItem) return;
    try {
      setSavingContact(true);
      await api.updateAntibiotic(selectedItem.id, {
        contactAttempts: selectedItem.contactAttempts + 1,
        lastContactDate: new Date().toISOString().split('T')[0],
        patientReportedProgress: contactProgress,
        status: contactProgress === 'completed_course' ? 'completed' : selectedItem.status,
        pharmacistNotes: pharmacistNotes ? `${selectedItem.pharmacistNotes ? selectedItem.pharmacistNotes + ' | ' : ''}${pharmacistNotes}` : selectedItem.pharmacistNotes
      });
      setSelectedItem(null);
      loadList();
    } catch (err: any) {
      alert(err.message || 'Failed to update contact attempt');
    } finally {
      setSavingContact(false);
    }
  };

  const handleCreateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAntibiotic.antibioticName.trim() || !newAntibiotic.patientName.trim()) {
      alert('Please fill in required fields');
      return;
    }

    try {
      await api.createAntibiotic({
        patientName: newAntibiotic.patientName,
        patientPhone: newAntibiotic.patientPhone,
        antibioticName: newAntibiotic.antibioticName,
        dosageAndDuration: newAntibiotic.dosageAndDuration,
        startDate: newAntibiotic.startDate,
        expectedFollowupDate: newAntibiotic.expectedFollowupDate,
        pharmacistNotes: newAntibiotic.pharmacistNotes
      });
      setIsAddOpen(false);
      setNewAntibiotic({
        patientName: '',
        patientPhone: '+964',
        antibioticName: '',
        dosageAndDuration: '',
        startDate: new Date().toISOString().split('T')[0],
        expectedFollowupDate: new Date().toISOString().split('T')[0],
        pharmacistNotes: ''
      });
      loadList();
    } catch (err: any) {
      alert(err.message || 'Failed to register antibiotic course');
    }
  };

  return (
    <div className="space-y-6">

      {/* NON-DIAGNOSTIC LEGAL & CLINICAL DISCLAIMER BANNER */}
      <div className="p-4 bg-cyan-950/40 border border-cyan-800/80 rounded-2xl flex items-start space-x-3 rtl:space-x-reverse text-cyan-200 text-xs">
        <Info className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block text-cyan-300">
            Clinical Record-Keeping & Follow-Up Communication Only
          </span>
          <p className="mt-0.5 text-cyan-200/90 leading-relaxed">
            {t.antibioticDisclaimer}
          </p>
        </div>
      </div>

      {/* Header and Actions */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Pill className="w-5 h-5 text-cyan-400" />
              <span>{t.antibioticFollowups}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Monitor short-term antimicrobial courses, verify symptom resolution, and document contact attempts.
            </p>
          </div>

          <button
            onClick={() => setIsAddOpen(true)}
            className="flex items-center space-x-1.5 rtl:space-x-reverse px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-950 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Record Antibiotic Course</span>
          </button>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              statusFilter === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-400'
            }`}
          >
            All Courses
          </button>
          <button
            onClick={() => setStatusFilter('due_today')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              statusFilter === 'due_today' ? 'bg-amber-600 text-white' : 'bg-slate-900 text-amber-400'
            }`}
          >
            Due Today
          </button>
          <button
            onClick={() => setStatusFilter('overdue')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              statusFilter === 'overdue' ? 'bg-rose-600 text-white' : 'bg-slate-900 text-rose-400'
            }`}
          >
            Overdue
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              statusFilter === 'completed' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-emerald-400'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Follow-up Cards / Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-2">
            <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Loading antibiotic registries...</p>
          </div>
        ) : followups.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No antibiotic follow-up records found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Patient / Phone</th>
                  <th className="py-3 px-4">Antibiotic & Duration</th>
                  <th className="py-3 px-4">Start Date</th>
                  <th className="py-3 px-4">Expected Follow-Up</th>
                  <th className="py-3 px-4">Attempts</th>
                  <th className="py-3 px-4">Reported Progress</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {followups.map(a => {
                  const isOverdue = a.status === 'overdue';
                  const isDueToday = a.status === 'due_today';

                  return (
                    <tr key={a.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          isOverdue ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          isDueToday ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                          a.status === 'completed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          'bg-slate-800 text-slate-300'
                        }`}>
                          {a.status}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{a.patientName}</div>
                        <div className="font-mono text-[10px] text-slate-400" dir="ltr">{a.patientPhone}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100">{a.antibioticName}</div>
                        <div className="text-[10px] text-cyan-400">{a.dosageAndDuration}</div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-300">{a.startDate}</td>

                      <td className="py-3 px-4 font-mono font-bold">
                        <span className={isOverdue ? 'text-rose-400' : isDueToday ? 'text-amber-400' : 'text-slate-200'}>
                          {a.expectedFollowupDate}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-mono text-center">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-bold">
                          {a.contactAttempts}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="capitalize text-slate-300">{a.patientReportedProgress?.replace('_', ' ')}</span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => {
                            setSelectedItem(a);
                            setContactProgress(a.patientReportedProgress || 'improving');
                            setPharmacistNotes('');
                          }}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-cyan-600/30 hover:bg-cyan-600 text-cyan-300 hover:text-white border border-cyan-500/40 transition"
                        >
                          {t.logContactAttempt}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Log Contact Attempt Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-[#111827] border border-slate-700 w-full max-w-md rounded-2xl p-5 space-y-4 text-xs shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm">Document Antibiotic Contact</h3>
              <button onClick={() => setSelectedItem(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl space-y-1">
              <div>Patient: <strong className="text-white">{selectedItem.patientName}</strong></div>
              <div>Medication: <strong className="text-cyan-400">{selectedItem.antibioticName}</strong></div>
              <div className="font-mono text-slate-400" dir="ltr">{selectedItem.patientPhone}</div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">{t.patientProgress}</label>
              <select
                value={contactProgress}
                onChange={(e) => setContactProgress(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
              >
                <option value="improving">{t.progressImproving}</option>
                <option value="no_change">{t.progressNoChange}</option>
                <option value="worsened">{t.progressWorsened}</option>
                <option value="adverse_reaction">{t.progressAdverse}</option>
                <option value="completed_course">{t.progressCompleted}</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Pharmacist Assessment Notes</label>
              <textarea
                rows={3}
                value={pharmacistNotes}
                onChange={(e) => setPharmacistNotes(e.target.value)}
                placeholder="e.g. Patient contacted via WhatsApp. Confirmed completion of full 7-day course. No fever or gastrointestinal complaints."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                disabled={savingContact}
                onClick={handleSaveContact}
                className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-lg shadow"
              >
                {savingContact ? 'Saving...' : 'Save Follow-Up'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Record New Antibiotic Course Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-[#111827] border border-slate-700 w-full max-w-lg rounded-2xl p-5 space-y-4 text-xs shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm">Record New Antibiotic Course</h3>
              <button onClick={() => setIsAddOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateCourse} className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Patient Full Name *</label>
                <input
                  type="text"
                  required
                  value={newAntibiotic.patientName}
                  onChange={(e) => setNewAntibiotic({ ...newAntibiotic, patientName: e.target.value })}
                  placeholder="e.g. Noor Al-Bayati"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Phone Number (+964) *</label>
                <input
                  type="text"
                  required
                  value={newAntibiotic.patientPhone}
                  onChange={(e) => setNewAntibiotic({ ...newAntibiotic, patientPhone: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Antibiotic Name *</label>
                <input
                  type="text"
                  required
                  value={newAntibiotic.antibioticName}
                  onChange={(e) => setNewAntibiotic({ ...newAntibiotic, antibioticName: e.target.value })}
                  placeholder="e.g. Amoxicillin / Clavulanate (Augmentin)"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Dosage & Duration *</label>
                <input
                  type="text"
                  required
                  value={newAntibiotic.dosageAndDuration}
                  onChange={(e) => setNewAntibiotic({ ...newAntibiotic, dosageAndDuration: e.target.value })}
                  placeholder="e.g. 1g twice daily for 7 days"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">{t.startAntibiotic} *</label>
                  <input
                    type="date"
                    required
                    value={newAntibiotic.startDate}
                    onChange={(e) => setNewAntibiotic({ ...newAntibiotic, startDate: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">{t.expectedFollowup} *</label>
                  <input
                    type="date"
                    required
                    value={newAntibiotic.expectedFollowupDate}
                    onChange={(e) => setNewAntibiotic({ ...newAntibiotic, expectedFollowupDate: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Initial Notes</label>
                <input
                  type="text"
                  value={newAntibiotic.pharmacistNotes}
                  onChange={(e) => setNewAntibiotic({ ...newAntibiotic, pharmacistNotes: e.target.value })}
                  placeholder="e.g. Indication: Dental abscess; instructed on completing entire course"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-lg shadow"
                >
                  Save Antibiotic Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
