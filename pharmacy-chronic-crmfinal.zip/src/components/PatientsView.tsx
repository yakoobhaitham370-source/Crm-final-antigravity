import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Users, 
  UserPlus, 
  AlertTriangle, 
  Phone, 
  MessageSquare, 
  ChevronLeft, 
  ChevronRight, 
  Pill, 
  Trash2, 
  Eye, 
  Link2,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { Patient, Medication } from '../server/types';
import { api } from '../lib/api';

interface PatientsViewProps {
  lang: Language;
  onSelectPatient: (patient: Patient) => void;
  onOpenAddPatient: () => void;
  onOpenRecordRefill: (medication: Medication, patient?: Patient) => void;
  onDeletePatient: (patientId: string) => void;
  onSendMessage: (patientId: string, medicationId?: string, channel?: 'whatsapp' | 'sms') => void;
}

export default function PatientsView({
  lang,
  onSelectPatient,
  onOpenAddPatient,
  onOpenRecordRefill,
  onDeletePatient,
  onSendMessage
}: PatientsViewProps) {
  const t = TRANSLATIONS[lang];

  const [patients, setPatients] = useState<Patient[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [familyCodeFilter, setFamilyCodeFilter] = useState('');
  const [drugFilter, setDrugFilter] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchList = async () => {
    try {
      setLoading(true);
      const res = await api.getPatients({
        page,
        pageSize,
        search,
        status: statusFilter,
        familyCode: familyCodeFilter || undefined,
        drugName: drugFilter || undefined
      });
      setPatients(res.data);
      setTotal(res.total);
    } catch (err) {
      console.error('Failed to load patients:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchList();
  }, [page, pageSize, statusFilter, familyCodeFilter, drugFilter]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchList();
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const totalPages = Math.ceil(total / pageSize) || 1;

  return (
    <div className="space-y-6">

      {/* Top Action and Filters Surface */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Global Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 rtl:left-auto rtl:right-3 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2 pl-9 pr-4 rtl:pl-4 rtl:pr-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
            />
            {search && (
              <button 
                onClick={() => setSearch('')}
                className="absolute right-3 rtl:right-auto rtl:left-3 top-2.5 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          {/* New Patient Registration Button */}
          <button
            onClick={onOpenAddPatient}
            className="flex items-center justify-center space-x-1.5 rtl:space-x-reverse px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950 transition active:scale-95 flex-shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t.addPatient}</span>
          </button>

        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-800/80 text-xs">
          
          {/* Retention Status Filter */}
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <span className="text-slate-400 font-medium">{t.retentionIndicator}:</span>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="all">{t.allStatus}</option>
              <option value="retained">{t.retained}</option>
              <option value="at_risk">{t.atRisk}</option>
              <option value="inactive">{t.inactive}</option>
            </select>
          </div>

          {/* Drug Name Search / Filter */}
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Pill className="w-3.5 h-3.5 text-emerald-400" />
            <input
              type="text"
              value={drugFilter}
              onChange={(e) => {
                setDrugFilter(e.target.value);
                setPage(1);
              }}
              placeholder="Filter by drug name..."
              className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Active Family Code Filter Tag */}
          {familyCodeFilter && (
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse bg-cyan-950/60 border border-cyan-800/60 text-cyan-300 px-2.5 py-1 rounded-lg text-xs">
              <Link2 className="w-3 h-3" />
              <span>Family: {familyCodeFilter}</span>
              <button 
                onClick={() => setFamilyCodeFilter('')}
                className="text-xs hover:text-white font-bold ml-1"
              >
                ✕
              </button>
            </div>
          )}

          {/* Active Drug Filter Tag with Patient Count */}
          {drugFilter && (
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 px-2.5 py-1 rounded-lg text-xs">
              <Pill className="w-3 h-3" />
              <span>{total} {t.drugsSearchCount.replace('{drug}', drugFilter)}</span>
              <button 
                onClick={() => setDrugFilter('')}
                className="text-xs hover:text-white font-bold ml-1"
              >
                ✕
              </button>
            </div>
          )}

          <div className="ml-auto rtl:ml-0 rtl:mr-auto text-slate-400">
            Total Records: <span className="font-semibold text-white">{total}</span>
          </div>

        </div>

      </div>

      {/* Patients Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-3">
            <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Loading patient dossier index...</p>
          </div>
        ) : patients.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            No patient records matched the specified search or filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right text-slate-300">
              <thead className="bg-slate-900/90 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Patient Profile</th>
                  <th className="py-3 px-4">Phone / WhatsApp</th>
                  <th className="py-3 px-4">Family Identifier</th>
                  <th className="py-3 px-4">Allergies (Safety Alert)</th>
                  <th className="py-3 px-4">Retention & PDC Adherence</th>
                  <th className="py-3 px-4">Active Chronic Regimens</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {patients.map(p => {
                  const hasAllergies = p.allergies && p.allergies.toLowerCase() !== 'none reported' && p.allergies.trim() !== '';

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition">
                      
                      {/* Name & File # */}
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-xs flex-shrink-0">
                            {p.firstName[0]}{p.lastName[0]}
                          </div>
                          <div>
                            <div 
                              onClick={() => onSelectPatient(p)}
                              className="font-bold text-white hover:text-emerald-400 cursor-pointer transition"
                            >
                              {p.firstName} {p.lastName}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              File #{p.fileNumber} &bull; {p.gender} &bull; {p.dateOfBirth}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Phone Number */}
                      <td className="py-3 px-4 font-mono text-slate-200" dir="ltr">
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-slate-500" />
                          <span>{p.phoneNumber}</span>
                        </div>
                        {p.optedOut && (
                          <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                            Opted-out
                          </span>
                        )}
                      </td>

                      {/* Family Identifier */}
                      <td className="py-3 px-4">
                        {p.familyCode ? (
                          <button
                            onClick={() => {
                              setFamilyCodeFilter(p.familyCode || '');
                              setPage(1);
                            }}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-cyan-950/60 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/60 transition"
                            title="Filter to view linked family members"
                          >
                            <Link2 className="w-3 h-3" />
                            <span>{p.familyCode}</span>
                          </button>
                        ) : (
                          <span className="text-slate-600 text-[10px]">Individual</span>
                        )}
                      </td>

                      {/* Drug Allergies */}
                      <td className="py-3 px-4">
                        {hasAllergies ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {p.allergies}
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[10px]">{t.noAllergies}</span>
                        )}
                      </td>

                      {/* Retention & Adherence Score */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.retentionStatus === 'retained' 
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                              : p.retentionStatus === 'at_risk'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}>
                            {p.retentionStatus === 'retained' ? t.retained : p.retentionStatus === 'at_risk' ? t.atRisk : t.inactive}
                          </span>
                          <span className="font-mono text-[10px] text-slate-300">
                            {p.retentionScore}% PDC
                          </span>
                        </div>
                      </td>

                      {/* Active Chronic Regimens */}
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {(p.medications || []).slice(0, 2).map(m => (
                            <span key={m.id} className="inline-block px-1.5 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 border border-slate-700 truncate max-w-[140px]">
                              {m.drugName} ({m.strength})
                            </span>
                          ))}
                          {(p.medications || []).length > 2 && (
                            <span className="text-[10px] text-slate-500 font-semibold">
                              +{(p.medications || []).length - 2} more
                            </span>
                          )}
                          {(!p.medications || p.medications.length === 0) && (
                            <span className="text-[10px] text-slate-600 italic">No active meds</span>
                          )}
                        </div>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
                          
                          {/* Dossier Detail */}
                          <button
                            onClick={() => onSelectPatient(p)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
                            title="Open Full Dossier"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Quick WhatsApp Outreach */}
                          {!p.optedOut && (
                            <button
                              onClick={() => onSendMessage(p.id, undefined, 'whatsapp')}
                              className="p-1.5 rounded-lg bg-teal-950 hover:bg-teal-900 text-teal-400 border border-teal-800 transition"
                              title={t.sendWhatsApp}
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Soft Delete / Archive */}
                          <button
                            onClick={() => {
                              if (confirm(`Archive patient ${p.firstName} ${p.lastName}? Important history is preserved.`)) {
                                onDeletePatient(p.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition"
                            title="Archive Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Toolbar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-5 py-3 border-t border-slate-800 text-xs text-slate-400 bg-slate-900/50">
          <div>
            Showing <span className="text-white font-medium">{Math.min(total, (page - 1) * pageSize + 1)}</span> to{' '}
            <span className="text-white font-medium">{Math.min(total, page * pageSize)}</span> of{' '}
            <span className="text-white font-medium">{total}</span> records
          </div>

          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            
            <button
              disabled={page <= 1}
              onClick={() => setPage(p => Math.max(1, p - 1))}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white transition"
            >
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            </button>

            <span className="px-2 py-1 text-slate-200 font-medium">
              Page {page} of {totalPages}
            </span>

            <button
              disabled={page >= totalPages}
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white transition"
            >
              <ChevronRight className="w-4 h-4 rtl:rotate-180" />
            </button>

            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              className="ml-3 rtl:ml-0 rtl:mr-3 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200"
            >
              <option value="10">10 / page</option>
              <option value="15">15 / page</option>
              <option value="25">25 / page</option>
              <option value="50">50 / page</option>
            </select>

          </div>
        </div>

      </div>

    </div>
  );
}
