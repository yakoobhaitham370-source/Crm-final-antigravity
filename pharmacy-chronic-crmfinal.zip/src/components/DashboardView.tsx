import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  Calendar, 
  CheckSquare, 
  MessageSquare, 
  Pill, 
  ChevronRight, 
  Boxes, 
  FileText,
  ShieldAlert
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { DashboardMetrics, Patient, Medication } from '../server/types';
import { api } from '../lib/api';

interface DashboardViewProps {
  metrics: DashboardMetrics | null;
  lang: Language;
  onSelectPatient: (patient: Patient) => void;
  onOpenRecordRefill: (medication: Medication, patient?: Patient) => void;
  onOpenBulkReview: (medications: Array<Medication & { patient?: Patient }>, date: string) => void;
  onOpenThermalSlip: (patientId: string, medicationIds: string[]) => void;
  setActiveTab: (tab: string) => void;
  onSendMessage: (patientId: string, medicationId?: string, channel?: 'whatsapp' | 'sms') => void;
}

export default function DashboardView({
  metrics,
  lang,
  onSelectPatient,
  onOpenRecordRefill,
  onOpenBulkReview,
  onOpenThermalSlip,
  setActiveTab,
  onSendMessage
}: DashboardViewProps) {
  const t = TRANSLATIONS[lang];
  const todayStr = new Date().toISOString().split('T')[0];

  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [dateMedications, setDateMedications] = useState<Array<Medication & { patient?: Patient }>>([]);
  const [loadingDateMeds, setLoadingDateMeds] = useState(false);

  // Load medications due on selected date
  const loadDateMeds = async (date: string) => {
    try {
      setLoadingDateMeds(true);
      const items = await api.getRefillsByDate(date);
      setDateMedications(items);
    } catch (err) {
      console.error('Error fetching refills by date:', err);
    } finally {
      setLoadingDateMeds(false);
    }
  };

  useEffect(() => {
    loadDateMeds(selectedDate);
  }, [selectedDate]);

  return (
    <div className="space-y-6">

      {/* KPI Surface Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Due Today */}
        <div className="bg-[#111827] border border-amber-500/30 rounded-2xl p-5 shadow-lg shadow-amber-950/20 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-amber-400/90">{t.dueToday}</p>
              <h3 className="text-3xl font-bold text-white mt-1">{metrics?.dueTodayCount ?? 0}</h3>
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Ready for preparation</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Card 2: Overdue Refills */}
        <div className="bg-[#111827] border border-rose-500/30 rounded-2xl p-5 shadow-lg shadow-rose-950/20 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-rose-400/90">{t.overdue}</p>
              <h3 className="text-3xl font-bold text-white mt-1">{metrics?.overdueCount ?? 0}</h3>
              <p className="text-xs text-rose-300 mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Treatment gap risk</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Card 3: Due Soon (1-3 days) */}
        <div className="bg-[#111827] border border-cyan-500/30 rounded-2xl p-5 shadow-lg shadow-cyan-950/20 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-cyan-400/90">{t.dueSoon}</p>
              <h3 className="text-3xl font-bold text-white mt-1">{metrics?.dueSoonCount ?? 0}</h3>
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Advance outreach</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center">
              <Calendar className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Card 4: Average Adherence PDC */}
        <div className="bg-[#111827] border border-emerald-500/30 rounded-2xl p-5 shadow-lg shadow-emerald-950/20 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-emerald-400/90">{t.avgAdherence}</p>
              <h3 className="text-3xl font-bold text-white mt-1">{metrics?.averageAdherenceRate ?? 92}%</h3>
              <p className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Target: &gt; 80% PDC</span>
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </div>

      </div>

      {/* Quick Alerts Bar (Antibiotic Follow-ups & Stockouts) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Antibiotic Alert */}
        <div 
          onClick={() => setActiveTab('antibiotics')}
          className="cursor-pointer bg-slate-900/80 hover:bg-slate-900 border border-cyan-800/40 hover:border-cyan-700/60 rounded-xl p-4 transition flex items-center justify-between"
        >
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 rounded-xl bg-cyan-950/80 text-cyan-400 flex items-center justify-center border border-cyan-800/60">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-100">{t.antibioticFollowups}</h4>
              <p className="text-xs text-slate-400">
                {metrics?.pendingAntibioticFollowups ?? 0} active &bull; <span className="text-rose-400 font-medium">{metrics?.overdueAntibioticFollowups ?? 0} overdue</span>
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-500 rtl:rotate-180" />
        </div>

        {/* Stockout Alert */}
        <div 
          onClick={() => setActiveTab('inventory')}
          className="cursor-pointer bg-slate-900/80 hover:bg-slate-900 border border-rose-800/40 hover:border-rose-700/60 rounded-xl p-4 transition flex items-center justify-between"
        >
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 rounded-xl bg-rose-950/80 text-rose-400 flex items-center justify-center border border-rose-800/60">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-100">{t.stockoutAlerts}</h4>
              <p className="text-xs text-slate-400">
                <span className="text-rose-400 font-medium">{metrics?.projectedStockoutsCount ?? 0} items</span> projected to run out based on patient refill schedules
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-500 rtl:rotate-180" />
        </div>

      </div>

      {/* Date-Based Refill Filter & Bulk Action Workbench */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-400" />
              <span>{t.bulkRefillTitle}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Select any calendar date to view patients whose chronic supply runs out on that exact day.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center space-x-2 rtl:space-x-reverse bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-xl">
              <span className="text-xs text-slate-400">{t.purchaseDate}:</span>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-transparent text-xs font-semibold text-white border-none focus:outline-none cursor-pointer"
              />
            </div>

            {/* Quick date chips */}
            <button
              onClick={() => setSelectedDate(todayStr)}
              className={`px-2.5 py-1.5 text-xs rounded-lg border transition ${
                selectedDate === todayStr
                  ? 'bg-emerald-600 text-white border-emerald-500 font-semibold'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {t.dueToday}
            </button>

            {/* Select All on Date Action with Confirmation Step */}
            <button
              disabled={dateMedications.length === 0}
              onClick={() => onOpenBulkReview(dateMedications, selectedDate)}
              className="flex items-center space-x-1.5 rtl:space-x-reverse px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white shadow-md transition"
            >
              <CheckSquare className="w-4 h-4" />
              <span>{t.selectAllOnDate} ({dateMedications.length})</span>
            </button>
          </div>
        </div>

        {/* Results Table for Selected Date */}
        {loadingDateMeds ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-2">
            <div className="w-7 h-7 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Loading scheduled refills...</p>
          </div>
        ) : dateMedications.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs font-medium">
            No patients with medications scheduled to finish on <span className="text-slate-300 font-semibold">{selectedDate}</span>.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Patient / File #</th>
                  <th className="py-3 px-4">Phone / WhatsApp</th>
                  <th className="py-3 px-4">Medication & Strength</th>
                  <th className="py-3 px-4">Instructions</th>
                  <th className="py-3 px-4">Allergies</th>
                  <th className="py-3 px-4">Remaining</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {dateMedications.map(m => {
                  const p = m.patient;
                  const hasAllergies = p?.allergies && p.allergies.toLowerCase() !== 'none reported' && p.allergies.trim() !== '';

                  return (
                    <tr key={m.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <div 
                          onClick={() => p && onSelectPatient(p)}
                          className="cursor-pointer hover:text-emerald-400 transition"
                        >
                          <div className="font-semibold text-white">
                            {p ? `${p.firstName} ${p.lastName}` : 'Unknown'}
                          </div>
                          <div className="text-[10px] font-mono text-slate-400">
                            {p?.fileNumber} {p?.familyCode && `• [${p.familyCode}]`}
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-200" dir="ltr">
                        {p?.phoneNumber}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100">{m.drugName}</div>
                        <div className="text-[10px] text-emerald-400 font-medium">{m.strength}</div>
                      </td>

                      <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                        {m.dosageInstructions}
                      </td>

                      <td className="py-3 px-4">
                        {hasAllergies ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-950/80 text-rose-300 border border-rose-800/60" title={p?.allergies}>
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {p?.allergies}
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[10px]">{t.noAllergies}</span>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          (m.refillsRemaining ?? 0) <= 1 ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-slate-800 text-slate-300'
                        }`}>
                          {m.refillsRemaining ?? 0} left
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center space-x-1.5 rtl:space-x-reverse">
                          
                          {/* Dispense Refill */}
                          <button
                            onClick={() => onOpenRecordRefill(m, p)}
                            className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition"
                            title={t.refillDispense}
                          >
                            {t.refillDispense}
                          </button>

                          {/* WhatsApp Outreach */}
                          {p && !p.optedOut ? (
                            <button
                              onClick={() => onSendMessage(p.id, m.id, 'whatsapp')}
                              className="p-1.5 rounded-lg bg-teal-950/60 hover:bg-teal-900 text-teal-400 border border-teal-800/60 transition"
                              title={t.sendWhatsApp}
                            >
                              <MessageSquare className="w-4 h-4" />
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-600 italic">Opted out</span>
                          )}

                          {/* Thermal Slip */}
                          {p && (
                            <button
                              onClick={() => onOpenThermalSlip(p.id, [m.id])}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                              title={t.thermalSlip}
                            >
                              <FileText className="w-4 h-4" />
                            </button>
                          )}

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
}
