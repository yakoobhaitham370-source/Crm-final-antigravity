import React, { useState } from 'react';
import { X, UserPlus, Phone, AlertTriangle, Link2, Pill, Check } from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { normalizePhoneNumber } from '../lib/calculations';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onAddPatient: (data: any) => Promise<void>;
}

export default function AddPatientModal({
  isOpen,
  onClose,
  lang,
  onAddPatient
}: AddPatientModalProps) {
  const t = TRANSLATIONS[lang];

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '1975-01-01',
    gender: 'Male',
    phoneNumber: '+964',
    whatsappNumber: '+964',
    familyCode: '',
    address: '',
    primaryPhysician: '',
    chronicConditions: [] as string[],
    allergies: 'None reported',
    optedOut: false,
    notes: '',
    // Initial medication
    includeMed: true,
    medName: '',
    strength: '',
    instructions: '',
    daysSupply: 30,
    purchaseDate: new Date().toISOString().split('T')[0]
  });

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handlePhoneChange = (val: string) => {
    setFormData(prev => ({
      ...prev,
      phoneNumber: val,
      whatsappNumber: prev.whatsappNumber === prev.phoneNumber || prev.whatsappNumber === '+964' ? val : prev.whatsappNumber
    }));
  };

  const toggleCondition = (cond: string) => {
    setFormData(prev => {
      const exists = prev.chronicConditions.includes(cond);
      return {
        ...prev,
        chronicConditions: exists
          ? prev.chronicConditions.filter(c => c !== cond)
          : [...prev.chronicConditions, cond]
      };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.firstName.trim() || !formData.lastName.trim()) {
      setError('First name and last name are required.');
      return;
    }

    const phoneCheck = normalizePhoneNumber(formData.phoneNumber);
    if (!phoneCheck.valid) {
      setError('Please provide a valid Iraqi (+964) or international phone number.');
      return;
    }

    if (formData.includeMed && (!formData.medName.trim() || Number(formData.daysSupply) <= 0)) {
      setError('Please provide a valid medication name and positive days supply.');
      return;
    }

    try {
      setSubmitting(true);
      await onAddPatient({
        firstName: formData.firstName.trim(),
        lastName: formData.lastName.trim(),
        dateOfBirth: formData.dateOfBirth,
        gender: formData.gender,
        phoneNumber: phoneCheck.normalized,
        whatsappNumber: normalizePhoneNumber(formData.whatsappNumber).normalized || phoneCheck.normalized,
        familyCode: formData.familyCode.trim() || undefined,
        address: formData.address.trim(),
        primaryPhysician: formData.primaryPhysician.trim(),
        chronicConditions: formData.chronicConditions,
        allergies: formData.allergies.trim() || 'None reported',
        optedOut: formData.optedOut,
        notes: formData.notes,
        // medication data if included
        includeMedication: formData.includeMed,
        medication: formData.includeMed ? {
          drugName: formData.medName.trim(),
          strength: formData.strength.trim(),
          dosageInstructions: formData.instructions.trim() || 'Take as directed',
          daysSupply: Number(formData.daysSupply),
          purchaseDate: formData.purchaseDate
        } : null
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create patient');
    } finally {
      setSubmitting(false);
    }
  };

  const COMMON_CONDITIONS = [
    'Hypertension',
    'Type 2 Diabetes',
    'Dyslipidemia',
    'Asthma / COPD',
    'Heart Failure',
    'Ischemic Heart Disease'
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Register Chronic Patient</h2>
              <p className="text-xs text-slate-400">Enroll new patient in adherence monitoring registry</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          
          {error && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-xl font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Demographic Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">First Name *</label>
              <input
                type="text"
                required
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="e.g. Ahmed"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Last Name / Family Name *</label>
              <input
                type="text"
                required
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="e.g. Al-Saadi"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Date of Birth *</label>
              <input
                type="date"
                required
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Gender</label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Phone Number (Iraq default +964) *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={formData.phoneNumber}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  placeholder="+964 770 123 4567"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Family Code / Relatives Identifier
              </label>
              <input
                type="text"
                value={formData.familyCode}
                onChange={(e) => setFormData({ ...formData, familyCode: e.target.value })}
                placeholder="e.g. FAM-MANSOUR-101"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                Links household members together without merging records.
              </span>
            </div>
          </div>

          {/* Prominent Drug Allergies Input */}
          <div className="p-3.5 bg-rose-950/40 border border-rose-900/60 rounded-xl space-y-1">
            <label className="text-xs font-bold text-rose-300 flex items-center gap-1.5 uppercase tracking-wider">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{t.allergies} (Prominent Clinical Safety Reminder)</span>
            </label>
            <input
              type="text"
              value={formData.allergies}
              onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
              placeholder="e.g. Penicillin (Hives/Swelling), Sulfa drugs, Aspirin (None reported if none)"
              className="w-full bg-slate-950 border border-rose-800/80 rounded-lg p-2 text-rose-100 placeholder-rose-700/60 text-xs focus:outline-none focus:border-rose-400"
            />
          </div>

          {/* Chronic Diagnoses Chips */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Chronic Conditions</label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_CONDITIONS.map(cond => {
                const active = formData.chronicConditions.includes(cond);
                return (
                  <button
                    key={cond}
                    type="button"
                    onClick={() => toggleCondition(cond)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition ${
                      active
                        ? 'bg-emerald-600 text-white border-emerald-500'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    {active && <Check className="w-3 h-3 inline mr-1" />}
                    {cond}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Initial Medication Checkbox & Accordion */}
          <div className="pt-2 border-t border-slate-800">
            <label className="flex items-center gap-2 cursor-pointer text-slate-300 font-semibold mb-2">
              <input
                type="checkbox"
                checked={formData.includeMed}
                onChange={(e) => setFormData({ ...formData, includeMed: e.target.checked })}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-0"
              />
              <span>Include Initial Chronic Medication Regimen</span>
            </label>

            {formData.includeMed && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-900 rounded-xl border border-slate-700/70">
                <div>
                  <label className="block text-slate-400 mb-1">Medication Name *</label>
                  <input
                    type="text"
                    value={formData.medName}
                    onChange={(e) => setFormData({ ...formData, medName: e.target.value })}
                    placeholder="e.g. Amlodipine"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Strength *</label>
                  <input
                    type="text"
                    value={formData.strength}
                    onChange={(e) => setFormData({ ...formData, strength: e.target.value })}
                    placeholder="e.g. 5mg"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Dosage Instructions</label>
                  <input
                    type="text"
                    value={formData.instructions}
                    onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                    placeholder="e.g. 1 tablet once daily in morning"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Purchase Date *</label>
                  <input
                    type="date"
                    value={formData.purchaseDate}
                    onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Days Supply *</label>
                  <input
                    type="number"
                    min="1"
                    value={formData.daysSupply}
                    onChange={(e) => setFormData({ ...formData, daysSupply: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Communication Opt-out Toggle */}
          <div className="pt-2 border-t border-slate-800">
            <label className="flex items-center gap-2 cursor-pointer text-slate-400">
              <input
                type="checkbox"
                checked={formData.optedOut}
                onChange={(e) => setFormData({ ...formData, optedOut: e.target.checked })}
                className="w-4 h-4 rounded text-rose-600 focus:ring-0"
              />
              <span>Patient explicitly opts out of WhatsApp & SMS outreach</span>
            </label>
          </div>

          {/* Submit Actions */}
          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-emerald-950 transition"
            >
              {submitting ? 'Registering...' : 'Register Patient'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
