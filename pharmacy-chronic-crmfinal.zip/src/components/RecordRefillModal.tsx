import React, { useState, useEffect } from 'react';
import { X, Check, Calendar, AlertTriangle, Pill, Clock } from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { Medication, Patient, PharmacySettings } from '../server/types';
import { calculateNextRefillDate, calculateNextReminderDate } from '../lib/calculations';

interface RecordRefillModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  medication: Medication | null;
  patient: Patient | null;
  settings: PharmacySettings | null;
  onRecordRefill: (data: {
    medicationId: string;
    purchaseDate: string;
    daysSupply: number;
    quantityDispensed: number;
    notes?: string;
  }) => Promise<void>;
}

export default function RecordRefillModal({
  isOpen,
  onClose,
  lang,
  medication,
  patient,
  settings,
  onRecordRefill
}: RecordRefillModalProps) {
  const t = TRANSLATIONS[lang];

  const todayStr = new Date().toISOString().split('T')[0];

  const [purchaseDate, setPurchaseDate] = useState(todayStr);
  const [daysSupply, setDaysSupply] = useState(30);
  const [quantityDispensed, setQuantityDispensed] = useState(30);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (medication) {
      setPurchaseDate(todayStr);
      setDaysSupply(medication.daysSupply || 30);
      setQuantityDispensed(medication.quantityPerRefill || 30);
    }
  }, [medication]);

  if (!isOpen || !medication) return null;

  const reminderInterval = settings?.reminderIntervalDays || 3;
  let previewNextRefill = '';
  let previewNextReminder = '';

  try {
    previewNextRefill = calculateNextRefillDate(purchaseDate, Number(daysSupply) || 30);
    previewNextReminder = calculateNextReminderDate(previewNextRefill, reminderInterval);
  } catch {}

  const hasAllergies = patient?.allergies && patient.allergies.toLowerCase() !== 'none reported' && patient.allergies.trim() !== '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (Number(daysSupply) <= 0) {
      setError('Days supply must be a positive integer greater than zero.');
      return;
    }

    try {
      setSubmitting(true);
      await onRecordRefill({
        medicationId: medication.id,
        purchaseDate,
        daysSupply: Number(daysSupply),
        quantityDispensed: Number(quantityDispensed),
        notes
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to record refill');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{t.refillDispense}</h2>
              <p className="text-xs text-slate-400">Update dispense date & recalculate next schedule</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          
          {error && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-xl font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Patient Context & Medication Name */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-1">
            <div className="text-slate-400 flex justify-between">
              <span>Patient: <strong className="text-white">{patient ? `${patient.firstName} ${patient.lastName}` : 'Patient'}</strong></span>
              <span className="font-mono text-emerald-400">{patient?.fileNumber}</span>
            </div>
            <div className="text-sm font-bold text-white pt-1 flex items-center gap-2">
              <span>{medication.drugName}</span>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                {medication.strength}
              </span>
            </div>
            <p className="text-xs text-slate-400">{medication.dosageInstructions}</p>
          </div>

          {/* CRITICAL ALLERGY REMINDER */}
          {hasAllergies && (
            <div className="p-3 bg-rose-950/60 border border-rose-800 text-rose-200 rounded-xl flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <div>
                <span className="font-bold uppercase tracking-wider block text-[10px]">Safety Allergy Reminder:</span>
                <span>{patient?.allergies}</span>
              </div>
            </div>
          )}

          {/* Dispense Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                {t.purchaseDate} (Editable) *
              </label>
              <input
                type="date"
                required
                value={purchaseDate}
                onChange={(e) => setPurchaseDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                {t.daysSupply} (Positive number) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={daysSupply}
                onChange={(e) => setDaysSupply(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Quantity Dispensed
              </label>
              <input
                type="number"
                min="1"
                required
                value={quantityDispensed}
                onChange={(e) => setQuantityDispensed(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Refills Remaining
              </label>
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-300 font-mono">
                {Math.max(0, (medication.refillsRemaining ?? 1) - 1)} left after dispense
              </div>
            </div>
          </div>

          {/* Real-time Schedule Calculation Preview */}
          <div className="p-3 bg-slate-900/90 rounded-xl border border-emerald-900/40 space-y-1 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span className="font-sans text-slate-400">Calculated Next Refill Date:</span>
              <strong className="text-emerald-400">{previewNextRefill}</strong>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="font-sans text-slate-400">Next Reminder Date ({reminderInterval}d advance):</span>
              <strong className="text-cyan-400">{previewNextReminder}</strong>
            </div>
          </div>

          {/* Pharmacist Counseling Notes */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Patient Counseling Notes & Blood Pressure / Vitals (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Counselled on evening dosing. Patient reported good tolerance. BP 124/80."
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-emerald-950 transition"
            >
              {submitting ? 'Dispensing...' : 'Confirm & Dispense'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
