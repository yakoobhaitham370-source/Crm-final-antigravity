import React, { useState, useEffect } from 'react';
import { 
  Boxes, 
  AlertTriangle, 
  TrendingUp, 
  Edit3, 
  Info, 
  CheckCircle2, 
  Clock, 
  ShieldAlert,
  Save,
  X
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { InventoryItem } from '../server/types';
import { api } from '../lib/api';

interface InventoryForecastViewProps {
  lang: Language;
}

export default function InventoryForecastView({ lang }: InventoryForecastViewProps) {
  const t = TRANSLATIONS[lang];

  const [planningDays, setPlanningDays] = useState(30);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  // Edit stock modal state
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [editStock, setEditStock] = useState(0);
  const [editMin, setEditMin] = useState(20);
  const [editLead, setEditLead] = useState(7);
  const [saving, setSaving] = useState(false);

  const loadForecast = async () => {
    try {
      setLoading(true);
      const res = await api.getInventoryForecast(planningDays);
      setItems(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadForecast();
  }, [planningDays]);

  const handleSaveStock = async () => {
    if (!editingItem) return;
    try {
      setSaving(true);
      await api.updateInventoryItem(editingItem.id, {
        currentStock: Number(editStock),
        minimumStockThreshold: Number(editMin),
        supplierLeadTimeDays: Number(editLead)
      });
      setEditingItem(null);
      loadForecast();
    } catch (err: any) {
      alert(err.message || 'Failed to update inventory item');
    } finally {
      setSaving(false);
    }
  };

  const criticalStockouts = items.filter(i => i.isStockoutProjected);

  return (
    <div className="space-y-6">

      {/* Assumptions & Methodology Transparency Box */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-start space-x-3 rtl:space-x-reverse text-slate-300 text-xs">
        <Info className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold text-white uppercase tracking-wider block">
            {t.inventoryDemandEngine} — Transparent Planning Assumptions
          </span>
          <p className="text-slate-400 leading-relaxed">
            {t.inventoryAssumptions} Projections calculate exact quantities required by summing each active patient’s purchase date plus validated days supply. Missing or zero-day regimens are automatically flagged and excluded to prevent skewed procurement estimates.
          </p>
        </div>
      </div>

      {/* Top Controls Surface */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Boxes className="w-5 h-5 text-emerald-400" />
              <span>Chronic Inventory & Refill Demand Forecast</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Aggregated from active patient refill cycles to anticipate supply shortages.
            </p>
          </div>

          <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs">
            <span className="text-slate-400 font-medium">Planning Horizon:</span>
            <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => setPlanningDays(7)}
                className={`px-3 py-1 rounded-lg font-semibold transition ${
                  planningDays === 7 ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                7 Days
              </button>
              <button
                onClick={() => setPlanningDays(14)}
                className={`px-3 py-1 rounded-lg font-semibold transition ${
                  planningDays === 14 ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                14 Days
              </button>
              <button
                onClick={() => setPlanningDays(30)}
                className={`px-3 py-1 rounded-lg font-semibold transition ${
                  planningDays === 30 ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                30 Days
              </button>
            </div>
          </div>
        </div>

        {/* Warning if stockouts exist */}
        {criticalStockouts.length > 0 && (
          <div className="p-3.5 bg-rose-950/60 border border-rose-800 text-rose-200 rounded-xl text-xs flex items-center justify-between">
            <div className="flex items-center space-x-2 rtl:space-x-reverse font-semibold">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>
                {criticalStockouts.length} medications have projected demand exceeding safety thresholds within the next {planningDays} days.
              </span>
            </div>
            <span className="text-[10px] uppercase font-bold text-rose-300 px-2 py-0.5 bg-rose-900 rounded border border-rose-700">
              Supplier Re-order Urgently Needed
            </span>
          </div>
        )}
      </div>

      {/* Forecast Data Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-2">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Computing demand matrix from chronic timelines...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Medication</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Current Stock</th>
                  <th className="py-3 px-4">Demand (7d)</th>
                  <th className="py-3 px-4">Demand (14d)</th>
                  <th className="py-3 px-4">Demand (30d)</th>
                  <th className="py-3 px-4">Lead Time</th>
                  <th className="py-3 px-4">Stock-Out Status</th>
                  <th className="py-3 px-4 text-center">Manage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {items.map(item => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{item.drugName}</div>
                      <div className="text-[10px] text-emerald-400 font-mono">{item.strength}</div>
                    </td>

                    <td className="py-3 px-4 text-slate-400">
                      {item.category}
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {item.currentStock} {item.unit}
                    </td>

                    <td className="py-3 px-4 font-mono text-cyan-300">
                      {item.forecast7d}
                    </td>

                    <td className="py-3 px-4 font-mono text-cyan-400 font-semibold">
                      {item.forecast14d}
                    </td>

                    <td className="py-3 px-4 font-mono text-cyan-500 font-bold">
                      {item.forecast30d}
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-400">
                      {item.supplierLeadTimeDays} days
                    </td>

                    <td className="py-3 px-4">
                      {item.isStockoutProjected ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                          <AlertTriangle className="w-3 h-3" />
                          <span>{t.stockoutWarning}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Adequate</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => {
                          setEditingItem(item);
                          setEditStock(item.currentStock);
                          setEditMin(item.minimumStockThreshold);
                          setEditLead(item.supplierLeadTimeDays);
                        }}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                        title="Update Stock Levels"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Stock Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-[#111827] border border-slate-700 w-full max-w-sm rounded-2xl p-5 space-y-4 text-xs shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm">Update Stock Thresholds</h3>
              <button onClick={() => setEditingItem(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl space-y-1">
              <div className="font-bold text-white">{editingItem.drugName}</div>
              <div className="text-emerald-400 font-mono">{editingItem.strength}</div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.currentStock}</label>
                <input
                  type="number"
                  min="0"
                  value={editStock}
                  onChange={(e) => setEditStock(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.minThreshold}</label>
                <input
                  type="number"
                  min="0"
                  value={editMin}
                  onChange={(e) => setEditMin(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">{t.supplierLeadTime}</label>
                <input
                  type="number"
                  min="1"
                  value={editLead}
                  onChange={(e) => setEditLead(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleSaveStock}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow"
              >
                {saving ? 'Saving...' : 'Save Parameters'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
