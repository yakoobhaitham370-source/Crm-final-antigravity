import React, { useState, useEffect } from 'react';
import { X, Printer, Download, Share2, ShieldCheck, Pill, QrCode } from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { PharmacySettings, Patient, Medication } from '../server/types';
import { api } from '../lib/api';
import QRCode from 'qrcode';

interface ThermalSlipModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  patientId: string;
  medicationIds: string[];
  settings: PharmacySettings | null;
}

export default function ThermalSlipModal({
  isOpen,
  onClose,
  lang,
  patientId,
  medicationIds,
  settings
}: ThermalSlipModalProps) {
  const t = TRANSLATIONS[lang];

  const [loading, setLoading] = useState(true);
  const [tokenData, setTokenData] = useState<{ token: string; url: string; expiresAt: string } | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [patient, setPatient] = useState<Patient | null>(null);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [instructions, setInstructions] = useState('Take medications with meals as directed. Store below 25°C away from direct sunlight.');

  useEffect(() => {
    if (!isOpen || !patientId) return;

    const generateSlip = async () => {
      try {
        setLoading(true);
        // Fetch patient
        const pt = await api.getPatientById(patientId);
        setPatient(pt);
        const selectedMeds = (pt.medications || []).filter(m => medicationIds.includes(m.id));
        setMedications(selectedMeds.length > 0 ? selectedMeds : (pt.medications || []).slice(0, 2));

        // Create secure non-guessable expiring token
        const res = await api.createThermalToken({
          patientId,
          medicationIds,
          instructions
        });
        setTokenData(res);

        // Generate QR code pointing to secure expiring URL (never raw health data)
        const fullUrl = `${window.location.origin}${res.url}`;
        const qr = await QRCode.toDataURL(fullUrl, {
          width: 140,
          margin: 1,
          color: {
            dark: '#000000',
            light: '#ffffff'
          }
        });
        setQrDataUrl(qr);
      } catch (err) {
        console.error('Failed to create thermal slip token:', err);
      } finally {
        setLoading(false);
      }
    };

    generateSlip();
  }, [isOpen, patientId]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    if (!patient || !tokenData) return;
    const shareText = `Refill Verification Slip from ${settings?.pharmacyName}:\nVerify prescription schedule securely here: ${window.location.origin}${tokenData.url}`;
    const cleanPhone = patient.phoneNumber.replace(/^\+/, '');
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Printer className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-white text-xs">{t.thermalSlip}</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          
          {/* Privacy Notice Alert */}
          <div className="p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded-xl flex items-center gap-2 text-emerald-300 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{t.thermalNotice}</span>
          </div>

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-2">
              <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-slate-400 text-xs">Generating secure verification receipt...</p>
            </div>
          ) : (
            <>
              {/* Thermal Slip Printable Surface (58mm/80mm format) */}
              <div 
                id="thermal-receipt-printable" 
                className="bg-white text-black p-4 rounded-xl shadow-inner font-mono text-[11px] leading-tight space-y-2.5 max-w-[280px] mx-auto border border-slate-300"
                dir="ltr"
              >
                {/* Pharmacy Header */}
                <div className="text-center border-b border-dashed border-black pb-2">
                  <div className="font-bold text-xs uppercase">{settings?.pharmacyName || 'COMMUNITY PHARMACY'}</div>
                  <div className="text-[10px]">{settings?.address || 'Baghdad, Iraq'}</div>
                  <div className="text-[10px]">Tel: {settings?.contactPhone || '+964 770 123 4567'}</div>
                  <div className="text-[9px] mt-1 text-slate-700">CHRONIC MEDICATION REFILL SLIP</div>
                </div>

                {/* Patient & Date Meta */}
                <div className="flex justify-between text-[10px] border-b border-dashed border-black pb-1.5">
                  <div>
                    <span>Date: {new Date().toISOString().split('T')[0]}</span>
                    <br />
                    <span>Patient: {patient ? `${patient.firstName} ${patient.lastName.slice(0, 1)}.` : 'Patient'}</span>
                  </div>
                  <div className="text-right">
                    <span>File: {patient?.fileNumber}</span>
                    <br />
                    <span>Token: {tokenData?.token.slice(0, 8).toUpperCase()}</span>
                  </div>
                </div>

                {/* Medications List */}
                <div className="space-y-1.5 border-b border-dashed border-black pb-2">
                  <div className="font-bold text-[10px] uppercase">Dispensed Items:</div>
                  {medications.map(m => (
                    <div key={m.id} className="text-[10px]">
                      <div className="font-bold">{m.drugName} {m.strength}</div>
                      <div className="italic text-[9px]">{m.dosageInstructions}</div>
                      <div className="text-[9px] text-slate-700">
                        Supply: {m.daysSupply}d &bull; Next Refill: {m.nextRefillDate}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Instructions */}
                <div className="text-[10px] border-b border-dashed border-black pb-2">
                  <span className="font-bold uppercase text-[9px] block">Pharmacist Instructions:</span>
                  <p className="text-[9px] mt-0.5 leading-snug">{instructions}</p>
                </div>

                {/* QR Code (Expires in 7 days, access-controlled) */}
                <div className="flex flex-col items-center justify-center pt-1">
                  {qrDataUrl && (
                    <img src={qrDataUrl} alt="Verification QR" className="w-24 h-24 object-contain" />
                  )}
                  <span className="text-[8px] uppercase tracking-wider text-slate-600 mt-0.5">
                    Scan for digital verification & reminders
                  </span>
                  <span className="text-[7px] text-slate-500">
                    Expires: {tokenData?.expiresAt.split('T')[0]}
                  </span>
                </div>
              </div>

              {/* Editable Instructions Input */}
              <div className="space-y-1 pt-2">
                <label className="block text-slate-400 text-[11px] font-semibold">
                  Custom Receipt Instructions:
                </label>
                <input
                  type="text"
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                />
              </div>
            </>
          )}

        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
          >
            {t.close}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-950 hover:bg-teal-900 text-teal-300 border border-teal-800 text-xs font-semibold"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.print}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
