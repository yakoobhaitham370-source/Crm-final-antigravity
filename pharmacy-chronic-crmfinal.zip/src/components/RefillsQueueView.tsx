import React, { useState, useEffect } from 'react';
import { 
  CalendarClock, 
  Search, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  CheckSquare, 
  Pill, 
  MessageSquare, 
  FileText,
  User
} from 'lucide-react';
import { TRANSLATIONS, Language } from '../lib/i18n';
import { Medication, Patient, PharmacySettings } from '../server/types';
import { api } from '../lib/api';

interface RefillsQueueViewProps {
  lang: Language;
  settings: PharmacySettings | null;
  onSelectPatient: (patient: Patient) => void;
  onOpenRecordRefill: (medication: Medication, patient?: Patient) => void;
  onOpenBulkReview: (medications: Array<Medication & { patient?: Patient }>, date: string) => void;
  onOpenThermalSlip: (patientId: string, medicationIds: string[]) => void;
  onSendMessage: (patientId: string, medicationId?: string, channel?: 'whatsapp' | 'sms') => void;
}

export default function RefillsQueueView({
  lang,
  settings,
  onSelectPatient,
  onOpenRecordRefill,
  onOpenBulkReview,
  onOpenThermalSlip,
  onSendMessage
}: RefillsQueueViewProps) {
  const t = TRANSLATIONS[lang];
  const todayStr = new Date().toISOString().split('T')[0];

  const [activeFilter, setActiveFilter] = useState<'all' | 'due_today' | 'overdue' | 'due_soon'>('all');
  const [targetDate, setTargetDate] = useState<string>(todayStr);
  const [search, setSearch] = useState('');
  const [medications, setMedications] = useState<Array<Medication & { patient?: Patient }>>([]);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      // Fetch patients and populate medications
      const res = await api.getPatients({ page: 1, pageSize: 100 });
      const flatMeds: Array<Medication & { patient?: Patient }> = [];
      res.data.forEach(p => {
        (p.medications || []).forEach(m => {
          flatMeds.push({ ...m, patient: p });
        });
      });
      setMedications(flatMeds);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter list
  const filtered = medications.filter(m => {
    if (activeFilter === 'overdue' && m.refillStatus !== 'overdue') return false;
    if (activeFilter === 'due_today' && m.refillStatus !== 'due_today') return false;
    if (activeFilter === 'due_soon' && m.refillStatus !== 'due_soon') return false;

    if (search) {
      const q = search.toLowerCase();
      const pt = m.patient;
      const matchDrug = m.drugName.toLowerCase().includes(q);
      const matchPatient = pt && (
        pt.firstName.toLowerCase().includes(q) ||
        pt.lastName.toLowerCase().includes(q) ||
        pt.phoneNumber.includes(q) ||
        pt.fileNumber.toLowerCase().includes(q)
      );
      if (!matchDrug && !matchPatient) return false;
    }

    return true;
  });

  // Items due on target date for bulk action
  const dueOnTargetDate = medications.filter(m => m.nextRefillDate === targetDate);

  return (
    <div className="space-y-6">

      {/* Workbench Header & Batch Date Selector */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <CalendarClock className="w-5 h-5 text-emerald-400" />
              <span>{t.refillsQueue}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Organized by clinical urgency to prevent chronic therapy gaps and non-adherence.
            </p>
          </div>

          {/* Bulk Date Workflow Container */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-900 border border-slate-700/80 p-2 rounded-xl">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 px-2">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>Target Refill Date:</span>
            </span>

            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
            />

            <button
              disabled={dueOnTargetDate.length === 0}
              onClick={() => onOpenBulkReview(dueOnTargetDate, targetDate)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow transition"
            >
              <CheckSquare className="w-3.5 h-3.5" />
              <span>{t.selectAllOnDate} ({dueOnTargetDate.length})</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar & Status Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 text-xs">
          
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeFilter === 'all'
                  ? 'bg-slate-700 text-white font-semibold'
                  : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
              }`}
            >
              All Scheduled ({medications.length})
            </button>

            <button
              onClick={() => setActiveFilter('due_today')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeFilter === 'due_today'
                  ? 'bg-amber-600 text-white font-semibold'
                  : 'bg-slate-900 text-amber-400 hover:bg-slate-800'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>{t.dueToday}</span>
            </button>

            <button
              onClick={() => setActiveFilter('overdue')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeFilter === 'overdue'
                  ? 'bg-rose-600 text-white font-semibold'
                  : 'bg-slate-900 text-rose-400 hover:bg-slate-800'
              }`}
            >
              <AlertTriangle className="w-3 h-3" />
              <span>{t.overdue}</span>
            </button>

            <button
              onClick={() => setActiveFilter('due_soon')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeFilter === 'due_soon'
                  ? 'bg-cyan-600 text-white font-semibold'
                  : 'bg-slate-900 text-cyan-400 hover:bg-slate-800'
              }`}
            >
              <Calendar className="w-3 h-3" />
              <span>{t.dueSoon}</span>
            </button>
          </div>

          {/* Quick Search in Queue */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 rtl:left-auto rtl:right-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search in refill queue..."
              className="bg-slate-900 border border-slate-700 rounded-lg py-1.5 pl-8 pr-3 rtl:pl-3 rtl:pr-8 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

        </div>

      </div>

      {/* Queue Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-2">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-400">Loading scheduled refills...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No medications match the active status or search filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right text-slate-300">
              <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Urgency</th>
                  <th className="py-3 px-4">Patient / Contact</th>
                  <th className="py-3 px-4">Medication & Strength</th>
                  <th className="py-3 px-4">Refill Due Date</th>
                  <th className="py-3 px-4">Advance Reminder</th>
                  <th className="py-3 px-4">Refills Left</th>
                  <th className="py-3 px-4 text-center">Dispense & Outreach</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.map(m => {
                  const p = m.patient;
                  const isOverdue = m.refillStatus === 'overdue';
                  const isDueToday = m.refillStatus === 'due_today';
                  const isDueSoon = m.refillStatus === 'due_soon';

                  return (
                    <tr key={m.id} className="hover:bg-slate-800/40 transition">
                      
                      {/* Urgency Badge */}
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          isOverdue ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                          isDueToday ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                          isDueSoon ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' :
                          'bg-slate-800 text-slate-300'
                        }`}>
                          {isOverdue && <AlertTriangle className="w-3 h-3" />}
                          {isDueToday && <Clock className="w-3 h-3" />}
                          {isDueSoon && <Calendar className="w-3 h-3" />}
                          <span className="uppercase">{m.refillStatus.replace('_', ' ')}</span>
                        </span>
                      </td>

                      {/* Patient */}
                      <td className="py-3 px-4">
                        <div 
                          onClick={() => p && onSelectPatient(p)}
                          className="cursor-pointer hover:text-emerald-400 transition"
                        >
                          <div className="font-semibold text-white">
                            {p ? `${p.firstName} ${p.lastName}` : 'Unknown'}
                          </div>
                          <div className="text-[10px] font-mono text-slate-400" dir="ltr">
                            {p?.phoneNumber} {p?.familyCode && `• [${p.familyCode}]`}
                          </div>
                        </div>
                      </td>

                      {/* Medication */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-100">{m.drugName}</div>
                        <div className="text-[10px] text-emerald-400 font-medium">{m.strength} &bull; {m.dosageInstructions}</div>
                      </td>

                      {/* Next Refill Date */}
                      <td className="py-3 px-4 font-mono font-bold">
                        <span className={isOverdue ? 'text-rose-400' : isDueToday ? 'text-amber-400' : 'text-slate-200'}>
                          {m.nextRefillDate}
                        </span>
                      </td>

                      {/* Next Reminder Date */}
                      <td className="py-3 px-4 font-mono text-cyan-400">
                        {m.nextReminderDate}
                      </td>

                      {/* Refills Remaining */}
                      <td className="py-3 px-4 font-mono">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          (m.refillsRemaining ?? 0) <= 1 ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-slate-800 text-slate-300'
                        }`}>
                          {m.refillsRemaining ?? 0}
                        </span>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center space-x-1.5 rtl:space-x-reverse">
                          
                          {/* Dispense Refill Modal */}
                          <button
                            onClick={() => onOpenRecordRefill(m, p)}
                            className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition"
                          >
                            {t.refillDispense}
                          </button>

                          {/* WhatsApp Direct */}
                          {p && !p.optedOut && (
                            <button
                              onClick={() => onSendMessage(p.id, m.id, 'whatsapp')}
                              className="p-1.5 rounded-lg bg-teal-950 hover:bg-teal-900 text-teal-400 border border-teal-800 transition"
                              title={t.sendWhatsApp}
                            >
                              <MessageSquare className="w-4 h-4" />
                            </button>
                          )}

                          {/* Thermal Slip */}
                          {p && (
                            <button
                              onClick={() => onOpenThermalSlip(p.id, [m.id])}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                              title={t.thermalSlip}
                            >
                              <FileText className="w-4 h-4" />
                            </button>
                          )}

                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
}
