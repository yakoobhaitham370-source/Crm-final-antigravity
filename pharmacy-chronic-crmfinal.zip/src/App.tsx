import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import DashboardView from './components/DashboardView';
import PatientsView from './components/PatientsView';
import RefillsQueueView from './components/RefillsQueueView';
import AntibioticFollowupView from './components/AntibioticFollowupView';
import InventoryForecastView from './components/InventoryForecastView';
import ReportsAndImportView from './components/ReportsAndImportView';
import PatientDetailModal from './components/PatientDetailModal';
import AddPatientModal from './components/AddPatientModal';
import RecordRefillModal from './components/RecordRefillModal';
import SettingsModal from './components/SettingsModal';
import BulkRefillModal from './components/BulkRefillModal';
import ThermalSlipModal from './components/ThermalSlipModal';
import VerifyRefillView from './components/VerifyRefillView';

import { TRANSLATIONS, Language } from './lib/i18n';
import { api } from './lib/api';
import { Patient, Medication, PharmacySettings, DashboardMetrics } from './server/types';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Application Data States
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [settings, setSettings] = useState<PharmacySettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Modals
  const [selectedPatient, setSelectedPatient] = useState<(Patient & { medications?: Medication[]; refillLogs?: any[]; familyMembers?: Patient[] }) | null>(null);
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const [refillModal, setRefillModal] = useState<{
    isOpen: boolean;
    medication: Medication | null;
    patient: Patient | null;
  }>({ isOpen: false, medication: null, patient: null });

  const [bulkReviewModal, setBulkReviewModal] = useState<{
    isOpen: boolean;
    date: string;
    medications: Array<Medication & { patient?: Patient }>;
  }>({ isOpen: false, date: '', medications: [] });

  const [thermalSlipModal, setThermalSlipModal] = useState<{
    isOpen: boolean;
    patientId: string;
    medicationIds: string[];
  }>({ isOpen: false, patientId: '', medicationIds: [] });

  // Verification Token from URL (e.g. /verify-refill?token=...)
  const [verifyToken, setVerifyToken] = useState<string | null>(null);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Sync RTL and language on html root element
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Check URL parameters for QR scan token
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    if (token) {
      setVerifyToken(token);
    }
  }, []);

  // Fetch initial metrics and settings
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const [met, set] = await Promise.all([
        api.getDashboardMetrics(),
        api.getSettings()
      ]);
      setMetrics(met);
      setSettings(set);
      if (set.interfaceLanguage) {
        setLang(set.interfaceLanguage);
      }
    } catch (err) {
      console.error('Failed to load initial data:', err);
      showToast('Error connecting to backend services', 'error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Handler: Add Patient
  const handleAddPatient = async (patientFormData: any) => {
    try {
      const { includeMedication, medication, ...ptDetails } = patientFormData;
      const created = await api.createPatient(ptDetails);

      if (includeMedication && medication) {
        await api.addMedication(created.id, medication);
      }

      await loadData();
      showToast(`Patient ${created.firstName} ${created.lastName} registered successfully`);
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      throw err;
    }
  };

  // Handler: Record Refill
  const handleRecordRefill = async (data: {
    medicationId: string;
    purchaseDate: string;
    daysSupply: number;
    quantityDispensed: number;
    notes?: string;
  }) => {
    try {
      const res = await api.recordRefill(data);
      await loadData();
      showToast(`Refill dispensed successfully for ${res.medication.drugName}`);

      if (selectedPatient) {
        const refreshed = await api.getPatientById(selectedPatient.id);
        setSelectedPatient(refreshed);
      }
    } catch (err: any) {
      showToast(err.message || 'Refill recording failed', 'error');
      throw err;
    }
  };

  // Handler: Delete Patient
  const handleDeletePatient = async (patientId: string) => {
    try {
      await api.deletePatient(patientId);
      if (selectedPatient?.id === patientId) setSelectedPatient(null);
      await loadData();
      showToast('Patient record archived');
    } catch (err: any) {
      showToast(err.message || 'Archive failed', 'error');
    }
  };

  // Handler: Send Message
  const handleSendMessage = async (patientId: string, medicationId?: string, channel: 'whatsapp' | 'sms' = 'whatsapp') => {
    try {
      const res = await api.sendMessage({ patientId, medicationId, channel });
      showToast(`Opening safe ${channel === 'whatsapp' ? 'WhatsApp' : 'SMS'} handoff...`, 'info');
      // Open handoff URL
      window.open(res.link, '_blank');
    } catch (err: any) {
      showToast(err.message || 'Message dispatch failed', 'error');
    }
  };

  // Refresh selected patient modal
  const refreshSelectedPatient = async () => {
    if (selectedPatient) {
      const refreshed = await api.getPatientById(selectedPatient.id);
      setSelectedPatient(refreshed);
    }
    loadData();
  };

  // If in QR verification view
  if (verifyToken) {
    return (
      <VerifyRefillView
        token={verifyToken}
        onBackToApp={() => {
          setVerifyToken(null);
          window.history.replaceState({}, '', window.location.pathname);
        }}
      />
    );
  }

  const t = TRANSLATIONS[lang];

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-white">
      
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed bottom-5 right-5 rtl:right-auto rtl:left-5 z-50 px-4 py-3 rounded-xl shadow-2xl border text-xs font-semibold flex items-center space-x-2 rtl:space-x-reverse animate-in slide-in-from-bottom-5 duration-200 ${
          toast.type === 'error'
            ? 'bg-rose-950 text-rose-200 border-rose-800'
            : toast.type === 'info'
            ? 'bg-cyan-950 text-cyan-200 border-cyan-800'
            : 'bg-emerald-950 text-emerald-200 border-emerald-800'
        }`}>
          <span className={`w-2 h-2 rounded-full ${
            toast.type === 'error' ? 'bg-rose-400' : toast.type === 'info' ? 'bg-cyan-400' : 'bg-emerald-400'
          }`} />
          <span>{toast.message}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        settings={settings}
        onOpenAddPatient={() => setIsAddPatientOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        urgentCount={metrics?.overdueCount ?? 0}
        dueTodayCount={metrics?.dueTodayCount ?? 0}
        stockoutCount={metrics?.projectedStockoutsCount ?? 0}
      />

      {/* Main Tab Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        {loading && !metrics ? (
          <div className="flex flex-col items-center justify-center py-28 space-y-3">
            <div className="w-10 h-10 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-xs text-slate-400 font-medium">Connecting to Pharmacy Adherence Database...</p>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <DashboardView
                metrics={metrics}
                lang={lang}
                onSelectPatient={(pt) => setSelectedPatient(pt)}
                onOpenRecordRefill={(m, pt) => setRefillModal({ isOpen: true, medication: m, patient: pt || null })}
                onOpenBulkReview={(meds, date) => setBulkReviewModal({ isOpen: true, medications: meds, date })}
                onOpenThermalSlip={(ptId, mIds) => setThermalSlipModal({ isOpen: true, patientId: ptId, medicationIds: mIds })}
                setActiveTab={setActiveTab}
                onSendMessage={handleSendMessage}
              />
            )}

            {activeTab === 'patients' && (
              <PatientsView
                lang={lang}
                onSelectPatient={(pt) => setSelectedPatient(pt)}
                onOpenAddPatient={() => setIsAddPatientOpen(true)}
                onOpenRecordRefill={(m, pt) => setRefillModal({ isOpen: true, medication: m, patient: pt || null })}
                onDeletePatient={handleDeletePatient}
                onSendMessage={handleSendMessage}
              />
            )}

            {activeTab === 'refills' && (
              <RefillsQueueView
                lang={lang}
                settings={settings}
                onSelectPatient={(pt) => setSelectedPatient(pt)}
                onOpenRecordRefill={(m, pt) => setRefillModal({ isOpen: true, medication: m, patient: pt || null })}
                onOpenBulkReview={(meds, date) => setBulkReviewModal({ isOpen: true, medications: meds, date })}
                onOpenThermalSlip={(ptId, mIds) => setThermalSlipModal({ isOpen: true, patientId: ptId, medicationIds: mIds })}
                onSendMessage={handleSendMessage}
              />
            )}

            {activeTab === 'antibiotics' && (
              <AntibioticFollowupView
                lang={lang}
                onSendMessage={handleSendMessage}
              />
            )}

            {activeTab === 'inventory' && (
              <InventoryForecastView
                lang={lang}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsAndImportView
                lang={lang}
                onRefreshPatients={loadData}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-[#0f172a] py-4 mt-auto text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>{settings?.pharmacyName || t.appTitle} &bull; Community Chronic Patient Refill Tracking</span>
          <span className="flex items-center space-x-2 rtl:space-x-reverse font-mono text-[11px] text-slate-400">
            <span>Netlify Functions</span>
            <span>&bull;</span>
            <span className={settings?.databaseConfigured ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
              {settings?.databaseConfigured ? 'PostgreSQL Active' : 'Local DB Demo'}
            </span>
            <span>&bull;</span>
            <span>RTL Ready</span>
          </span>
        </div>
      </footer>

      {/* Modals */}
      {selectedPatient && (
        <PatientDetailModal
          patient={selectedPatient}
          lang={lang}
          onClose={() => setSelectedPatient(null)}
          onRefresh={refreshSelectedPatient}
          onOpenRecordRefill={(m, pt) => setRefillModal({ isOpen: true, medication: m, patient: pt || selectedPatient })}
          onOpenThermalSlip={(ptId, mIds) => setThermalSlipModal({ isOpen: true, patientId: ptId, medicationIds: mIds })}
          onSendMessage={handleSendMessage}
          onFilterFamily={(famCode) => {
            setSelectedPatient(null);
            setActiveTab('patients');
          }}
        />
      )}

      {isAddPatientOpen && (
        <AddPatientModal
          isOpen={isAddPatientOpen}
          onClose={() => setIsAddPatientOpen(false)}
          lang={lang}
          onAddPatient={handleAddPatient}
        />
      )}

      {refillModal.isOpen && refillModal.medication && (
        <RecordRefillModal
          isOpen={refillModal.isOpen}
          medication={refillModal.medication}
          patient={refillModal.patient}
          settings={settings}
          lang={lang}
          onClose={() => setRefillModal({ isOpen: false, medication: null, patient: null })}
          onRecordRefill={handleRecordRefill}
        />
      )}

      {bulkReviewModal.isOpen && (
        <BulkRefillModal
          isOpen={bulkReviewModal.isOpen}
          date={bulkReviewModal.date}
          medications={bulkReviewModal.medications}
          settings={settings}
          lang={lang}
          onClose={() => setBulkReviewModal({ isOpen: false, date: '', medications: [] })}
          onSuccess={loadData}
        />
      )}

      {thermalSlipModal.isOpen && (
        <ThermalSlipModal
          isOpen={thermalSlipModal.isOpen}
          patientId={thermalSlipModal.patientId}
          medicationIds={thermalSlipModal.medicationIds}
          settings={settings}
          lang={lang}
          onClose={() => setThermalSlipModal({ isOpen: false, patientId: '', medicationIds: [] })}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          lang={lang}
          setLang={setLang}
          settings={settings}
          onSettingsUpdated={loadData}
        />
      )}

    </div>
  );
}
