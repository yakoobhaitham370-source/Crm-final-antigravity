/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Cairo', 'Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      colors: {
        dark: {
          bg: '#0b0f19',
          surface: '#111827',
          surfaceElevated: '#1e293b',
          border: '#334155',
          borderLight: '#1e293b',
          textMuted: '#94a3b8',
          textPrimary: '#f8fafc',
        }
      }
    },
  },
  plugins: [],
}
