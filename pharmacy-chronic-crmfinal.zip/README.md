# PharmaTrack CRM: Chronic Patient Medication Tracker & Adherence Hub
### Production-Minded Community Pharmacy Web Application (English & Arabic RTL)

PharmaTrack is a dark-mode clinical CRM engineered for community pharmacies to track chronic disease patients (Hypertension, Type 2 Diabetes, Dyslipidemia, Asthma/COPD, Heart Failure), monitor refill timelines, automate patient follow-up, and anticipate inventory demand.

It comfortably handles **at least 3,000 patient records** with sub-10ms paginated queries and is ready for 1-click deployment on a **free Netlify account** with protected **Netlify Functions** and hosted **PostgreSQL** (Neon, Supabase, or RDS).

---

## 🌟 Architecture & Stack

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Netlify Edge CDN                                │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │            React 18 + TypeScript + Tailwind CSS (Dark)         │   │
│   │         Full Bilingual UI (English LTR & Arabic RTL)           │   │
│   └───────────────────────────────┬────────────────────────────────┘   │
└───────────────────────────────────┼────────────────────────────────────┘
                                    │ /api/*
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Netlify Functions                               │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │             Protected Serverless API Router (api.ts)           │   │
│   │       Role-Based Access Control (Admin / Pharmacist / Staff)   │   │
│   └───────────────────────┬────────────────────────┬───────────────┘   │
└───────────────────────────┼────────────────────────┼───────────────────┘
                            │                        │
                            ▼                        ▼
     ┌─────────────────────────────┐   ┌─────────────────────────────┐
     │    PostgreSQL Database      │   │   Private Object Storage    │
     │   (Neon / Supabase / RDS)   │   │  (Supabase Storage / S3)    │
     │      Drizzle ORM Schema     │   │   Expiring Signed Tokens    │
     └─────────────────────────────┘   └─────────────────────────────┘
```

- **Frontend**: React 18, TypeScript, Tailwind CSS with full dark-mode palette and bidirectional typography (Cairo and Inter).
- **Backend**: Netlify Functions (`netlify/functions/api.ts`) for protected server-side operations, rate limiting, and sanitization. In local development, an integrated Vite dev middleware executes the exact same API router seamlessly without external daemons.
- **Database Layer**: Migration-managed PostgreSQL with typed query layer via **Drizzle ORM** (`src/db/schema.ts`, `drizzle/0000_initial_schema.sql`). High-performance indexing on `patients(file_number)`, `patients(phone_number)`, `patients(family_code)`, `medications(patient_id)`, and `medications(next_refill_date)`.
- **Private File Storage**: Encrypted object storage abstraction for patient photos and documents. Files are **never stored publicly or directly in database rows**. Access is mediated through expiring signed download tokens (`/api/documents/stream?token=...`).
- **Security & Privacy**: Zero credentials exposed to frontend code or client settings. Formula injection protection (`'`, `=`, `+`, `-`, `@`) on all spreadsheet exports. Safe WhatsApp click-to-chat and SMS compose handoffs.

---

## 📋 Core Features

### 1. Bilingual Support & Native Arabic RTL Layout
- Instant toggle between **English** and **العربية (Arabic)**.
- Full right-to-left layout in Arabic: mirrored navigation, cards, tables, modals, input text alignments, and directional icons.
- Preserves readable direction (`dir="ltr"`) for phone numbers (`+964...`), calendar dates, dosages, and drug codes in both modes.

### 2. High-Performance Dashboard & Date-Based Refill Filter
- KPI Surface Cards: **Refills Due Today**, **Overdue Refills**, **Due Soon (1-3 Days)**, and **Average Adherence (PDC)**.
- **Run-Out Date Picker**: Pick any date to view all patients whose chronic supply finishes on that exact day.
- **"Select All Due on This Date" Action**: Batch outreach modal with a required review step before sending messages.

### 3. Patient Profiles & Chronic Dossiers
- **Demographics**: Full name, normalized Iraqi phone (`+964`), date of birth, address, physician, and notes.
- **Patient Photo**: Secure upload, preview, replacement, and removal with mime-type checking and 3MB size limit.
- **Family Code / Relatives Identifier**: Links related patients (e.g. `FAM-MANSOUR-101`) to view family members together without merging individual medical records.
- **Prominent Allergy Safety Section**: Visually distinguished warning banner, independently editable, and highlighted across all refill workflows without making unsupported diagnostic claims.
- **Multiple Medications per Patient**: Complete regimen list per patient dossier.
- **Patient Retention Adherence Calculator**: Transparent Proportion of Days Covered (PDC proxy) comparison between expected refill dates and recorded purchases. Clearly labeled as an administrative indicator. Authorized users can manually override status (`retained`, `at_risk`, `inactive`) with reason and date.
- **Document Vault**: Upload prescription scans and laboratory results (PDF, JPG, PNG) with file size validation (max 8MB) and secure expiring retrieval tokens.

### 4. Medication & Refill Workflow
- Capture drug name, strength, dosage instructions, purchase date (editable with date picker), and days supply (validated positive integer).
- Automatically calculates:
  - $\text{Next Refill Date} = \text{Purchase Date} + \text{Days Supply}$
  - $\text{Next Reminder Date} = \text{Next Refill Date} - \text{Configured Reminder Interval}$ (defaults to 3 days).
- **Configurable Reminder Interval**: Authorized users can update the interval (e.g. from 3 days to 5 days) in Settings; all active medication reminder dates are recalculated automatically.
- Dispensing a refill records an **immutable audit trail** in `refill_audit_logs`.

### 5. Antibiotic Follow-Up Workflow
- Dedicated antimicrobial tracking tab for short-term courses (e.g. Amoxicillin, Ciprofloxacin, Azithromycin).
- Tracks start date, expected follow-up date, contact attempts, and patient-reported progress (`improving`, `no_change`, `worsened`, `adverse_reaction`, `completed_course`).
- Highlights overdue follow-ups.
- **Clear Clinical Disclaimer**: Displays prominent banner stating that the tool is strictly for administrative communication and record-keeping, not diagnostic medical advice.

### 6. Messages & Communication
- Editable WhatsApp and SMS message templates with dynamic placeholders: `{patient_name}`, `{medications}`, `{due_date}`, `{pharmacy_name}`, `{pharmacy_phone}`.
- Iraq (+964) default calling code while preserving valid international numbers.
- **Safe Fallback**: WhatsApp Click-to-Chat handoff (`https://wa.me/964...`) and SMS compose handoff when no provider credentials exist.
- **Opt-Out Protection**: Consent field (`optedOut`); system blocks messaging to opted-out patients.
- **Batch Messaging Review**: Displays preview table with recipient names, destination phone numbers, and final message text before sending.

### 7. Pocket Thermal Slip & Expiring QR Code
- Printer-friendly thermal receipt formatted for standard **58mm and 80mm** receipt printers with clean print styles (`@media print`).
- Configurable pharmacy name, masked patient name (privacy-preserving), medication instructions, and date.
- **Expiring Non-Guessable QR Code**: Points to `/verify-refill?token=...` with a 7-day expiration. **No sensitive patient diagnosis or raw medical history is encoded in the QR code or URL**.
- Verification view for scanning the slip and validating refill authenticity.

### 8. Inventory Demand Forecasting Engine
- Aggregates active patients' exact refill timelines by drug.
- Forecasts quantities for **7 Days**, **14 Days**, and **30 Days**.
- Flags **Critical Stock-Out Warnings** when current stock falls below projected demand.
- Manage current stock, safety thresholds, and supplier lead times.
- Transparent assumptions box explaining days supply math; excludes missing or inconsistent records with explanations.

### 9. Reports, Import & Export
- **Spreadsheet Formula Injection Defense**: Neutralizes formula triggers (`=`, `+`, `-`, `@`, `\t`, `\r`) with leading single quotes.
- Export patient registry, refill workbench, and inventory forecasts to **Excel (.xlsx)** and **CSV**.
- **Batch Patient Import**: Downloadable Excel template, column mapping preview, row validation, duplicate phone and file number detection, and confirmation before import.

### 10. Settings & Security
- Editable pharmacy name, pharmacist in charge, phone, timezone (`Asia/Baghdad`), and interface language.
- Configurable reminder interval in days with recalculation explanation.
- **Zero Client Credential Exposure**: Database connection string is never entered or stored in the browser. Configured exclusively as a Netlify environment variable (`DATABASE_URL`).
- **Server-Side Database Test**: One-click connection test button calls `/api/system/db-status` and returns sanitized status (connected vs local demo mode) with zero credentials leaked and zero SSRF risk.

---

## 🚀 Quick Start & Local Development

### Prerequisites
- Node.js 18+ or 20+
- npm 9+

### 1. Clone & Install
```bash
git clone https://github.com/your-username/pharmacy-chronic-crm.git
cd pharmacy-chronic-crm
npm install
```

### 2. Run Local Development Server
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.
The built-in Vite dev API middleware executes the Netlify Functions backend automatically with the persistent local store and seed data.

### 3. Run Automated Tests
```bash
npm test
```
Executes all 30 automated unit, integration, and scale tests across 9 test suites:
- Days supply positive number validation
- Refill and reminder date calendar math
- Urgency categorization (overdue, due today, due soon)
- Iraqi phone normalization (+964) and international numbers
- Patient retention PDC proxy score calculation
- Spreadsheet formula injection protection
- Netlify Functions API integration workflows
- Opt-out blocking verification
- Expiring QR token generation and verification
- 3,000+ patient records scale benchmark (<10ms response)

### 4. Build for Production
```bash
npm run build
```
Type-checks with `tsc` and bundles optimized assets into `dist/`.

---

## 🗄️ Database Setup & Provisioning

PharmaTrack uses **PostgreSQL**. You can use any hosted PostgreSQL provider (Neon, Supabase, AWS RDS, Railway).

### Option 1: Neon Serverless PostgreSQL (Recommended)
1. Create a free database on [Neon.tech](https://neon.tech).
2. Copy the Connection String:
   `postgresql://username:password@ep-sample-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require`
3. Run the schema migration:
   ```bash
   DATABASE_URL="your-connection-string" npm run db:migrate
   ```
4. (Optional) Seed realistic chronic patient data:
   ```bash
   DATABASE_URL="your-connection-string" npm run seed
   ```

### Option 2: Supabase PostgreSQL
1. Create a project at [Supabase.com](https://supabase.com).
2. Go to **Project Settings &rarr; Database &rarr; Connection string (URI)**.
3. Apply migration using `npm run db:migrate` or paste `drizzle/0000_initial_schema.sql` into the Supabase SQL Editor.

---

## ☁️ Netlify Deployment Configuration

### Step 1: Deploy with Netlify CLI or Git
1. Push the repository to GitHub:
   ```bash
   git add .
   git commit -m "Deploy PharmaTrack Chronic CRM"
   git push origin main
   ```
2. In Netlify Dashboard, select **Add new site &rarr; Import an existing project &rarr; Select repository**.
3. Build Settings are automatically configured from [`netlify.toml`](file:///data/data/com.termux/files/home/pharmacy-chronic-crm/netlify.toml):
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
   - **Functions directory**: `netlify/functions`

### Step 2: Configure Environment Variables in Netlify
Go to **Site configuration &rarr; Environment variables** in your Netlify dashboard and add:

| Variable Name | Description | Example |
| :--- | :--- | :--- |
| `DATABASE_URL` | Hosted PostgreSQL connection string | `postgresql://user:pass@ep-xyz.neon.tech/pharmacy_db?sslmode=require` |
| `DEFAULT_TIMEZONE` | Pharmacy operational timezone | `Asia/Baghdad` |
| `AUTH_SECRET_KEY` | 32-byte random hex string | `a7b8c9d0e1f2...` |
| `STORAGE_BUCKET_NAME` | (Optional) Private storage bucket | `pharmacy-private-docs` |
| `WHATSAPP_API_TOKEN` | (Optional) Meta WhatsApp Cloud API | `EAAX...` |
| `TWILIO_ACCOUNT_SID` | (Optional) Twilio SMS provider | `AC...` |

*(Note: If messaging or storage credentials are not provided, PharmaTrack operates with its safe WhatsApp click-to-chat handoff, SMS compose workflows, and access-controlled private server storage without failing).*

---

## 🧪 Short Manual Verification Checklist

Follow this checklist to verify key workflows in under 3 minutes:

1. **Language & RTL Check**: Click the language switcher in the header. Switch to **العربية**. Verify that navigation, table columns, and form labels flip to RTL, while phone numbers (`+964...`) and drug names remain readable. Switch back to **English**.
2. **Patient Registration**: Click **"+ New Patient"**. Register a patient with first name, last name, phone `07701234567`, family code `FAM-MANSOUR-101`, and allergy `Penicillin`. Click Register. Verify that the phone number is normalized to `+9647701234567` and the prominent allergy alert appears.
3. **Refill Dispense & Date Math**: Click on a patient to open their dossier. Click **"Record Refill Dispense"** on a medication. Change days supply to `60`. Notice the real-time calculation preview updates next refill to +60 days and reminder to +57 days. Click **Confirm & Dispense**. Verify the schedule updates and an entry appears in **Dispense & Refill Audit History**.
4. **Thermal Slip & Expiring QR**: Click the **Thermal Slip** icon next to a medication. Verify the 58mm/80mm preview renders with pharmacy name, masked patient name, and verification QR code. Click **"Print Receipt"** and verify that only the receipt prints.
5. **Bulk Outreach Review**: On the Dashboard, pick a date or click **"Select All Due On This Date"**. Verify the review modal displays eligible recipients, message preview, and excludes opted-out patients.
6. **Server-Side Database Test**: Open **Settings**. Click **"Test Server-Side Database Connection"**. Verify the connection status reports success or local demo mode without disclosing connection credentials or URLs.
7. **Export Protection**: Go to **Reports & Import**. Click **Export Patient Registry (.XLSX)**. Verify that the file downloads cleanly with formula injection protection enabled.
