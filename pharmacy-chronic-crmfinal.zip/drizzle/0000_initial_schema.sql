-- ============================================================================
-- COMMUNITY PHARMACY CHRONIC PATIENT CRM & REFILL TRACKER
-- PRODUCTION POSTGRESQL SCHEMA MIGRATION 0000
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PATIENTS TABLE
CREATE TABLE IF NOT EXISTS "patients" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "file_number" varchar(50) NOT NULL UNIQUE,
  "first_name" varchar(100) NOT NULL,
  "last_name" varchar(100) NOT NULL,
  "date_of_birth" date NOT NULL,
  "gender" varchar(20) DEFAULT 'Other' NOT NULL,
  "phone_number" varchar(30) NOT NULL,
  "whatsapp_number" varchar(30) NOT NULL,
  "address" text,
  "family_code" varchar(50),
  "emergency_contact_name" varchar(100),
  "emergency_contact_phone" varchar(30),
  "primary_physician" varchar(100),
  "physician_phone" varchar(30),
  "preferred_channel" varchar(20) DEFAULT 'WhatsApp' NOT NULL,
  "chronic_conditions" jsonb DEFAULT '[]'::jsonb,
  "allergies" text DEFAULT 'None reported',
  "retention_status" varchar(30) DEFAULT 'retained' NOT NULL,
  "retention_score" numeric(5, 2) DEFAULT 95.00,
  "retention_reason" text,
  "retention_updated_at" timestamptz DEFAULT now(),
  "photo_url" text,
  "opted_out" boolean DEFAULT false NOT NULL,
  "is_deleted" boolean DEFAULT false NOT NULL,
  "deleted_at" timestamptz,
  "notes" text,
  "created_at" timestamptz DEFAULT now() NOT NULL,
  "updated_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_patients_file_number" ON "patients" ("file_number");
CREATE INDEX IF NOT EXISTS "idx_patients_phone" ON "patients" ("phone_number");
CREATE INDEX IF NOT EXISTS "idx_patients_family_code" ON "patients" ("family_code");
CREATE INDEX IF NOT EXISTS "idx_patients_names" ON "patients" ("last_name", "first_name");
CREATE INDEX IF NOT EXISTS "idx_patients_deleted" ON "patients" ("is_deleted");

-- 2. MEDICATIONS TABLE
CREATE TABLE IF NOT EXISTS "medications" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "drug_name" varchar(200) NOT NULL,
  "strength" varchar(100) NOT NULL,
  "dosage_instructions" text NOT NULL,
  "purchase_date" date NOT NULL,
  "days_supply" integer NOT NULL,
  "next_refill_date" date NOT NULL,
  "next_reminder_date" date NOT NULL,
  "refill_status" varchar(30) DEFAULT 'active' NOT NULL,
  "refills_authorized" integer DEFAULT 6,
  "refills_remaining" integer DEFAULT 5,
  "quantity_per_refill" integer DEFAULT 30,
  "prescribing_doctor" varchar(100),
  "notes" text,
  "is_deleted" boolean DEFAULT false NOT NULL,
  "deleted_at" timestamptz,
  "created_at" timestamptz DEFAULT now() NOT NULL,
  "updated_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_medications_patient" ON "medications" ("patient_id");
CREATE INDEX IF NOT EXISTS "idx_medications_drug_name" ON "medications" ("drug_name");
CREATE INDEX IF NOT EXISTS "idx_medications_next_refill" ON "medications" ("next_refill_date");
CREATE INDEX IF NOT EXISTS "idx_medications_next_reminder" ON "medications" ("next_reminder_date");
CREATE INDEX IF NOT EXISTS "idx_medications_status" ON "medications" ("refill_status");
CREATE INDEX IF NOT EXISTS "idx_medications_deleted" ON "medications" ("is_deleted");

-- 3. REFILL AUDIT LOGS
CREATE TABLE IF NOT EXISTS "refill_audit_logs" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "medication_id" uuid NOT NULL REFERENCES "medications"("id") ON DELETE CASCADE,
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "action" varchar(50) NOT NULL,
  "previous_purchase_date" date,
  "new_purchase_date" date NOT NULL,
  "previous_days_supply" integer,
  "new_days_supply" integer NOT NULL,
  "quantity_dispensed" integer NOT NULL,
  "performed_by" varchar(100) NOT NULL,
  "refill_compliance" varchar(30) DEFAULT 'On Time',
  "notes" text,
  "created_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_refill_audit_patient" ON "refill_audit_logs" ("patient_id");
CREATE INDEX IF NOT EXISTS "idx_refill_audit_med" ON "refill_audit_logs" ("medication_id");
CREATE INDEX IF NOT EXISTS "idx_refill_audit_created" ON "refill_audit_logs" ("created_at");

-- 4. ANTIBIOTIC FOLLOW-UPS
CREATE TABLE IF NOT EXISTS "antibiotic_followups" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "antibiotic_name" varchar(200) NOT NULL,
  "dosage_and_duration" varchar(200) NOT NULL,
  "start_date" date NOT NULL,
  "expected_followup_date" date NOT NULL,
  "contact_attempts" integer DEFAULT 0 NOT NULL,
  "last_contact_date" date,
  "patient_reported_progress" varchar(50) DEFAULT 'pending',
  "status" varchar(30) DEFAULT 'pending' NOT NULL,
  "pharmacist_notes" text,
  "disclaimer_acknowledged" boolean DEFAULT true NOT NULL,
  "created_at" timestamptz DEFAULT now() NOT NULL,
  "updated_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_antibiotic_patient" ON "antibiotic_followups" ("patient_id");
CREATE INDEX IF NOT EXISTS "idx_antibiotic_date" ON "antibiotic_followups" ("expected_followup_date");
CREATE INDEX IF NOT EXISTS "idx_antibiotic_status" ON "antibiotic_followups" ("status");

-- 5. PATIENT DOCUMENTS
CREATE TABLE IF NOT EXISTS "patient_documents" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "document_type" varchar(50) NOT NULL,
  "file_name" varchar(255) NOT NULL,
  "file_size" integer NOT NULL,
  "mime_type" varchar(100) NOT NULL,
  "storage_path" text NOT NULL,
  "notes" text,
  "uploaded_by" varchar(100) NOT NULL,
  "is_deleted" boolean DEFAULT false NOT NULL,
  "created_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_documents_patient" ON "patient_documents" ("patient_id");
CREATE INDEX IF NOT EXISTS "idx_documents_type" ON "patient_documents" ("document_type");

-- 6. INVENTORY ITEMS
CREATE TABLE IF NOT EXISTS "inventory_items" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "drug_name" varchar(200) NOT NULL UNIQUE,
  "strength" varchar(100) NOT NULL,
  "category" varchar(100) DEFAULT 'General Chronic' NOT NULL,
  "current_stock" integer DEFAULT 0 NOT NULL,
  "minimum_stock_threshold" integer DEFAULT 20 NOT NULL,
  "supplier_lead_time_days" integer DEFAULT 7 NOT NULL,
  "unit" varchar(50) DEFAULT 'packs' NOT NULL,
  "updated_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_inventory_drug_name" ON "inventory_items" ("drug_name");

-- 7. MESSAGE LOGS
CREATE TABLE IF NOT EXISTS "message_logs" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "medication_id" uuid,
  "channel" varchar(20) NOT NULL,
  "recipient_phone" varchar(30) NOT NULL,
  "message_content" text NOT NULL,
  "delivery_mode" varchar(40) NOT NULL,
  "status" varchar(30) DEFAULT 'prepared' NOT NULL,
  "error_message" text,
  "sent_by" varchar(100) NOT NULL,
  "created_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_messages_patient" ON "message_logs" ("patient_id");
CREATE INDEX IF NOT EXISTS "idx_messages_created" ON "message_logs" ("created_at");

-- 8. THERMAL RECEIPT TOKENS
CREATE TABLE IF NOT EXISTS "thermal_receipt_tokens" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "token" varchar(64) NOT NULL UNIQUE,
  "patient_id" uuid NOT NULL REFERENCES "patients"("id") ON DELETE CASCADE,
  "medication_ids" jsonb NOT NULL,
  "instructions" text,
  "pharmacy_name" varchar(150) NOT NULL,
  "expires_at" timestamptz NOT NULL,
  "access_count" integer DEFAULT 0 NOT NULL,
  "created_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_thermal_token" ON "thermal_receipt_tokens" ("token");
CREATE INDEX IF NOT EXISTS "idx_thermal_expires" ON "thermal_receipt_tokens" ("expires_at");

-- 9. SYSTEM SETTINGS
CREATE TABLE IF NOT EXISTS "system_settings" (
  "key" varchar(100) PRIMARY KEY,
  "value" jsonb NOT NULL,
  "updated_at" timestamptz DEFAULT now() NOT NULL,
  "updated_by" varchar(100) DEFAULT 'System'
);

-- 10. AUDIT TRAIL LOGS
CREATE TABLE IF NOT EXISTS "audit_trail_logs" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "entity_type" varchar(50) NOT NULL,
  "entity_id" varchar(100) NOT NULL,
  "action" varchar(50) NOT NULL,
  "performed_by" varchar(100) NOT NULL,
  "details" jsonb,
  "created_at" timestamptz DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "idx_audit_entity" ON "audit_trail_logs" ("entity_type", "entity_id");
CREATE INDEX IF NOT EXISTS "idx_audit_created" ON "audit_trail_logs" ("created_at");
